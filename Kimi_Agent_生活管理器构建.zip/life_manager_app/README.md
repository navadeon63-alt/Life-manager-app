# Life Manager App

A comprehensive Flutter application for managing your daily life with tasks, notes, finance tracking, birthdays, and an AI assistant.

## Features

- **Tasks**: Create, manage, and track your daily tasks
- **Notes**: Keep track of important information
- **Finance**: Track expenses and income in ZAR currency
- **Birthdays**: Never forget important dates
- **AI Assistant**: Get help from Gemini 1.5 Flash API (online) or keyword-based responses (offline)
- **Daily Briefing**: Get a summary when you open the app
- **Google Sign-In**: Secure authentication
- **Push Notifications**: Get reminded of important events
- **Dark Theme**: Easy on the eyes

## Setup Instructions

### Prerequisites

- Flutter SDK (>=3.0.0)
- Android Studio or VS Code
- An Android device or emulator

### Google Sign-In Setup

To enable Google Sign-In, you need to configure your Firebase project:

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select existing one
3. Add an Android app with your package name: `com.example.life_manager_app`
4. Download the `google-services.json` file
5. Place it in `android/app/`
6. Get your SHA-1 fingerprint:
   ```bash
   cd android
   ./gradlew signingReport
   ```
7. Add the SHA-1 to your Firebase project settings

### Gemini API Setup

1. Get your API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Add it to your environment variables or constants.dart file

### Building the App

```bash
# Get dependencies
flutter pub get

# Run the app
flutter run

# Build release APK
flutter build apk --release
```

## Project Structure

```
lib/
├── core/
│   ├── constants.dart
│   └── theme.dart
├── models/
│   ├── task.dart
│   ├── note.dart
│   ├── finance.dart
│   ├── birthday.dart
│   ├── chat_message.dart
│   └── user_profile.dart
├── screens/
│   ├── sign_in_screen.dart
│   ├── home_screen.dart
│   ├── tasks_screen.dart
│   ├── notes_screen.dart
│   ├── finance_screen.dart
│   ├── birthdays_screen.dart
│   ├── assistant_screen.dart
│   ├── daily_briefing_screen.dart
│   └── settings_screen.dart
└── services/
    ├── storage_service.dart
    ├── notification_service.dart
    ├── connectivity_service.dart
    ├── auth_service.dart
    ├── ai_service.dart
    ├── local_ai_service.dart
    ├── online_ai_service.dart
    ├── app_context_service.dart
    ├── image_service.dart
    ├── learning_engine_service.dart
    └── user_profile_service.dart
```

## Offline Mode

When offline, the AI assistant uses a keyword-based response system to provide helpful pre-written responses based on your queries.

## License

MIT License
