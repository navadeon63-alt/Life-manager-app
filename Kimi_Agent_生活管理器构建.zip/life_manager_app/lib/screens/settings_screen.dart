import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../core/constants.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../services/notification_service.dart';
import '../services/user_profile_service.dart';
import '../services/learning_engine_service.dart';
import 'sign_in_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final AuthService _authService = AuthService();
  final StorageService _storage = StorageService();
  final NotificationService _notifications = NotificationService();
  final UserProfileService _profileService = UserProfileService();
  final LearningEngineService _learningEngine = LearningEngineService();

  bool _notificationsEnabled = true;
  bool _dailyBriefingEnabled = true;
  TimeOfDay _dailyBriefingTime = const TimeOfDay(hour: 8, minute: 0);
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final notificationsEnabled = _profileService.getPreference('notificationsEnabled', defaultValue: true);
    final dailyBriefingEnabled = _profileService.getPreference('dailyBriefingEnabled', defaultValue: true);
    final briefingHour = _profileService.getPreference('dailyBriefingHour', defaultValue: 8);
    final briefingMinute = _profileService.getPreference('dailyBriefingMinute', defaultValue: 0);

    setState(() {
      _notificationsEnabled = notificationsEnabled;
      _dailyBriefingEnabled = dailyBriefingEnabled;
      _dailyBriefingTime = TimeOfDay(hour: briefingHour, minute: briefingMinute);
    });
  }

  Future<void> _updateNotificationSettings(bool enabled) async {
    setState(() => _notificationsEnabled = enabled);
    await _profileService.updatePreference('notificationsEnabled', enabled);

    if (enabled) {
      await _notifications.requestPermissions();
    }
  }

  Future<void> _updateDailyBriefing(bool enabled) async {
    setState(() => _dailyBriefingEnabled = enabled);
    await _profileService.updatePreference('dailyBriefingEnabled', enabled);

    if (enabled) {
      await _notifications.scheduleDailyBriefing(
        hour: _dailyBriefingTime.hour,
        minute: _dailyBriefingTime.minute,
      );
    } else {
      await _notifications.cancelNotification(999999);
    }
  }

  Future<void> _updateBriefingTime(TimeOfDay time) async {
    setState(() => _dailyBriefingTime = time);
    await _profileService.updatePreference('dailyBriefingHour', time.hour);
    await _profileService.updatePreference('dailyBriefingMinute', time.minute);

    if (_dailyBriefingEnabled) {
      await _notifications.scheduleDailyBriefing(
        hour: time.hour,
        minute: time.minute,
      );
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _dailyBriefingTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            timePickerTheme: TimePickerThemeData(
              backgroundColor: AppTheme.backgroundCard,
              hourMinuteTextColor: AppTheme.textPrimary,
              dialHandColor: AppTheme.primaryColor,
              dialBackgroundColor: AppTheme.backgroundElevated,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != _dailyBriefingTime) {
      await _updateBriefingTime(picked);
    }
  }

  Future<void> _signOut() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.backgroundCard,
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isLoading = true);
      await _authService.signOut();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const SignInScreen()),
          (route) => false,
        );
      }
    }
  }

  Future<void> _clearAllData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.backgroundCard,
        title: const Text('Clear All Data'),
        content: const Text(
          'This will permanently delete all your tasks, notes, finances, and birthdays. This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isLoading = true);
      await _storage.clearAllData();
      await _notifications.cancelAllNotifications();
      setState(() => _isLoading = false);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All data has been cleared'),
            backgroundColor: AppTheme.success,
          ),
        );
      }
    }
  }

  Future<void> _exportData() async {
    setState(() => _isLoading = true);
    final path = await _learningEngine.exportUserData();
    setState(() => _isLoading = false);

    if (mounted) {
      if (path != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Data exported to: $path'),
            backgroundColor: AppTheme.success,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to export data'),
            backgroundColor: AppTheme.error,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _authService.currentUser;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // User Profile Section
                if (user != null) _buildUserProfileSection(user),
                const SizedBox(height: 24),
                // Notifications Section
                _buildSectionTitle('Notifications'),
                _buildSettingsCard([
                  SwitchListTile(
                    title: const Text('Enable Notifications'),
                    subtitle: const Text('Receive reminders and alerts'),
                    value: _notificationsEnabled,
                    onChanged: _updateNotificationSettings,
                    activeColor: AppTheme.primaryColor,
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    title: const Text('Daily Briefing'),
                    subtitle: const Text('Get a daily summary'),
                    value: _dailyBriefingEnabled,
                    onChanged: _updateDailyBriefing,
                    activeColor: AppTheme.primaryColor,
                  ),
                  if (_dailyBriefingEnabled)
                    ListTile(
                      title: const Text('Briefing Time'),
                      subtitle: Text(
                        '${_dailyBriefingTime.hour.toString().padLeft(2, '0')}:${_dailyBriefingTime.minute.toString().padLeft(2, '0')}',
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: _selectTime,
                    ),
                ]),
                const SizedBox(height: 24),
                // Data Management Section
                _buildSectionTitle('Data Management'),
                _buildSettingsCard([
                  ListTile(
                    leading: const Icon(Icons.download, color: AppTheme.primaryColor),
                    title: const Text('Export Data'),
                    subtitle: const Text('Save your data to a file'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _exportData,
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.delete_forever, color: AppTheme.error),
                    title: const Text('Clear All Data'),
                    subtitle: const Text('Permanently delete all your data'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: _clearAllData,
                  ),
                ]),
                const SizedBox(height: 24),
                // About Section
                _buildSectionTitle('About'),
                _buildSettingsCard([
                  const ListTile(
                    title: Text('App Version'),
                    subtitle: Text(Constants.appVersion),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    title: const Text('Privacy Policy'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: () {
                      // Open privacy policy
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    title: const Text('Terms of Service'),
                    trailing: const Icon(Icons.open_in_new, size: 18),
                    onTap: () {
                      // Open terms of service
                    },
                  ),
                ]),
                const SizedBox(height: 24),
                // Sign Out Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _signOut,
                    icon: const Icon(Icons.logout),
                    label: const Text('Sign Out'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.error,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
                const SizedBox(height: 32),
              ],
            ),
    );
  }

  Widget _buildUserProfileSection(dynamic user) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 35,
            backgroundColor: Colors.white24,
            backgroundImage: user.photoUrl != null
                ? NetworkImage(user.photoUrl!)
                : null,
            child: user.photoUrl == null
                ? Text(
                    user.displayName?.isNotEmpty == true
                        ? user.displayName![0].toUpperCase()
                        : '?',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.displayName ?? 'User',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  user.email ?? '',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, left: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppTheme.textMuted,
        ),
      ),
    );
  }

  Widget _buildSettingsCard(List<Widget> children) {
    return Card(
      margin: EdgeInsets.zero,
      child: Column(
        children: children,
      ),
    );
  }
}
