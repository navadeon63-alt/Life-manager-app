import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../core/theme.dart';
import '../core/constants.dart';
import '../models/finance.dart';
import '../services/storage_service.dart';
import '../services/image_service.dart';
import '../services/learning_engine_service.dart';

class FinanceScreen extends StatefulWidget {
  const FinanceScreen({super.key});

  @override
  State<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  final StorageService _storage = StorageService();
  final ImageService _imageService = ImageService();
  final LearningEngineService _learningEngine = LearningEngineService();
  final Uuid _uuid = const Uuid();
  final currencyFormat = NumberFormat.currency(symbol: 'R', locale: 'en_ZA');

  List<Finance> _finances = [];
  bool _isLoading = true;
  String _filterType = 'all'; // all, income, expense

  @override
  void initState() {
    super.initState();
    _loadFinances();
  }

  Future<void> _loadFinances() async {
    setState(() => _isLoading = true);
    final finances = await _storage.getFinances();
    setState(() {
      _finances = finances;
      _isLoading = false;
    });
  }

  List<Finance> get _filteredFinances {
    var finances = _finances;
    if (_filterType != 'all') {
      finances = finances.where((f) => f.type == _filterType).toList();
    }
    // Sort by date descending
    finances.sort((a, b) => b.date.compareTo(a.date));
    return finances;
  }

  double get _totalIncome {
    return _finances
        .where((f) => f.type == 'income')
        .fold(0, (sum, f) => sum + f.amount);
  }

  double get _totalExpense {
    return _finances
        .where((f) => f.type == 'expense')
        .fold(0, (sum, f) => sum + f.amount);
  }

  double get _balance {
    return _totalIncome - _totalExpense;
  }

  Future<void> _addFinance(Finance finance) async {
    await _storage.addFinance(finance);
    await _learningEngine.trackFeatureUsage(Constants.featureFinance);
    await _loadFinances();
  }

  Future<void> _updateFinance(Finance finance) async {
    await _storage.updateFinance(finance);
    await _loadFinances();
  }

  Future<void> _deleteFinance(String id) async {
    await _storage.deleteFinance(id);
    await _loadFinances();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: Column(
        children: [
          _buildSummaryCard(),
          _buildFilterChips(),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredFinances.isEmpty
                    ? _buildEmptyState()
                    : _buildFinanceList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddFinanceDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildSummaryCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'Total Balance',
            style: TextStyle(
              fontSize: 16,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            currencyFormat.format(_balance),
            style: const TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildSummaryItem(
                  'Income',
                  _totalIncome,
                  Icons.arrow_upward,
                  AppTheme.success,
                ),
              ),
              Expanded(
                child: _buildSummaryItem(
                  'Expense',
                  _totalExpense,
                  Icons.arrow_downward,
                  AppTheme.error,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(
    String label,
    double amount,
    IconData icon,
    Color color,
  ) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.white70,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          currencyFormat.format(amount),
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChips() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _buildFilterChip('All', 'all'),
          const SizedBox(width: 8),
          _buildFilterChip('Income', 'income'),
          const SizedBox(width: 8),
          _buildFilterChip('Expense', 'expense'),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String value) {
    final isSelected = _filterType == value;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          setState(() => _filterType = value);
        }
      },
      backgroundColor: AppTheme.backgroundCard,
      selectedColor: AppTheme.primaryColor,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : AppTheme.textSecondary,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.account_balance_wallet_outlined,
            size: 80,
            color: AppTheme.textMuted.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No transactions yet',
            style: TextStyle(
              fontSize: 18,
              color: AppTheme.textMuted.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap + to add a transaction',
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textMuted.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFinanceList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _filteredFinances.length,
      itemBuilder: (context, index) {
        final finance = _filteredFinances[index];
        return _buildFinanceCard(finance);
      },
    );
  }

  Widget _buildFinanceCard(Finance finance) {
    final isIncome = finance.type == 'income';
    final color = isIncome ? AppTheme.success : AppTheme.error;
    final sign = isIncome ? '+' : '-';

    return Dismissible(
      key: Key(finance.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: AppTheme.error,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) => _deleteFinance(finance.id),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: () => _showEditFinanceDialog(finance),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    isIncome ? Icons.arrow_upward : Icons.arrow_downward,
                    color: color,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        finance.title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      if (finance.description != null &&
                          finance.description!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            finance.description!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.backgroundElevated,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              finance.category,
                              style: const TextStyle(
                                fontSize: 12,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            DateFormat('MMM d, y').format(finance.date),
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppTheme.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Text(
                  '$sign${currencyFormat.format(finance.amount).replaceAll('R', '')}',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAddFinanceDialog() {
    showDialog(
      context: context,
      builder: (context) => FinanceDialog(
        onSave: _addFinance,
        imageService: _imageService,
      ),
    );
  }

  void _showEditFinanceDialog(Finance finance) {
    showDialog(
      context: context,
      builder: (context) => FinanceDialog(
        finance: finance,
        onSave: _updateFinance,
        imageService: _imageService,
      ),
    );
  }
}

class FinanceDialog extends StatefulWidget {
  final Finance? finance;
  final Function(Finance) onSave;
  final ImageService imageService;

  const FinanceDialog({
    super.key,
    this.finance,
    required this.onSave,
    required this.imageService,
  });

  @override
  State<FinanceDialog> createState() => _FinanceDialogState();
}

class _FinanceDialogState extends State<FinanceDialog> {
  final _titleController = TextEditingController();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  String _type = 'expense';
  String _category = 'Food';
  DateTime _date = DateTime.now();
  String? _imagePath;

  final List<String> _incomeCategories = Constants.incomeCategories;
  final List<String> _expenseCategories = Constants.expenseCategories;

  List<String> get _currentCategories {
    return _type == 'income' ? _incomeCategories : _expenseCategories;
  }

  @override
  void initState() {
    super.initState();
    if (widget.finance != null) {
      _titleController.text = widget.finance!.title;
      _amountController.text = widget.finance!.amount.toString();
      _descriptionController.text = widget.finance!.description ?? '';
      _type = widget.finance!.type;
      _category = widget.finance!.category;
      _date = widget.finance!.date;
      _imagePath = widget.finance!.imagePath;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    await widget.imageService.showImagePickerOptions(
      context: context,
      onImageSelected: (path) {
        if (path != null) {
          setState(() => _imagePath = path);
        }
      },
    );
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      setState(() => _date = date);
    }
  }

  void _save() {
    if (_titleController.text.trim().isEmpty) return;
    if (_amountController.text.trim().isEmpty) return;

    final amount = double.tryParse(_amountController.text.trim());
    if (amount == null || amount <= 0) return;

    final finance = Finance(
      id: widget.finance?.id ?? const Uuid().v4(),
      title: _titleController.text.trim(),
      amount: amount,
      type: _type,
      category: _category,
      date: _date,
      description: _descriptionController.text.trim(),
      imagePath: _imagePath,
    );

    widget.onSave(finance);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppTheme.backgroundCard,
      title: Text(widget.finance == null ? 'Add Transaction' : 'Edit Transaction'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Type selector
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(
                  value: 'expense',
                  label: Text('Expense'),
                  icon: Icon(Icons.arrow_downward),
                ),
                ButtonSegment(
                  value: 'income',
                  label: Text('Income'),
                  icon: Icon(Icons.arrow_upward),
                ),
              ],
              selected: {_type},
              onSelectionChanged: (Set<String> selected) {
                setState(() {
                  _type = selected.first;
                  _category = _currentCategories.first;
                });
              },
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title',
                hintText: 'Enter transaction title',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Amount (ZAR)',
                hintText: 'Enter amount',
                prefixText: 'R ',
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Category'),
              items: _currentCategories
                  .map((c) => DropdownMenuItem(
                        value: c,
                        child: Text(c),
                      ))
                  .toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() => _category = value);
                }
              },
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              decoration: const InputDecoration(
                labelText: 'Description (optional)',
                hintText: 'Enter description',
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.calendar_today, color: AppTheme.textSecondary),
              title: Text('Date: ${_date.toString().split(' ')[0]}'),
              onTap: _selectDate,
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.image, color: AppTheme.textSecondary),
              title: Text(_imagePath == null ? 'Add receipt/image' : 'Image attached'),
              trailing: _imagePath != null
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () => setState(() => _imagePath = null),
                    )
                  : null,
              onTap: _pickImage,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _save,
          child: const Text('Save'),
        ),
      ],
    );
  }
}
