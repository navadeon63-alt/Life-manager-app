import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../core/theme.dart';
import '../core/constants.dart';
import '../models/birthday.dart';
import '../services/storage_service.dart';
import '../services/notification_service.dart';
import '../services/image_service.dart';
import '../services/learning_engine_service.dart';

class BirthdaysScreen extends StatefulWidget {
  const BirthdaysScreen({super.key});

  @override
  State<BirthdaysScreen> createState() => _BirthdaysScreenState();
}

class _BirthdaysScreenState extends State<BirthdaysScreen> {
  final StorageService _storage = StorageService();
  final NotificationService _notifications = NotificationService();
  final ImageService _imageService = ImageService();
  final LearningEngineService _learningEngine = LearningEngineService();
  final Uuid _uuid = const Uuid();

  List<Birthday> _birthdays = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBirthdays();
  }

  Future<void> _loadBirthdays() async {
    setState(() => _isLoading = true);
    final birthdays = await _storage.getBirthdays();
    setState(() {
      _birthdays = birthdays;
      _isLoading = false;
    });
  }

  List<Birthday> get _sortedBirthdays {
    final now = DateTime.now();
    final sorted = List<Birthday>.from(_birthdays);
    sorted.sort((a, b) {
      final aDays = a.daysUntilBirthday;
      final bDays = b.daysUntilBirthday;
      return aDays.compareTo(bDays);
    });
    return sorted;
  }

  List<Birthday> get _todaysBirthdays {
    return _birthdays.where((b) => b.isToday).toList();
  }

  List<Birthday> get _upcomingBirthdays {
    return _sortedBirthdays.where((b) => !b.isToday).toList();
  }

  Future<void> _addBirthday(Birthday birthday) async {
    await _storage.addBirthday(birthday);
    if (birthday.reminderEnabled) {
      await _notifications.scheduleBirthdayReminder(
        birthdayId: birthday.id,
        name: birthday.name,
        birthDate: birthday.birthDate,
        daysBefore: birthday.reminderDaysBefore,
      );
    }
    await _learningEngine.trackFeatureUsage(Constants.featureBirthdays);
    await _loadBirthdays();
  }

  Future<void> _updateBirthday(Birthday birthday) async {
    await _storage.updateBirthday(birthday);
    if (birthday.reminderEnabled) {
      await _notifications.scheduleBirthdayReminder(
        birthdayId: birthday.id,
        name: birthday.name,
        birthDate: birthday.birthDate,
        daysBefore: birthday.reminderDaysBefore,
      );
    } else {
      await _notifications.cancelNotification(birthday.id.hashCode);
    }
    await _loadBirthdays();
  }

  Future<void> _deleteBirthday(String id) async {
    await _storage.deleteBirthday(id);
    await _notifications.cancelNotification(id.hashCode);
    await _loadBirthdays();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _birthdays.isEmpty
              ? _buildEmptyState()
              : _buildBirthdaysList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddBirthdayDialog(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.cake_outlined,
            size: 80,
            color: AppTheme.textMuted.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No birthdays yet',
            style: TextStyle(
              fontSize: 18,
              color: AppTheme.textMuted.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap + to add a birthday reminder',
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textMuted.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBirthdaysList() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_todaysBirthdays.isNotEmpty) ...[
          _buildSectionTitle('Today 🎉'),
          ..._todaysBirthdays.map((b) => _buildBirthdayCard(b, isToday: true)),
          const SizedBox(height: 24),
        ],
        if (_upcomingBirthdays.isNotEmpty) ...[
          _buildSectionTitle('Upcoming'),
          ..._upcomingBirthdays.map((b) => _buildBirthdayCard(b)),
        ],
      ],
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: AppTheme.textPrimary,
        ),
      ),
    );
  }

  Widget _buildBirthdayCard(Birthday birthday, {bool isToday = false}) {
    final daysUntil = birthday.daysUntilBirthday;
    final age = birthday.age + (isToday ? 1 : 0);

    return Dismissible(
      key: Key(birthday.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: AppTheme.error,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) => _deleteBirthday(birthday.id),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        color: isToday ? AppTheme.primaryColor.withOpacity(0.2) : null,
        child: InkWell(
          onTap: () => _showEditBirthdayDialog(birthday),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isToday
                          ? [AppTheme.primaryColor, AppTheme.secondaryColor]
                          : [AppTheme.backgroundElevated, AppTheme.backgroundCard],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Center(
                    child: Text(
                      birthday.name.isNotEmpty ? birthday.name[0].toUpperCase() : '?',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: isToday ? Colors.white : AppTheme.textPrimary,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        birthday.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          if (birthday.relationship != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.backgroundElevated,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                birthday.relationship!,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ),
                          const SizedBox(width: 8),
                          Text(
                            'Turning $age',
                            style: const TextStyle(
                              fontSize: 14,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        DateFormat('MMMM d').format(birthday.birthDate),
                        style: const TextStyle(
                          fontSize: 14,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: isToday
                        ? AppTheme.primaryColor
                        : AppTheme.backgroundElevated,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    isToday
                        ? 'TODAY!'
                        : daysUntil == 1
                            ? '1 day'
                            : '$daysUntil days',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: isToday ? Colors.white : AppTheme.textSecondary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showAddBirthdayDialog() {
    showDialog(
      context: context,
      builder: (context) => BirthdayDialog(
        onSave: _addBirthday,
        imageService: _imageService,
      ),
    );
  }

  void _showEditBirthdayDialog(Birthday birthday) {
    showDialog(
      context: context,
      builder: (context) => BirthdayDialog(
        birthday: birthday,
        onSave: _updateBirthday,
        imageService: _imageService,
      ),
    );
  }
}

class BirthdayDialog extends StatefulWidget {
  final Birthday? birthday;
  final Function(Birthday) onSave;
  final ImageService imageService;

  const BirthdayDialog({
    super.key,
    this.birthday,
    required this.onSave,
    required this.imageService,
  });

  @override
  State<BirthdayDialog> createState() => _BirthdayDialogState();
}

class _BirthdayDialogState extends State<BirthdayDialog> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _notesController = TextEditingController();
  DateTime _birthDate = DateTime.now();
  String? _relationship;
  bool _reminderEnabled = true;
  int _reminderDaysBefore = 1;
  String? _imagePath;

  final List<String> _relationships = Constants.relationships;

  @override
  void initState() {
    super.initState();
    if (widget.birthday != null) {
      _nameController.text = widget.birthday!.name;
      _phoneController.text = widget.birthday!.phoneNumber ?? '';
      _emailController.text = widget.birthday!.email ?? '';
      _notesController.text = widget.birthday!.notes ?? '';
      _birthDate = widget.birthday!.birthDate;
      _relationship = widget.birthday!.relationship;
      _reminderEnabled = widget.birthday!.reminderEnabled;
      _reminderDaysBefore = widget.birthday!.reminderDaysBefore;
      _imagePath = widget.birthday!.imagePath;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    await widget.imageService.showImagePickerOptions(
      context: context,
      onImageSelected: (path) {
        if (path != null) {
          setState(() => _imagePath = path);
        }
      },
    );
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _birthDate,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (date != null) {
      setState(() => _birthDate = date);
    }
  }

  void _save() {
    if (_nameController.text.trim().isEmpty) return;

    final birthday = Birthday(
      id: widget.birthday?.id ?? const Uuid().v4(),
      name: _nameController.text.trim(),
      birthDate: _birthDate,
      relationship: _relationship,
      phoneNumber: _phoneController.text.trim().isEmpty
          ? null
          : _phoneController.text.trim(),
      email: _emailController.text.trim().isEmpty
          ? null
          : _emailController.text.trim(),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      reminderEnabled: _reminderEnabled,
      reminderDaysBefore: _reminderDaysBefore,
      imagePath: _imagePath,
    );

    widget.onSave(birthday);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppTheme.backgroundCard,
      title: Text(widget.birthday == null ? 'Add Birthday' : 'Edit Birthday'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
                hintText: 'Enter person\'s name',
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.calendar_today, color: AppTheme.textSecondary),
              title: Text('Birth Date: ${DateFormat('MMMM d, y').format(_birthDate)}'),
              onTap: _selectDate,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String?>(
              value: _relationship,
              decoration: const InputDecoration(labelText: 'Relationship (optional)'),
              items: [
                const DropdownMenuItem(
                  value: null,
                  child: Text('None'),
                ),
                ..._relationships.map((r) => DropdownMenuItem(
                      value: r,
                      child: Text(r),
                    )),
              ],
              onChanged: (value) => setState(() => _relationship = value),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _phoneController,
              decoration: const InputDecoration(
                labelText: 'Phone (optional)',
                hintText: 'Enter phone number',
              ),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Email (optional)',
                hintText: 'Enter email address',
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _notesController,
              decoration: const InputDecoration(
                labelText: 'Notes (optional)',
                hintText: 'Gift ideas, preferences, etc.',
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Enable Reminder'),
              value: _reminderEnabled,
              onChanged: (value) => setState(() => _reminderEnabled = value),
            ),
            if (_reminderEnabled)
              DropdownButtonFormField<int>(
                value: _reminderDaysBefore,
                decoration: const InputDecoration(labelText: 'Remind me'),
                items: [
                  const DropdownMenuItem(value: 0, child: Text('On the day')),
                  const DropdownMenuItem(value: 1, child: Text('1 day before')),
                  const DropdownMenuItem(value: 3, child: Text('3 days before')),
                  const DropdownMenuItem(value: 7, child: Text('1 week before')),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _reminderDaysBefore = value);
                  }
                },
              ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.image, color: AppTheme.textSecondary),
              title: Text(_imagePath == null ? 'Add photo' : 'Photo attached'),
              trailing: _imagePath != null
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () => setState(() => _imagePath = null),
                    )
                  : null,
              onTap: _pickImage,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _save,
          child: const Text('Save'),
        ),
      ],
    );
  }
}
