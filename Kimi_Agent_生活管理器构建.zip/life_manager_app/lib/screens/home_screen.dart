import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/user_profile_service.dart';
import '../services/learning_engine_service.dart';
import 'tasks_screen.dart';
import 'notes_screen.dart';
import 'finance_screen.dart';
import 'birthdays_screen.dart';
import 'assistant_screen.dart';
import 'daily_briefing_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final UserProfileService _profileService = UserProfileService();
  final LearningEngineService _learningEngine = LearningEngineService();

  final List<Widget> _screens = [
    const TasksScreen(),
    const NotesScreen(),
    const FinanceScreen(),
    const BirthdaysScreen(),
    const AssistantScreen(),
  ];

  final List<String> _titles = [
    'Tasks',
    'Notes',
    'Finance',
    'Birthdays',
    'AI Assistant',
  ];

  final List<IconData> _icons = [
    Icons.check_circle_outline,
    Icons.note_alt_outlined,
    Icons.account_balance_wallet_outlined,
    Icons.cake_outlined,
    Icons.smart_toy_outlined,
  ];

  @override
  void initState() {
    super.initState();
    _showDailyBriefing();
    _updateLastActive();
  }

  Future<void> _showDailyBriefing() async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) {
      final shouldShow = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (context) => const DailyBriefingScreen(),
      );

      if (shouldShow == true && mounted) {
        // User wants to see full briefing
      }
    }
  }

  Future<void> _updateLastActive() async {
    await _profileService.updateLastActive();
  }

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    // Track feature usage
    final featureNames = ['tasks', 'notes', 'finance', 'birthdays', 'assistant'];
    _learningEngine.trackFeatureUsage(featureNames[index]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        title: Text(_titles[_currentIndex]),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.backgroundDark,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: _onTabTapped,
          backgroundColor: AppTheme.backgroundDark,
          selectedItemColor: AppTheme.primaryColor,
          unselectedItemColor: AppTheme.textMuted,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: List.generate(
            _titles.length,
            (index) => BottomNavigationBarItem(
              icon: Icon(_icons[index]),
              label: _titles[index],
            ),
          ),
        ),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget? _buildFloatingActionButton() {
    switch (_currentIndex) {
      case 0: // Tasks
        return FloatingActionButton(
          onPressed: () => _showAddTaskDialog(),
          child: const Icon(Icons.add),
        );
      case 1: // Notes
        return FloatingActionButton(
          onPressed: () => _showAddNoteDialog(),
          child: const Icon(Icons.add),
        );
      case 2: // Finance
        return FloatingActionButton(
          onPressed: () => _showAddFinanceDialog(),
          child: const Icon(Icons.add),
        );
      case 3: // Birthdays
        return FloatingActionButton(
          onPressed: () => _showAddBirthdayDialog(),
          child: const Icon(Icons.add),
        );
      default:
        return null;
    }
  }

  void _showAddTaskDialog() {
    // Navigate to tasks screen's add dialog
    final tasksScreenState = _screens[0] as TasksScreen;
    // This will be handled by the TasksScreen itself
  }

  void _showAddNoteDialog() {
    // Navigate to notes screen's add dialog
  }

  void _showAddFinanceDialog() {
    // Navigate to finance screen's add dialog
  }

  void _showAddBirthdayDialog() {
    // Navigate to birthdays screen's add dialog
  }
}
