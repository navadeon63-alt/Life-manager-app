import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../core/theme.dart';
import '../models/chat_message.dart';
import '../services/ai_service.dart';
import '../services/connectivity_service.dart';
import '../services/image_service.dart';
import '../services/learning_engine_service.dart';
import '../services/storage_service.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final AIService _aiService = AIService();
  final ConnectivityService _connectivity = ConnectivityService();
  final ImageService _imageService = ImageService();
  final LearningEngineService _learningEngine = LearningEngineService();
  final StorageService _storage = StorageService();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final Uuid _uuid = const Uuid();

  List<ChatMessage> _messages = [];
  bool _isTyping = false;
  bool _isOnline = true;
  String? _pendingImagePath;

  final List<String> _quickQuestions = [
    'What tasks do I have today?',
    'Help me plan my day',
    'Any birthdays coming up?',
    'Give me finance tips',
    'Motivate me!',
  ];

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _checkConnectivity();
    _connectivity.connectionStream.listen((isOnline) {
      setState(() => _isOnline = isOnline);
    });
  }

  Future<void> _loadMessages() async {
    final messages = await _storage.getChatMessages();
    setState(() => _messages = messages);
    _scrollToBottom();
  }

  Future<void> _checkConnectivity() async {
    final isOnline = await _connectivity.checkConnection();
    setState(() => _isOnline = isOnline);
  }

  Future<void> _sendMessage(String content, {String? imagePath}) async {
    if (content.trim().isEmpty && imagePath == null) return;

    // Add user message
    final userMessage = ChatMessage(
      id: _uuid.v4(),
      content: content.trim(),
      isUser: true,
      timestamp: DateTime.now(),
      imagePath: imagePath,
    );

    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
      _pendingImagePath = null;
    });

    _messageController.clear();
    _scrollToBottom();

    // Save messages
    await _storage.saveChatMessages(_messages);

    // Track query
    await _learningEngine.trackQuery(content);

    // Get AI response
    try {
      final response = await _aiService.sendMessage(
        content,
        imagePath: imagePath,
      );

      setState(() {
        _messages.add(response);
        _isTyping = false;
      });

      await _storage.saveChatMessages(_messages);
    } catch (e) {
      setState(() => _isTyping = false);
    }

    _scrollToBottom();
  }

  Future<void> _pickImage() async {
    await _imageService.showImagePickerOptions(
      context: context,
      onImageSelected: (path) {
        if (path != null) {
          setState(() => _pendingImagePath = path);
        }
      },
    );
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _clearChat() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.backgroundCard,
        title: const Text('Clear Chat'),
        content: const Text('Are you sure you want to clear all messages?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _messages.clear());
      await _storage.clearChatMessages();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        title: const Text('AI Assistant'),
        actions: [
          // Online/Offline indicator
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _isOnline
                  ? AppTheme.success.withOpacity(0.2)
                  : AppTheme.warning.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _isOnline ? AppTheme.success : AppTheme.warning,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _isOnline ? 'Online' : 'Offline',
                  style: TextStyle(
                    fontSize: 12,
                    color: _isOnline ? AppTheme.success : AppTheme.warning,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: _clearChat,
          ),
        ],
      ),
      body: Column(
        children: [
          // Quick questions
          if (_messages.isEmpty) _buildQuickQuestions(),
          // Messages
          Expanded(
            child: _messages.isEmpty
                ? _buildWelcomeMessage()
                : _buildMessageList(),
          ),
          // Typing indicator
          if (_isTyping) _buildTypingIndicator(),
          // Input area
          _buildInputArea(),
        ],
      ),
    );
  }

  Widget _buildQuickQuestions() {
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _quickQuestions.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ActionChip(
              label: Text(_quickQuestions[index]),
              onPressed: () => _sendMessage(_quickQuestions[index]),
              backgroundColor: AppTheme.backgroundCard,
              labelStyle: const TextStyle(color: AppTheme.textSecondary),
            ),
          );
        },
      ),
    );
  }

  Widget _buildWelcomeMessage() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(
              Icons.smart_toy,
              size: 40,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'How can I help you today?',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _isOnline
                ? 'Ask me about your tasks, notes, finances, or anything else!'
                : 'I\'m offline but can still help with basic responses.',
            style: const TextStyle(
              fontSize: 14,
              color: AppTheme.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(16),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final message = _messages[index];
        return _buildMessageBubble(message);
      },
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isUser = message.isUser;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isUser
              ? AppTheme.primaryColor
              : AppTheme.backgroundCard,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isUser ? 16 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 16),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (message.imagePath != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  File(message.imagePath!),
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            if (message.imagePath != null && message.content.isNotEmpty)
              const SizedBox(height: 8),
            if (message.content.isNotEmpty)
              Text(
                message.content,
                style: TextStyle(
                  fontSize: 15,
                  color: isUser ? Colors.white : AppTheme.textPrimary,
                ),
              ),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  DateFormat('h:mm a').format(message.timestamp),
                  style: TextStyle(
                    fontSize: 11,
                    color: isUser
                        ? Colors.white70
                        : AppTheme.textMuted,
                  ),
                ),
                if (!isUser && message.isOffline) ...[
                  const SizedBox(width: 6),
                  Icon(
                    Icons.offline_bolt,
                    size: 12,
                    color: AppTheme.warning,
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.only(left: 16, bottom: 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.backgroundCard,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDot(0),
            const SizedBox(width: 4),
            _buildDot(1),
            const SizedBox(width: 4),
            _buildDot(2),
          ],
        ),
      ),
    );
  }

  Widget _buildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        color: AppTheme.textMuted.withOpacity(0.5),
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.backgroundCard,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_pendingImagePath != null)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.backgroundElevated,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: Image.file(
                        File(_pendingImagePath!),
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Image selected',
                        style: TextStyle(color: AppTheme.textSecondary),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.clear, color: AppTheme.textMuted),
                      onPressed: () => setState(() => _pendingImagePath = null),
                    ),
                  ],
                ),
              ),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.image, color: AppTheme.textSecondary),
                  onPressed: _pickImage,
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    textInputAction: TextInputAction.send,
                    onSubmitted: (text) => _sendMessage(
                      text,
                      imagePath: _pendingImagePath,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: AppTheme.primaryColor),
                  onPressed: () => _sendMessage(
                    _messageController.text,
                    imagePath: _pendingImagePath,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
