class Finance {
  final String id;
  String title;
  double amount;
  String type;
  String category;
  DateTime date;
  String? description;
  String? imagePath;
  String currency;

  Finance({
    required this.id,
    required this.title,
    required this.amount,
    required this.type,
    required this.category,
    required this.date,
    this.description,
    this.imagePath,
    this.currency = 'ZAR',
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'type': type,
      'category': category,
      'date': date.toIso8601String(),
      'description': description,
      'imagePath': imagePath,
      'currency': currency,
    };
  }

  factory Finance.fromJson(Map<String, dynamic> json) {
    return Finance(
      id: json['id'],
      title: json['title'],
      amount: json['amount'].toDouble(),
      type: json['type'],
      category: json['category'],
      date: DateTime.parse(json['date']),
      description: json['description'],
      imagePath: json['imagePath'],
      currency: json['currency'] ?? 'ZAR',
    );
  }

  Finance copyWith({
    String? id,
    String? title,
    double? amount,
    String? type,
    String? category,
    DateTime? date,
    String? description,
    String? imagePath,
    String? currency,
  }) {
    return Finance(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      category: category ?? this.category,
      date: date ?? this.date,
      description: description ?? this.description,
      imagePath: imagePath ?? this.imagePath,
      currency: currency ?? this.currency,
    );
  }
}

class FinanceCategory {
  final String id;
  String name;
  String type;
  String iconName;
  String color;

  FinanceCategory({
    required this.id,
    required this.name,
    required this.type,
    required this.iconName,
    required this.color,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'iconName': iconName,
      'color': color,
    };
  }

  factory FinanceCategory.fromJson(Map<String, dynamic> json) {
    return FinanceCategory(
      id: json['id'],
      name: json['name'],
      type: json['type'],
      iconName: json['iconName'],
      color: json['color'],
    );
  }
}

class FinanceSummary {
  final double totalIncome;
  final double totalExpense;
  final double balance;
  final Map<String, double> categoryBreakdown;

  FinanceSummary({
    required this.totalIncome,
    required this.totalExpense,
    required this.balance,
    required this.categoryBreakdown,
  });
}
