class UserProfile {
  final String id;
  String name;
  String email;
  String? photoUrl;
  DateTime createdAt;
  DateTime lastActive;
  Map<String, dynamic> preferences;
  Map<String, dynamic> habits;
  Map<String, int> featureUsage;
  List<String> commonQueries;
  Map<String, dynamic> aiInteractions;

  UserProfile({
    required this.id,
    required this.name,
    required this.email,
    this.photoUrl,
    required this.createdAt,
    required this.lastActive,
    this.preferences = const {},
    this.habits = const {},
    this.featureUsage = const {},
    this.commonQueries = const [],
    this.aiInteractions = const {},
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'photoUrl': photoUrl,
      'createdAt': createdAt.toIso8601String(),
      'lastActive': lastActive.toIso8601String(),
      'preferences': preferences,
      'habits': habits,
      'featureUsage': featureUsage,
      'commonQueries': commonQueries,
      'aiInteractions': aiInteractions,
    };
  }

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      photoUrl: json['photoUrl'],
      createdAt: DateTime.parse(json['createdAt']),
      lastActive: DateTime.parse(json['lastActive']),
      preferences: Map<String, dynamic>.from(json['preferences'] ?? {}),
      habits: Map<String, dynamic>.from(json['habits'] ?? {}),
      featureUsage: Map<String, int>.from(json['featureUsage'] ?? {}),
      commonQueries: List<String>.from(json['commonQueries'] ?? []),
      aiInteractions: Map<String, dynamic>.from(json['aiInteractions'] ?? {}),
    );
  }

  UserProfile copyWith({
    String? id,
    String? name,
    String? email,
    String? photoUrl,
    DateTime? createdAt,
    DateTime? lastActive,
    Map<String, dynamic>? preferences,
    Map<String, dynamic>? habits,
    Map<String, int>? featureUsage,
    List<String>? commonQueries,
    Map<String, dynamic>? aiInteractions,
  }) {
    return UserProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      photoUrl: photoUrl ?? this.photoUrl,
      createdAt: createdAt ?? this.createdAt,
      lastActive: lastActive ?? this.lastActive,
      preferences: preferences ?? this.preferences,
      habits: habits ?? this.habits,
      featureUsage: featureUsage ?? this.featureUsage,
      commonQueries: commonQueries ?? this.commonQueries,
      aiInteractions: aiInteractions ?? this.aiInteractions,
    );
  }
}

class UserHabit {
  final String id;
  String name;
  String category;
  int frequency;
  DateTime lastOccurrence;
  List<DateTime> occurrences;
  double importance;

  UserHabit({
    required this.id,
    required this.name,
    required this.category,
    this.frequency = 0,
    required this.lastOccurrence,
    this.occurrences = const [],
    this.importance = 1.0,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'frequency': frequency,
      'lastOccurrence': lastOccurrence.toIso8601String(),
      'occurrences': occurrences.map((o) => o.toIso8601String()).toList(),
      'importance': importance,
    };
  }

  factory UserHabit.fromJson(Map<String, dynamic> json) {
    return UserHabit(
      id: json['id'],
      name: json['name'],
      category: json['category'],
      frequency: json['frequency'] ?? 0,
      lastOccurrence: DateTime.parse(json['lastOccurrence']),
      occurrences: (json['occurrences'] as List?)
              ?.map((o) => DateTime.parse(o))
              .toList() ??
          [],
      importance: json['importance']?.toDouble() ?? 1.0,
    );
  }
}
