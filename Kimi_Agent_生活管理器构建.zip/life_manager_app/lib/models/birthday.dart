class Birthday {
  final String id;
  String name;
  DateTime birthDate;
  String? relationship;
  String? phoneNumber;
  String? email;
  String? notes;
  String? imagePath;
  bool reminderEnabled;
  int reminderDaysBefore;

  Birthday({
    required this.id,
    required this.name,
    required this.birthDate,
    this.relationship,
    this.phoneNumber,
    this.email,
    this.notes,
    this.imagePath,
    this.reminderEnabled = true,
    this.reminderDaysBefore = 1,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'birthDate': birthDate.toIso8601String(),
      'relationship': relationship,
      'phoneNumber': phoneNumber,
      'email': email,
      'notes': notes,
      'imagePath': imagePath,
      'reminderEnabled': reminderEnabled,
      'reminderDaysBefore': reminderDaysBefore,
    };
  }

  factory Birthday.fromJson(Map<String, dynamic> json) {
    return Birthday(
      id: json['id'],
      name: json['name'],
      birthDate: DateTime.parse(json['birthDate']),
      relationship: json['relationship'],
      phoneNumber: json['phoneNumber'],
      email: json['email'],
      notes: json['notes'],
      imagePath: json['imagePath'],
      reminderEnabled: json['reminderEnabled'] ?? true,
      reminderDaysBefore: json['reminderDaysBefore'] ?? 1,
    );
  }

  Birthday copyWith({
    String? id,
    String? name,
    DateTime? birthDate,
    String? relationship,
    String? phoneNumber,
    String? email,
    String? notes,
    String? imagePath,
    bool? reminderEnabled,
    int? reminderDaysBefore,
  }) {
    return Birthday(
      id: id ?? this.id,
      name: name ?? this.name,
      birthDate: birthDate ?? this.birthDate,
      relationship: relationship ?? this.relationship,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      email: email ?? this.email,
      notes: notes ?? this.notes,
      imagePath: imagePath ?? this.imagePath,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      reminderDaysBefore: reminderDaysBefore ?? this.reminderDaysBefore,
    );
  }

  int get age {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month ||
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  int get daysUntilBirthday {
    final now = DateTime.now();
    DateTime nextBirthday = DateTime(now.year, birthDate.month, birthDate.day);
    if (nextBirthday.isBefore(now) || nextBirthday.isAtSameMomentAs(now)) {
      nextBirthday = DateTime(now.year + 1, birthDate.month, birthDate.day);
    }
    return nextBirthday.difference(now).inDays;
  }

  bool get isToday {
    final now = DateTime.now();
    return now.month == birthDate.month && now.day == birthDate.day;
  }
}
