import 'dart:async';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [
      'email',
      'profile',
    ],
  );

  final StreamController<bool> _authStateController =
      StreamController<bool>.broadcast();
  Stream<bool> get authStateStream => _authStateController.stream;

  GoogleSignInAccount? _currentUser;
  GoogleSignInAccount? get currentUser => _currentUser;

  bool get isSignedIn => _currentUser != null;

  Future<void> init() async {
    _currentUser = await _googleSignIn.signInSilently();
    _authStateController.add(isSignedIn);
  }

  Future<bool> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? account = await _googleSignIn.signIn();
      if (account != null) {
        _currentUser = account;
        await _saveUserData(account);
        _authStateController.add(true);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    _currentUser = null;
    await _clearUserData();
    _authStateController.add(false);
  }

  Future<void> _saveUserData(GoogleSignInAccount account) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_id', account.id);
    await prefs.setString('user_email', account.email);
    await prefs.setString('user_name', account.displayName ?? '');
    await prefs.setString('user_photo', account.photoUrl ?? '');
    await prefs.setBool('is_signed_in', true);
  }

  Future<void> _clearUserData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('user_id');
    await prefs.remove('user_email');
    await prefs.remove('user_name');
    await prefs.remove('user_photo');
    await prefs.setBool('is_signed_in', false);
  }

  Future<Map<String, String?>> getSavedUserData() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'id': prefs.getString('user_id'),
      'email': prefs.getString('user_email'),
      'name': prefs.getString('user_name'),
      'photoUrl': prefs.getString('user_photo'),
    };
  }

  Future<bool> checkPreviousSignIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('is_signed_in') ?? false;
  }

  void dispose() {
    _authStateController.close();
  }
}
