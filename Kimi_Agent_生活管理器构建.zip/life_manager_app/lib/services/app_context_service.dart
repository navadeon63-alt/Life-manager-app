import 'storage_service.dart';

class AppContextService {
  static final AppContextService _instance = AppContextService._internal();
  factory AppContextService() => _instance;
  AppContextService._internal();

  final StorageService _storage = StorageService();

  Future<Map<String, dynamic>> getContextSummary() async {
    final tasks = await _storage.getTasks();
    final notes = await _storage.getNotes();
    final finances = await _storage.getFinances();
    final birthdays = await _storage.getBirthdays();

    return {
      'tasks': tasks.map((t) => t.toJson()).toList(),
      'notes': notes.map((n) => n.toJson()).toList(),
      'finances': finances.map((f) => f.toJson()).toList(),
      'birthdays': birthdays.map((b) => b.toJson()).toList(),
      'taskCount': tasks.length,
      'pendingTaskCount': tasks.where((t) => !t.isCompleted).length,
      'noteCount': notes.length,
      'financeCount': finances.length,
      'birthdayCount': birthdays.length,
    };
  }

  Future<Map<String, dynamic>> getDetailedContext() async {
    final summary = await getContextSummary();
    final now = DateTime.now();

    // Add today's info
    summary['today'] = {
      'dayOfWeek': now.weekday,
      'day': now.day,
      'month': now.month,
      'year': now.year,
      'hour': now.hour,
    };

    // Add high priority tasks
    final tasks = await _storage.getTasks();
    summary['highPriorityTasks'] = tasks
        .where((t) => !t.isCompleted && t.priority == 'high')
        .map((t) => t.toJson())
        .toList();

    // Add overdue tasks
    summary['overdueTasks'] = tasks
        .where((t) =>
            !t.isCompleted &&
            t.dueDate != null &&
            t.dueDate!.isBefore(now))
        .map((t) => t.toJson())
        .toList();

    // Add today's birthdays
    final birthdays = await _storage.getBirthdays();
    summary['todaysBirthdays'] = birthdays
        .where((b) =>
            b.birthDate.month == now.month &&
            b.birthDate.day == now.day)
        .map((b) => b.toJson())
        .toList();

    // Add upcoming birthdays (next 7 days)
    summary['upcomingBirthdays'] = birthdays
        .where((b) {
          final nextBirthday = DateTime(now.year, b.birthDate.month, b.birthDate.day);
          final diff = nextBirthday.difference(now).inDays;
          return diff >= 0 && diff <= 7;
        })
        .map((b) => b.toJson())
        .toList();

    // Add finance summary
    final finances = await _storage.getFinances();
    double totalIncome = 0;
    double totalExpense = 0;
    
    // This month's finances
    final thisMonthFinances = finances.where((f) =>
        f.date.month == now.month && f.date.year == now.year);
    
    for (var f in thisMonthFinances) {
      if (f.type == 'income') {
        totalIncome += f.amount;
      } else {
        totalExpense += f.amount;
      }
    }

    summary['financeSummary'] = {
      'totalIncome': totalIncome,
      'totalExpense': totalExpense,
      'balance': totalIncome - totalExpense,
      'month': now.month,
      'year': now.year,
    };

    // Add pinned notes
    final notes = await _storage.getNotes();
    summary['pinnedNotes'] = notes
        .where((n) => n.isPinned)
        .map((n) => n.toJson())
        .toList();

    return summary;
  }

  Future<Map<String, dynamic>> getTaskContext() async {
    final tasks = await _storage.getTasks();
    final now = DateTime.now();

    return {
      'allTasks': tasks.map((t) => t.toJson()).toList(),
      'pendingTasks': tasks.where((t) => !t.isCompleted).map((t) => t.toJson()).toList(),
      'completedTasks': tasks.where((t) => t.isCompleted).map((t) => t.toJson()).toList(),
      'highPriorityTasks': tasks
          .where((t) => !t.isCompleted && t.priority == 'high')
          .map((t) => t.toJson())
          .toList(),
      'overdueTasks': tasks
          .where((t) =>
              !t.isCompleted &&
              t.dueDate != null &&
              t.dueDate!.isBefore(now))
          .map((t) => t.toJson())
          .toList(),
      'tasksDueToday': tasks
          .where((t) =>
              !t.isCompleted &&
              t.dueDate != null &&
              t.dueDate!.year == now.year &&
              t.dueDate!.month == now.month &&
              t.dueDate!.day == now.day)
          .map((t) => t.toJson())
          .toList(),
    };
  }

  Future<Map<String, dynamic>> getFinanceContext() async {
    final finances = await _storage.getFinances();
    final now = DateTime.now();

    double totalIncome = 0;
    double totalExpense = 0;
    Map<String, double> categoryBreakdown = {};

    // This month's data
    final thisMonth = finances.where((f) =>
        f.date.month == now.month && f.date.year == now.year);

    for (var f in thisMonth) {
      if (f.type == 'income') {
        totalIncome += f.amount;
      } else {
        totalExpense += f.amount;
      }

      categoryBreakdown[f.category] =
          (categoryBreakdown[f.category] ?? 0) + f.amount;
    }

    // Last 6 months
    List<Map<String, dynamic>> monthlyData = [];
    for (int i = 0; i < 6; i++) {
      final month = DateTime(now.year, now.month - i, 1);
      final monthFinances = finances.where((f) =>
          f.date.month == month.month && f.date.year == month.year);

      double monthIncome = 0;
      double monthExpense = 0;

      for (var f in monthFinances) {
        if (f.type == 'income') {
          monthIncome += f.amount;
        } else {
          monthExpense += f.amount;
        }
      }

      monthlyData.add({
        'month': month.month,
        'year': month.year,
        'income': monthIncome,
        'expense': monthExpense,
      });
    }

    return {
      'allFinances': finances.map((f) => f.toJson()).toList(),
      'totalIncome': totalIncome,
      'totalExpense': totalExpense,
      'balance': totalIncome - totalExpense,
      'categoryBreakdown': categoryBreakdown,
      'monthlyData': monthlyData,
      'currency': 'ZAR',
    };
  }

  Future<Map<String, dynamic>> getBirthdayContext() async {
    final birthdays = await _storage.getBirthdays();
    final now = DateTime.now();

    return {
      'allBirthdays': birthdays.map((b) => b.toJson()).toList(),
      'todaysBirthdays': birthdays
          .where((b) =>
              b.birthDate.month == now.month &&
              b.birthDate.day == now.day)
          .map((b) => b.toJson())
          .toList(),
      'upcomingBirthdays': birthdays
          .where((b) {
            final nextBirthday = DateTime(now.year, b.birthDate.month, b.birthDate.day);
            if (nextBirthday.isBefore(now)) {
              return false;
            }
            final diff = nextBirthday.difference(now).inDays;
            return diff <= 30;
          })
          .map((b) => {
                ...b.toJson(),
                'daysUntil': b.daysUntilBirthday,
                'age': b.age,
              })
          .toList()
        ..sort((a, b) => (a['daysUntil'] as int).compareTo(b['daysUntil'] as int)),
    };
  }

  Future<Map<String, dynamic>> getNoteContext() async {
    final notes = await _storage.getNotes();

    // Get unique categories
    Set<String> categories = {};
    for (var note in notes) {
      if (note.category != null) {
        categories.add(note.category!);
      }
    }

    return {
      'allNotes': notes.map((n) => n.toJson()).toList(),
      'pinnedNotes': notes.where((n) => n.isPinned).map((n) => n.toJson()).toList(),
      'recentNotes': notes
          .where((n) => !n.isPinned)
          .toList()
          .sublist(0, notes.length > 10 ? 10 : notes.length)
          .map((n) => n.toJson())
          .toList(),
      'categories': categories.toList(),
      'noteCount': notes.length,
    };
  }
}
