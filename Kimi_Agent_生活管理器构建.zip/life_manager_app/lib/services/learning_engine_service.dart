import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'storage_service.dart';

class LearningEngineService {
  static final LearningEngineService _instance = LearningEngineService._internal();
  factory LearningEngineService() => _instance;
  LearningEngineService._internal();

  final StorageService _storage = StorageService();

  // Track feature usage
  Future<void> trackFeatureUsage(String featureName) async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null) {
        final usage = Map<String, int>.from(profile.featureUsage);
        usage[featureName] = (usage[featureName] ?? 0) + 1;
        
        final updatedProfile = profile.copyWith(
          featureUsage: usage,
          lastActive: DateTime.now(),
        );
        await _storage.saveUserProfile(updatedProfile);
      }
    } catch (e) {
      // Silently handle errors
    }
  }

  // Track query patterns
  Future<void> trackQuery(String query) async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null) {
        final queries = List<String>.from(profile.commonQueries);
        queries.add(query.toLowerCase());
        
        // Keep only last 100 queries
        if (queries.length > 100) {
          queries.removeAt(0);
        }
        
        final updatedProfile = profile.copyWith(
          commonQueries: queries,
          lastActive: DateTime.now(),
        );
        await _storage.saveUserProfile(updatedProfile);
      }
    } catch (e) {
      // Silently handle errors
    }
  }

  // Track habit formation
  Future<void> trackHabit(String habitName, String category) async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null) {
        final habits = Map<String, dynamic>.from(profile.habits);
        
        if (!habits.containsKey(habitName)) {
          habits[habitName] = {
            'category': category,
            'frequency': 1,
            'firstSeen': DateTime.now().toIso8601String(),
            'lastSeen': DateTime.now().toIso8601String(),
          };
        } else {
          final habit = Map<String, dynamic>.from(habits[habitName]);
          habit['frequency'] = (habit['frequency'] as int) + 1;
          habit['lastSeen'] = DateTime.now().toIso8601String();
          habits[habitName] = habit;
        }
        
        final updatedProfile = profile.copyWith(
          habits: habits,
          lastActive: DateTime.now(),
        );
        await _storage.saveUserProfile(updatedProfile);
      }
    } catch (e) {
      // Silently handle errors
    }
  }

  // Get most used features
  Future<List<MapEntry<String, int>>> getMostUsedFeatures({int limit = 5}) async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null) {
        final usage = profile.featureUsage.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));
        return usage.take(limit).toList();
      }
    } catch (e) {
      // Silently handle errors
    }
    return [];
  }

  // Get common query patterns
  Future<List<String>> getCommonQueryPatterns() async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null && profile.commonQueries.isNotEmpty) {
        // Count occurrences of each query
        final Map<String, int> queryCounts = {};
        for (var query in profile.commonQueries) {
          queryCounts[query] = (queryCounts[query] ?? 0) + 1;
        }
        
        // Sort by frequency
        final sorted = queryCounts.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));
        
        return sorted.take(10).map((e) => e.key).toList();
      }
    } catch (e) {
      // Silently handle errors
    }
    return [];
  }

  // Get user habits summary
  Future<Map<String, dynamic>> getHabitsSummary() async {
    try {
      final profile = await _storage.getUserProfile();
      if (profile != null) {
        return {
          'habits': profile.habits,
          'totalHabits': profile.habits.length,
          'mostFrequent': _getMostFrequentHabit(profile.habits),
        };
      }
    } catch (e) {
      // Silently handle errors
    }
    return {};
  }

  String? _getMostFrequentHabit(Map<String, dynamic> habits) {
    if (habits.isEmpty) return null;
    
    String? mostFrequent;
    int maxFrequency = 0;
    
    habits.forEach((key, value) {
      final habit = value as Map<String, dynamic>;
      final frequency = habit['frequency'] as int;
      if (frequency > maxFrequency) {
        maxFrequency = frequency;
        mostFrequent = key;
      }
    });
    
    return mostFrequent;
  }

  // Get personalized suggestions based on usage patterns
  Future<List<String>> getPersonalizedSuggestions() async {
    final suggestions = <String>[];
    
    try {
      final profile = await _storage.getUserProfile();
      if (profile == null) return suggestions;

      final featureUsage = profile.featureUsage;
      final habits = profile.habits;

      // Suggest underused features
      if ((featureUsage['tasks'] ?? 0) < 5) {
        suggestions.add('Try adding more tasks to stay organized');
      }
      
      if ((featureUsage['finance'] ?? 0) < 3) {
        suggestions.add('Track your daily expenses to understand your spending');
      }
      
      if ((featureUsage['notes'] ?? 0) < 3) {
        suggestions.add('Use notes to capture ideas and important information');
      }

      // Suggest based on habits
      if (habits.containsKey('late_night_tasks')) {
        suggestions.add('Consider completing tasks earlier for better sleep');
      }

      if (habits.containsKey('weekend_finance_review')) {
        suggestions.add('Great job reviewing finances on weekends!');
      }

      // Time-based suggestions
      final hour = DateTime.now().hour;
      if (hour >= 9 && hour <= 11) {
        suggestions.add('Morning is great for tackling high-priority tasks');
      } else if (hour >= 14 && hour <= 16) {
        suggestions.add('Afternoon slump? Try a quick review of your notes');
      }

    } catch (e) {
      // Silently handle errors
    }

    return suggestions;
  }

  // Get adaptive greeting based on time and usage
  Future<String> getAdaptiveGreeting() async {
    final hour = DateTime.now().hour;
    final profile = await _storage.getUserProfile();
    
    String timeGreeting;
    if (hour < 12) {
      timeGreeting = 'Good morning';
    } else if (hour < 17) {
      timeGreeting = 'Good afternoon';
    } else {
      timeGreeting = 'Good evening';
    }

    if (profile != null) {
      final lastActive = profile.lastActive;
      final daysSinceActive = DateTime.now().difference(lastActive).inDays;
      
      if (daysSinceActive > 7) {
        return '$timeGreeting! Welcome back! It\'s been a while.';
      }
      
      final name = profile.name.split(' ').first;
      return '$timeGreeting, $name!';
    }

    return '$timeGreeting!';
  }

  // Export user data for backup
  Future<String?> exportUserData() async {
    try {
      final profile = await _storage.getUserProfile();
      final tasks = await _storage.getTasks();
      final notes = await _storage.getNotes();
      final finances = await _storage.getFinances();
      final birthdays = await _storage.getBirthdays();

      final exportData = {
        'profile': profile?.toJson(),
        'tasks': tasks.map((t) => t.toJson()).toList(),
        'notes': notes.map((n) => n.toJson()).toList(),
        'finances': finances.map((f) => f.toJson()).toList(),
        'birthdays': birthdays.map((b) => b.toJson()).toList(),
        'exportedAt': DateTime.now().toIso8601String(),
      };

      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/backup_${DateTime.now().millisecondsSinceEpoch}.json');
      await file.writeAsString(jsonEncode(exportData));

      return file.path;
    } catch (e) {
      return null;
    }
  }

  // Import user data from backup
  Future<bool> importUserData(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      final content = await file.readAsString();
      final data = jsonDecode(content);

      // Import profile
      if (data['profile'] != null) {
        // Profile will be handled by user_profile_service
      }

      // Import tasks
      if (data['tasks'] != null) {
        for (var taskJson in data['tasks']) {
          // Tasks will be imported via storage service
        }
      }

      return true;
    } catch (e) {
      return false;
    }
  }
}
