import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/finance.dart';
import '../models/birthday.dart';
import '../models/chat_message.dart';
import '../models/user_profile.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Tasks
  Future<List<Task>> getTasks() async {
    final String? tasksJson = _prefs?.getString('tasks');
    if (tasksJson == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(tasksJson);
      return decoded.map((json) => Task.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveTasks(List<Task> tasks) async {
    final String encoded = jsonEncode(tasks.map((t) => t.toJson()).toList());
    await _prefs?.setString('tasks', encoded);
  }

  Future<void> addTask(Task task) async {
    final tasks = await getTasks();
    tasks.add(task);
    await saveTasks(tasks);
  }

  Future<void> updateTask(Task updatedTask) async {
    final tasks = await getTasks();
    final index = tasks.indexWhere((t) => t.id == updatedTask.id);
    if (index != -1) {
      tasks[index] = updatedTask;
      await saveTasks(tasks);
    }
  }

  Future<void> deleteTask(String id) async {
    final tasks = await getTasks();
    tasks.removeWhere((t) => t.id == id);
    await saveTasks(tasks);
  }

  // Notes
  Future<List<Note>> getNotes() async {
    final String? notesJson = _prefs?.getString('notes');
    if (notesJson == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(notesJson);
      return decoded.map((json) => Note.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveNotes(List<Note> notes) async {
    final String encoded = jsonEncode(notes.map((n) => n.toJson()).toList());
    await _prefs?.setString('notes', encoded);
  }

  Future<void> addNote(Note note) async {
    final notes = await getNotes();
    notes.add(note);
    await saveNotes(notes);
  }

  Future<void> updateNote(Note updatedNote) async {
    final notes = await getNotes();
    final index = notes.indexWhere((n) => n.id == updatedNote.id);
    if (index != -1) {
      notes[index] = updatedNote;
      await saveNotes(notes);
    }
  }

  Future<void> deleteNote(String id) async {
    final notes = await getNotes();
    notes.removeWhere((n) => n.id == id);
    await saveNotes(notes);
  }

  // Finance
  Future<List<Finance>> getFinances() async {
    final String? financesJson = _prefs?.getString('finances');
    if (financesJson == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(financesJson);
      return decoded.map((json) => Finance.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveFinances(List<Finance> finances) async {
    final String encoded = jsonEncode(finances.map((f) => f.toJson()).toList());
    await _prefs?.setString('finances', encoded);
  }

  Future<void> addFinance(Finance finance) async {
    final finances = await getFinances();
    finances.add(finance);
    await saveFinances(finances);
  }

  Future<void> updateFinance(Finance updatedFinance) async {
    final finances = await getFinances();
    final index = finances.indexWhere((f) => f.id == updatedFinance.id);
    if (index != -1) {
      finances[index] = updatedFinance;
      await saveFinances(finances);
    }
  }

  Future<void> deleteFinance(String id) async {
    final finances = await getFinances();
    finances.removeWhere((f) => f.id == id);
    await saveFinances(finances);
  }

  // Birthdays
  Future<List<Birthday>> getBirthdays() async {
    final String? birthdaysJson = _prefs?.getString('birthdays');
    if (birthdaysJson == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(birthdaysJson);
      return decoded.map((json) => Birthday.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveBirthdays(List<Birthday> birthdays) async {
    final String encoded = jsonEncode(birthdays.map((b) => b.toJson()).toList());
    await _prefs?.setString('birthdays', encoded);
  }

  Future<void> addBirthday(Birthday birthday) async {
    final birthdays = await getBirthdays();
    birthdays.add(birthday);
    await saveBirthdays(birthdays);
  }

  Future<void> updateBirthday(Birthday updatedBirthday) async {
    final birthdays = await getBirthdays();
    final index = birthdays.indexWhere((b) => b.id == updatedBirthday.id);
    if (index != -1) {
      birthdays[index] = updatedBirthday;
      await saveBirthdays(birthdays);
    }
  }

  Future<void> deleteBirthday(String id) async {
    final birthdays = await getBirthdays();
    birthdays.removeWhere((b) => b.id == id);
    await saveBirthdays(birthdays);
  }

  // Chat Messages
  Future<List<ChatMessage>> getChatMessages() async {
    final String? messagesJson = _prefs?.getString('chat_messages');
    if (messagesJson == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(messagesJson);
      return decoded.map((json) => ChatMessage.fromJson(json)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveChatMessages(List<ChatMessage> messages) async {
    final String encoded = jsonEncode(messages.map((m) => m.toJson()).toList());
    await _prefs?.setString('chat_messages', encoded);
  }

  Future<void> addChatMessage(ChatMessage message) async {
    final messages = await getChatMessages();
    messages.add(message);
    await saveChatMessages(messages);
  }

  Future<void> clearChatMessages() async {
    await _prefs?.remove('chat_messages');
  }

  // User Profile
  Future<UserProfile?> getUserProfile() async {
    final String? profileJson = _prefs?.getString('user_profile');
    if (profileJson == null) return null;
    try {
      return UserProfile.fromJson(jsonDecode(profileJson));
    } catch (e) {
      return null;
    }
  }

  Future<void> saveUserProfile(UserProfile profile) async {
    final String encoded = jsonEncode(profile.toJson());
    await _prefs?.setString('user_profile', encoded);
  }

  // Image Storage
  Future<String?> saveImage(File imageFile, String fileName) async {
    try {
      final Directory appDir = await getApplicationDocumentsDirectory();
      final String imagesPath = '${appDir.path}/images';
      await Directory(imagesPath).create(recursive: true);
      final String filePath = '$imagesPath/$fileName';
      await imageFile.copy(filePath);
      return filePath;
    } catch (e) {
      return null;
    }
  }

  Future<void> deleteImage(String? imagePath) async {
    if (imagePath == null) return;
    try {
      final file = File(imagePath);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      // Ignore deletion errors
    }
  }

  // Clear all data
  Future<void> clearAllData() async {
    await _prefs?.clear();
  }

  // Settings
  Future<void> setSetting(String key, dynamic value) async {
    if (value is String) {
      await _prefs?.setString(key, value);
    } else if (value is bool) {
      await _prefs?.setBool(key, value);
    } else if (value is int) {
      await _prefs?.setInt(key, value);
    } else if (value is double) {
      await _prefs?.setDouble(key, value);
    }
  }

  dynamic getSetting(String key) {
    return _prefs?.get(key);
  }

  Future<void> removeSetting(String key) async {
    await _prefs?.remove(key);
  }
}
