import 'dart:async';
import 'connectivity_service.dart';
import 'online_ai_service.dart';
import 'local_ai_service.dart';
import 'app_context_service.dart';
import '../models/chat_message.dart';

class AIService {
  static final AIService _instance = AIService._internal();
  factory AIService() => _instance;
  AIService._internal();

  final ConnectivityService _connectivity = ConnectivityService();
  final OnlineAIService _onlineAI = OnlineAIService();
  final LocalAIService _localAI = LocalAIService();
  final AppContextService _appContext = AppContextService();

  final StreamController<ChatMessage> _messageController =
      StreamController<ChatMessage>.broadcast();
  Stream<ChatMessage> get messageStream => _messageController.stream;

  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  Future<void> init() async {
    await _onlineAI.init();
    await _localAI.init();
  }

  Future<ChatMessage> sendMessage(
    String message, {
    String? imagePath,
  }) async {
    _isProcessing = true;

    try {
      final context = await _appContext.getContextSummary();
      final isOnline = await _connectivity.checkConnection();

      ChatMessage response;

      if (isOnline) {
        response = await _onlineAI.sendMessage(
          message,
          context: context,
          imagePath: imagePath,
        );
      } else {
        response = await _localAI.sendMessage(
          message,
          context: context,
        );
      }

      _messageController.add(response);
      return response;
    } finally {
      _isProcessing = false;
    }
  }

  Future<String> getDailyBriefing() async {
    final isOnline = await _connectivity.checkConnection();
    final context = await _appContext.getDetailedContext();

    if (isOnline) {
      return await _onlineAI.generateDailyBriefing(context);
    } else {
      return _localAI.generateOfflineBriefing(context);
    }
  }

  Future<List<String>> getSuggestions(String category) async {
    final isOnline = await _connectivity.checkConnection();

    if (isOnline) {
      return await _onlineAI.getSuggestions(category);
    } else {
      return _localAI.getOfflineSuggestions(category);
    }
  }

  void dispose() {
    _messageController.close();
  }
}
