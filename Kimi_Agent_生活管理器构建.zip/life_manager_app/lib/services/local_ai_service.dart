import 'dart:math';
import '../models/chat_message.dart';
import 'package:uuid/uuid.dart';

class LocalAIService {
  static final LocalAIService _instance = LocalAIService._internal();
  factory LocalAIService() => _instance;
  LocalAIService._internal();

  final Uuid _uuid = const Uuid();
  final Random _random = Random();

  Future<void> init() async {
    // No initialization needed for keyword-based system
  }

  Future<ChatMessage> sendMessage(
    String message, {
    Map<String, dynamic>? context,
  }) async {
    final response = _generateResponse(message, context);

    return ChatMessage(
      id: _uuid.v4(),
      content: response,
      isUser: false,
      timestamp: DateTime.now(),
      isOffline: true,
    );
  }

  String _generateResponse(String message, Map<String, dynamic>? context) {
    final lowerMessage = message.toLowerCase();

    // Task-related queries
    if (_containsAny(lowerMessage, ['task', 'todo', 'to do', 'work', 'job'])) {
      return _getTaskResponse(lowerMessage, context);
    }

    // Note-related queries
    if (_containsAny(lowerMessage, ['note', 'write', 'remember', 'save'])) {
      return _getNoteResponse(lowerMessage, context);
    }

    // Finance-related queries
    if (_containsAny(lowerMessage, [
      'money',
      'finance',
      'budget',
      'expense',
      'income',
      'zar',
      'rand',
      'cost',
      'price'
    ])) {
      return _getFinanceResponse(lowerMessage, context);
    }

    // Birthday-related queries
    if (_containsAny(lowerMessage, ['birthday', 'birth date', 'celebrate'])) {
      return _getBirthdayResponse(lowerMessage, context);
    }

    // Greeting queries
    if (_containsAny(lowerMessage, ['hello', 'hi', 'hey', 'good morning', 'good afternoon'])) {
      return _getGreetingResponse();
    }

    // Help queries
    if (_containsAny(lowerMessage, ['help', 'assist', 'support', 'how to'])) {
      return _getHelpResponse();
    }

    // Weather queries (common but offline)
    if (_containsAny(lowerMessage, ['weather', 'rain', 'sunny', 'temperature'])) {
      return "I'm currently offline, so I can't check the weather. Please connect to the internet for real-time weather updates, or check your device's weather app.";
    }

    // Time/Date queries
    if (_containsAny(lowerMessage, ['time', 'date', 'day', 'month'])) {
      final now = DateTime.now();
      return "It's currently ${now.hour}:${now.minute.toString().padLeft(2, '0')} on ${_getDayName(now.weekday)}, ${now.day} ${_getMonthName(now.month)} ${now.year}.";
    }

    // Motivation/Encouragement
    if (_containsAny(lowerMessage, ['motivate', 'inspire', 'encourage', 'sad', 'depressed'])) {
      return _getMotivationalResponse();
    }

    // Default response
    return _getDefaultResponse();
  }

  String _getTaskResponse(String message, Map<String, dynamic>? context) {
    final responses = [
      "I see you're working on tasks! While offline, I can help you organize your thoughts. Try breaking large tasks into smaller, manageable steps. Would you like to add a new task when you're back online?",
      "Task management is key to productivity! Since I'm offline, I recommend prioritizing your tasks by urgency and importance. The Eisenhower Matrix is a great tool for this.",
      "Keep up the good work with your tasks! When you're back online, I can help you set reminders and deadlines for better task management.",
      "Tasks can feel overwhelming sometimes. Try the '2-minute rule' - if a task takes less than 2 minutes, do it now!",
    ];

    if (message.contains('add') || message.contains('create') || message.contains('new')) {
      return "To add a new task, go to the Tasks tab and tap the + button. You can set a title, description, due date, and priority. I'll remind you when it's due!";
    }

    if (message.contains('complete') || message.contains('done') || message.contains('finish')) {
      return "Great job working on completing tasks! Mark them as done by tapping the checkbox. Completed tasks help you track your progress.";
    }

    if (message.contains('priority') || message.contains('important')) {
      return "Prioritize tasks by marking them as High, Medium, or Low priority. Focus on high-priority tasks first for maximum productivity!";
    }

    return responses[_random.nextInt(responses.length)];
  }

  String _getNoteResponse(String message, Map<String, dynamic>? context) {
    final responses = [
      "Notes are great for capturing ideas! When offline, your notes are still saved locally and will sync when you're back online.",
      "Jotting down notes helps clear your mind. Try using categories to organize your notes better.",
      "Your notes are safely stored on your device even while offline. You can add images to notes for better context too!",
    ];

    if (message.contains('add') || message.contains('create') || message.contains('new')) {
      return "To create a new note, go to the Notes tab and tap the + button. You can add a title, content, and even attach photos!";
    }

    return responses[_random.nextInt(responses.length)];
  }

  String _getFinanceResponse(String message, Map<String, dynamic>? context) {
    final responses = [
      "Managing finances in ZAR! Track your income and expenses to understand your spending patterns. Small savings add up over time!",
      "Financial awareness is the first step to financial freedom. Keep track of every transaction, no matter how small.",
      "Budgeting tip: Try the 50/30/20 rule - 50% for needs, 30% for wants, and 20% for savings and debt repayment.",
    ];

    if (message.contains('expense') || message.contains('spend')) {
      return "Track your expenses by category to see where your money goes. Common categories include Food, Transport, Entertainment, and Bills.";
    }

    if (message.contains('income') || message.contains('earn')) {
      return "Great job tracking your income! Compare your income vs expenses to ensure you're living within your means.";
    }

    if (message.contains('budget') || message.contains('save')) {
      return "Creating a budget helps you control your spending. Set monthly limits for different categories and try to stick to them!";
    }

    return responses[_random.nextInt(responses.length)];
  }

  String _getBirthdayResponse(String message, Map<String, dynamic>? context) {
    final responses = [
      "Birthdays are special! I'll remind you of upcoming birthdays so you never miss celebrating with loved ones.",
      "Never forget a birthday again! Add birthdays with reminder settings to get notified in advance.",
      "Birthday reminders help you plan ahead. You can set how many days before you want to be notified.",
    ];

    if (message.contains('add') || message.contains('new')) {
      return "To add a birthday, go to the Birthdays tab and tap the + button. Add the person's name, birth date, and set reminder preferences.";
    }

    return responses[_random.nextInt(responses.length)];
  }

  String _getGreetingResponse() {
    final hour = DateTime.now().hour;
    String timeGreeting;

    if (hour < 12) {
      timeGreeting = "Good morning";
    } else if (hour < 17) {
      timeGreeting = "Good afternoon";
    } else {
      timeGreeting = "Good evening";
    }

    final responses = [
      "$timeGreeting! I'm currently in offline mode, but I'm still here to help with your tasks, notes, finances, and birthdays. What would you like to work on?",
      "$timeGreeting! Welcome to Life Manager. I'm running offline right now, but I can still assist you with pre-programmed responses. How can I help you today?",
      "$timeGreeting! I'm your offline assistant today. I can help you with task management, note-taking, finance tracking, and birthday reminders. What do you need?",
    ];

    return responses[_random.nextInt(responses.length)];
  }

  String _getHelpResponse() {
    return """I'm currently offline, but here's how I can help:

📋 **Tasks** - Create, manage, and track your daily tasks with priorities and due dates

📝 **Notes** - Keep important information organized with categories

💰 **Finance** - Track income and expenses in ZAR currency

🎂 **Birthdays** - Never forget important dates with reminders

🤖 **AI Assistant** - Get help with various topics (full features when online)

To use any feature, tap the corresponding tab at the bottom of the screen. Connect to the internet for enhanced AI capabilities!""";
  }

  String _getMotivationalResponse() {
    final quotes = [
      "Believe you can and you're halfway there. - Theodore Roosevelt",
      "The only way to do great work is to love what you do. - Steve Jobs",
      "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
      "Your time is limited, don't waste it living someone else's life. - Steve Jobs",
      "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
      "It does not matter how slowly you go as long as you do not stop. - Confucius",
      "Everything you've ever wanted is on the other side of fear. - George Addair",
      "Hardships often prepare ordinary people for an extraordinary destiny. - C.S. Lewis",
    ];

    return "Here's some motivation for you:\n\n${quotes[_random.nextInt(quotes.length)]}\n\nRemember, every small step counts towards your goals! 💪";
  }

  String _getDefaultResponse() {
    final responses = [
      "I'm currently offline, so my responses are limited. I can help with tasks, notes, finances, and birthdays. For more advanced assistance, please connect to the internet.",
      "I'm running in offline mode right now. I can provide basic help with your life management tasks. Connect online for full AI capabilities!",
      "Thanks for your message! I'm offline at the moment but can assist with pre-programmed responses about tasks, notes, finance, and birthdays.",
      "I'm in offline mode, which means I have limited capabilities. For the best experience, connect to the internet to access Gemini AI features!",
    ];

    return responses[_random.nextInt(responses.length)];
  }

  String generateOfflineBriefing(Map<String, dynamic> context) {
    final tasks = context['tasks'] as List<dynamic>? ?? [];
    final birthdays = context['birthdays'] as List<dynamic>? ?? [];
    final notes = context['notes'] as List<dynamic>? ?? [];

    final pendingTasks = tasks.where((t) => !(t['isCompleted'] ?? false)).toList();
    final todayBirthdays = birthdays.where((b) {
      final birthDate = DateTime.parse(b['birthDate']);
      final now = DateTime.now();
      return birthDate.month == now.month && birthDate.day == now.day;
    }).toList();

    StringBuffer briefing = StringBuffer();
    briefing.writeln("📅 **Daily Briefing (Offline Mode)**\n");

    // Tasks section
    briefing.writeln("📋 **Tasks**");
    if (pendingTasks.isEmpty) {
      briefing.writeln("No pending tasks! Great job! ✨");
    } else {
      briefing.writeln("You have ${pendingTasks.length} pending task(s):");
      for (var i = 0; i < pendingTasks.length && i < 5; i++) {
        briefing.writeln("• ${pendingTasks[i]['title']}");
      }
      if (pendingTasks.length > 5) {
        briefing.writeln("... and ${pendingTasks.length - 5} more");
      }
    }
    briefing.writeln();

    // Birthdays section
    briefing.writeln("🎂 **Birthdays**");
    if (todayBirthdays.isEmpty) {
      briefing.writeln("No birthdays today.");
    } else {
      briefing.writeln("Today's birthdays:");
      for (var birthday in todayBirthdays) {
        briefing.writeln("• ${birthday['name']} 🎉");
      }
    }
    briefing.writeln();

    // Notes section
    briefing.writeln("📝 **Notes**");
    if (notes.isEmpty) {
      briefing.writeln("No notes yet.");
    } else {
      briefing.writeln("You have ${notes.length} note(s).");
    }
    briefing.writeln();

    briefing.writeln("💡 *Connect to the internet for AI-powered insights and suggestions!*");

    return briefing.toString();
  }

  List<String> getOfflineSuggestions(String category) {
    final suggestions = {
      'tasks': [
        'Break large tasks into smaller steps',
        'Set specific deadlines for each task',
        'Prioritize tasks by importance',
        'Use the 2-minute rule for quick tasks',
        'Review and update your task list daily',
      ],
      'finance': [
        'Track every expense, no matter how small',
        'Create a monthly budget and stick to it',
        'Set aside 20% of income for savings',
        'Review your subscriptions regularly',
        'Compare prices before making purchases',
      ],
      'notes': [
        'Use categories to organize notes',
        'Add images for better context',
        'Review notes weekly',
        'Pin important notes for quick access',
        'Keep daily journaling notes',
      ],
      'birthdays': [
        'Set reminders a week in advance',
        'Plan gifts early',
        'Keep a gift ideas list',
        'Note favorite things for each person',
        'Schedule time to celebrate',
      ],
    };

    return suggestions[category.toLowerCase()] ?? [
      'Stay organized with regular reviews',
      'Set achievable daily goals',
      'Take breaks to maintain productivity',
      'Celebrate small wins',
      'Keep learning and improving',
    ];
  }

  bool _containsAny(String text, List<String> keywords) {
    return keywords.any((keyword) => text.contains(keyword));
  }

  String _getDayName(int weekday) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return days[weekday - 1];
  }

  String _getMonthName(int month) {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[month - 1];
  }
}
