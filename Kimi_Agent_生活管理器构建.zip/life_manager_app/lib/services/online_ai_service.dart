import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';
import '../core/constants.dart';
import 'package:uuid/uuid.dart';

class OnlineAIService {
  static final OnlineAIService _instance = OnlineAIService._internal();
  factory OnlineAIService() => _instance;
  OnlineAIService._internal();

  final Uuid _uuid = const Uuid();
  final String _apiKey = Constants.geminiApiKey;
  final String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

  Future<void> init() async {
    // Initialize online AI service
  }

  Future<ChatMessage> sendMessage(
    String message, {
    Map<String, dynamic>? context,
    String? imagePath,
  }) async {
    try {
      final response = await _callGeminiAPI(
        message,
        context: context,
        imagePath: imagePath,
      );

      return ChatMessage(
        id: _uuid.v4(),
        content: response,
        isUser: false,
        timestamp: DateTime.now(),
        isOffline: false,
      );
    } catch (e) {
      return ChatMessage(
        id: _uuid.v4(),
        content:
            "I'm having trouble connecting to the AI service. Please try again later. Error: $e",
        isUser: false,
        timestamp: DateTime.now(),
        isOffline: false,
      );
    }
  }

  Future<String> _callGeminiAPI(
    String message, {
    Map<String, dynamic>? context,
    String? imagePath,
  }) async {
    final url = '$_baseUrl?key=$_apiKey';

    String systemPrompt = _buildSystemPrompt(context);

    List<Map<String, dynamic>> contents = [];

    // Add system prompt as first content
    contents.add({
      'role': 'user',
      'parts': [
        {'text': systemPrompt}
      ]
    });

    contents.add({
      'role': 'model',
      'parts': [
        {
          'text':
              'I understand. I will act as a helpful life management assistant for this user.'
        }
      ]
    });

    // Build user message parts
    List<Map<String, dynamic>> userParts = [];
    userParts.add({'text': message});

    // Add image if provided
    if (imagePath != null) {
      final imageBytes = await File(imagePath).readAsBytes();
      final base64Image = base64Encode(imageBytes);
      userParts.add({
        'inline_data': {
          'mime_type': 'image/jpeg',
          'data': base64Image,
        }
      });
    }

    contents.add({
      'role': 'user',
      'parts': userParts,
    });

    final body = {
      'contents': contents,
      'generationConfig': {
        'temperature': 0.7,
        'topK': 40,
        'topP': 0.95,
        'maxOutputTokens': 2048,
      },
      'safetySettings': [
        {
          'category': 'HARM_CATEGORY_HARASSMENT',
          'threshold': 'BLOCK_MEDIUM_AND_ABOVE'
        },
        {
          'category': 'HARM_CATEGORY_HATE_SPEECH',
          'threshold': 'BLOCK_MEDIUM_AND_ABOVE'
        },
        {
          'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
          'threshold': 'BLOCK_MEDIUM_AND_ABOVE'
        },
        {
          'category': 'HARM_CATEGORY_DANGEROUS_CONTENT',
          'threshold': 'BLOCK_MEDIUM_AND_ABOVE'
        }
      ]
    };

    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final candidates = data['candidates'] as List<dynamic>?;

      if (candidates != null && candidates.isNotEmpty) {
        final content = candidates[0]['content'];
        final parts = content['parts'] as List<dynamic>?;

        if (parts != null && parts.isNotEmpty) {
          return parts[0]['text'] ?? 'No response generated';
        }
      }
      return 'Sorry, I could not generate a response.';
    } else {
      throw Exception('API Error: ${response.statusCode} - ${response.body}');
    }
  }

  String _buildSystemPrompt(Map<String, dynamic>? context) {
    StringBuffer prompt = StringBuffer();

    prompt.writeln(
        'You are a helpful AI assistant for the Life Manager app. You help users with task management, note-taking, finance tracking, and birthday reminders.');
    prompt.writeln();
    prompt.writeln('Guidelines:');
    prompt.writeln('- Be concise but helpful');
    prompt.writeln('- Use emojis where appropriate');
    prompt.writeln('- Provide actionable advice');
    prompt.writeln('- Be encouraging and supportive');
    prompt.writeln('- Format responses with clear sections when needed');
    prompt.writeln();

    if (context != null) {
      prompt.writeln('User Context:');

      final tasks = context['tasks'] as List<dynamic>?;
      if (tasks != null && tasks.isNotEmpty) {
        final pendingTasks = tasks.where((t) => !(t['isCompleted'] ?? false)).toList();
        prompt.writeln('- Has ${pendingTasks.length} pending tasks');
      }

      final notes = context['notes'] as List<dynamic>?;
      if (notes != null) {
        prompt.writeln('- Has ${notes.length} notes');
      }

      final finances = context['finances'] as List<dynamic>?;
      if (finances != null && finances.isNotEmpty) {
        prompt.writeln('- Has finance records');
      }

      final birthdays = context['birthdays'] as List<dynamic>?;
      if (birthdays != null && birthdays.isNotEmpty) {
        prompt.writeln('- Has ${birthdays.length} birthdays saved');
      }

      prompt.writeln();
    }

    prompt.writeln('Respond to the user\'s message helpfully.');

    return prompt.toString();
  }

  Future<String> generateDailyBriefing(Map<String, dynamic> context) async {
    try {
      final url = '$_baseUrl?key=$_apiKey';

      StringBuffer briefingPrompt = StringBuffer();
      briefingPrompt.writeln('Generate a friendly daily briefing for the user.');
      briefingPrompt.writeln();

      final tasks = context['tasks'] as List<dynamic>? ?? [];
      final pendingTasks = tasks.where((t) => !(t['isCompleted'] ?? false)).toList();
      final highPriorityTasks = pendingTasks.where((t) => t['priority'] == 'high').toList();

      briefingPrompt.writeln('Tasks: ${pendingTasks.length} pending (${highPriorityTasks.length} high priority)');

      final birthdays = context['birthdays'] as List<dynamic>? ?? [];
      final now = DateTime.now();
      final todayBirthdays = birthdays.where((b) {
        final birthDate = DateTime.parse(b['birthDate']);
        return birthDate.month == now.month && birthDate.day == now.day;
      }).toList();
      final upcomingBirthdays = birthdays.where((b) {
        final birthDate = DateTime.parse(b['birthDate']);
        final nextBirthday = DateTime(now.year, birthDate.month, birthDate.day);
        final diff = nextBirthday.difference(now).inDays;
        return diff > 0 && diff <= 7;
      }).toList();

      briefingPrompt.writeln('Birthdays: ${todayBirthdays.length} today, ${upcomingBirthdays.length} this week');

      final finances = context['finances'] as List<dynamic>? ?? [];
      if (finances.isNotEmpty) {
        double totalIncome = 0;
        double totalExpense = 0;
        for (var f in finances) {
          if (f['type'] == 'income') {
            totalIncome += (f['amount'] as num).toDouble();
          } else {
            totalExpense += (f['amount'] as num).toDouble();
          }
        }
        briefingPrompt.writeln('Finance: R${totalIncome.toStringAsFixed(2)} income, R${totalExpense.toStringAsFixed(2)} expenses');
      }

      briefingPrompt.writeln();
      briefingPrompt.writeln('Format the briefing with emojis, clear sections, and an encouraging tone. Include a motivational quote at the end.');

      final body = {
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': briefingPrompt.toString()}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.8,
          'maxOutputTokens': 1024,
        }
      };

      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final candidates = data['candidates'] as List<dynamic>?;

        if (candidates != null && candidates.isNotEmpty) {
          final content = candidates[0]['content'];
          final parts = content['parts'] as List<dynamic>?;

          if (parts != null && parts.isNotEmpty) {
            return parts[0]['text'] ?? _generateOfflineBriefing(context);
          }
        }
      }

      return _generateOfflineBriefing(context);
    } catch (e) {
      return _generateOfflineBriefing(context);
    }
  }

  String _generateOfflineBriefing(Map<String, dynamic> context) {
    final tasks = context['tasks'] as List<dynamic>? ?? [];
    final pendingTasks = tasks.where((t) => !(t['isCompleted'] ?? false)).toList();

    StringBuffer briefing = StringBuffer();
    briefing.writeln('📅 **Daily Briefing**\n');
    briefing.writeln('📋 **Tasks**: ${pendingTasks.length} pending');
    briefing.writeln('🎂 **Birthdays**: Check the Birthdays tab');
    briefing.writeln('💰 **Finance**: Track your daily expenses');
    briefing.writeln('\n✨ *Have a productive day!*');

    return briefing.toString();
  }

  Future<List<String>> getSuggestions(String category) async {
    try {
      final url = '$_baseUrl?key=$_apiKey';

      String prompt;
      switch (category.toLowerCase()) {
        case 'tasks':
          prompt =
              'Give me 5 practical productivity tips for task management. Return as a simple numbered list, one tip per line.';
          break;
        case 'finance':
          prompt =
              'Give me 5 practical money management tips for personal finance in South Africa (ZAR). Return as a simple numbered list, one tip per line.';
          break;
        case 'notes':
          prompt =
              'Give me 5 tips for effective note-taking and organization. Return as a simple numbered list, one tip per line.';
          break;
        case 'birthdays':
          prompt =
              'Give me 5 thoughtful ways to celebrate birthdays and remember them. Return as a simple numbered list, one tip per line.';
          break;
        default:
          prompt =
              'Give me 5 general life management tips. Return as a simple numbered list, one tip per line.';
      }

      final body = {
        'contents': [
          {
            'role': 'user',
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.7,
          'maxOutputTokens': 512,
        }
      };

      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final candidates = data['candidates'] as List<dynamic>?;

        if (candidates != null && candidates.isNotEmpty) {
          final content = candidates[0]['content'];
          final parts = content['parts'] as List<dynamic>?;

          if (parts != null && parts.isNotEmpty) {
            final text = parts[0]['text'] as String;
            return text
                .split('\n')
                .where((line) => line.trim().isNotEmpty)
                .map((line) => line.replaceAll(RegExp(r'^\d+\.\s*'), '').trim())
                .where((line) => line.isNotEmpty)
                .toList();
          }
        }
      }

      return _getDefaultSuggestions(category);
    } catch (e) {
      return _getDefaultSuggestions(category);
    }
  }

  List<String> _getDefaultSuggestions(String category) {
    final suggestions = {
      'tasks': [
        'Break large tasks into smaller, actionable steps',
        'Use the Eisenhower Matrix to prioritize by urgency and importance',
        'Set specific deadlines for each task',
        'Review your task list at the start and end of each day',
        'Celebrate completing tasks to stay motivated',
      ],
      'finance': [
        'Track every expense to understand your spending patterns',
        'Create a budget using the 50/30/20 rule',
        'Build an emergency fund of 3-6 months expenses',
        'Review and cancel unused subscriptions',
        'Set up automatic transfers to savings',
      ],
      'notes': [
        'Use categories to organize your notes',
        'Review and update notes regularly',
        'Include dates and context in your notes',
        'Use bullet points for better readability',
        'Pin important notes for quick access',
      ],
      'birthdays': [
        'Set reminders a week in advance',
        'Keep a list of gift ideas for each person',
        'Schedule time to celebrate or call',
        'Note important preferences for each person',
        'Plan group celebrations when possible',
      ],
    };

    return suggestions[category.toLowerCase()] ?? [
      'Set clear goals for each day',
      'Take regular breaks to maintain focus',
      'Review your progress weekly',
      'Stay organized with consistent routines',
      'Celebrate your achievements',
    ];
  }
}
