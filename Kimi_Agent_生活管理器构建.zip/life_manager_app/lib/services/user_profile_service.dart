import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/user_profile.dart';
import 'storage_service.dart';
import 'auth_service.dart';

class UserProfileService {
  static final UserProfileService _instance = UserProfileService._internal();
  factory UserProfileService() => _instance;
  UserProfileService._internal();

  final StorageService _storage = StorageService();
  final AuthService _auth = AuthService();

  UserProfile? _currentProfile;
  UserProfile? get currentProfile => _currentProfile;

  Future<void> init() async {
    await _loadProfile();
  }

  Future<void> _loadProfile() async {
    _currentProfile = await _storage.getUserProfile();
    
    // If no profile exists but user is signed in, create one
    if (_currentProfile == null && _auth.isSignedIn) {
      final user = _auth.currentUser;
      if (user != null) {
        await createProfile(
          id: user.id,
          name: user.displayName ?? 'User',
          email: user.email,
          photoUrl: user.photoUrl,
        );
      }
    }
  }

  Future<UserProfile> createProfile({
    required String id,
    required String name,
    required String email,
    String? photoUrl,
  }) async {
    final now = DateTime.now();
    final profile = UserProfile(
      id: id,
      name: name,
      email: email,
      photoUrl: photoUrl,
      createdAt: now,
      lastActive: now,
      preferences: {
        'darkMode': true,
        'notificationsEnabled': true,
        'dailyBriefingTime': '08:00',
        'currency': 'ZAR',
      },
      habits: {},
      featureUsage: {},
      commonQueries: [],
      aiInteractions: {},
    );

    await _storage.saveUserProfile(profile);
    _currentProfile = profile;
    return profile;
  }

  Future<void> updateProfile(UserProfile updatedProfile) async {
    await _storage.saveUserProfile(updatedProfile);
    _currentProfile = updatedProfile;
  }

  Future<void> updateName(String name) async {
    if (_currentProfile != null) {
      final updated = _currentProfile!.copyWith(
        name: name,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> updatePhotoUrl(String? photoUrl) async {
    if (_currentProfile != null) {
      final updated = _currentProfile!.copyWith(
        photoUrl: photoUrl,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> updatePreference(String key, dynamic value) async {
    if (_currentProfile != null) {
      final preferences = Map<String, dynamic>.from(_currentProfile!.preferences);
      preferences[key] = value;
      
      final updated = _currentProfile!.copyWith(
        preferences: preferences,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  dynamic getPreference(String key, {dynamic defaultValue}) {
    if (_currentProfile != null) {
      return _currentProfile!.preferences[key] ?? defaultValue;
    }
    return defaultValue;
  }

  Future<void> trackFeatureUsage(String featureName) async {
    if (_currentProfile != null) {
      final usage = Map<String, int>.from(_currentProfile!.featureUsage);
      usage[featureName] = (usage[featureName] ?? 0) + 1;
      
      final updated = _currentProfile!.copyWith(
        featureUsage: usage,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> trackQuery(String query) async {
    if (_currentProfile != null) {
      final queries = List<String>.from(_currentProfile!.commonQueries);
      queries.add(query.toLowerCase());
      
      // Keep only last 100 queries
      if (queries.length > 100) {
        queries.removeAt(0);
      }
      
      final updated = _currentProfile!.copyWith(
        commonQueries: queries,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> trackHabit(String habitName, String category) async {
    if (_currentProfile != null) {
      final habits = Map<String, dynamic>.from(_currentProfile!.habits);
      
      if (!habits.containsKey(habitName)) {
        habits[habitName] = {
          'category': category,
          'frequency': 1,
          'firstSeen': DateTime.now().toIso8601String(),
          'lastSeen': DateTime.now().toIso8601String(),
        };
      } else {
        final habit = Map<String, dynamic>.from(habits[habitName]);
        habit['frequency'] = (habit['frequency'] as int) + 1;
        habit['lastSeen'] = DateTime.now().toIso8601String();
        habits[habitName] = habit;
      }
      
      final updated = _currentProfile!.copyWith(
        habits: habits,
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> updateLastActive() async {
    if (_currentProfile != null) {
      final updated = _currentProfile!.copyWith(
        lastActive: DateTime.now(),
      );
      await updateProfile(updated);
    }
  }

  Future<void> deleteProfile() async {
    await _storage.setSetting('user_profile', null);
    _currentProfile = null;
  }

  // Export profile to JSON file
  Future<String?> exportProfile() async {
    if (_currentProfile == null) return null;

    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/user_profile.json');
      
      final exportData = {
        'profile': _currentProfile!.toJson(),
        'exportedAt': DateTime.now().toIso8601String(),
      };
      
      await file.writeAsString(jsonEncode(exportData));
      return file.path;
    } catch (e) {
      return null;
    }
  }

  // Import profile from JSON file
  Future<bool> importProfile(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      final content = await file.readAsString();
      final data = jsonDecode(content);

      if (data['profile'] != null) {
        final profile = UserProfile.fromJson(data['profile']);
        await updateProfile(profile);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // Get profile statistics
  Map<String, dynamic> getProfileStats() {
    if (_currentProfile == null) return {};

    final now = DateTime.now();
    final daysSinceCreated = now.difference(_currentProfile!.createdAt).inDays;
    
    return {
      'daysActive': daysSinceCreated,
      'totalFeaturesUsed': _currentProfile!.featureUsage.values.fold(0, (a, b) => a + b),
      'mostUsedFeature': _getMostUsedFeature(),
      'totalHabits': _currentProfile!.habits.length,
      'totalQueries': _currentProfile!.commonQueries.length,
    };
  }

  String? _getMostUsedFeature() {
    if (_currentProfile == null || _currentProfile!.featureUsage.isEmpty) {
      return null;
    }

    final sorted = _currentProfile!.featureUsage.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sorted.first.key;
  }

  // Get personalized recommendations
  List<String> getRecommendations() {
    final recommendations = <String>[];
    
    if (_currentProfile == null) return recommendations;

    final usage = _currentProfile!.featureUsage;
    
    // Feature-based recommendations
    if ((usage['tasks'] ?? 0) == 0) {
      recommendations.add('Start using Tasks to organize your daily activities');
    }
    
    if ((usage['finance'] ?? 0) < 5) {
      recommendations.add('Track your expenses regularly to build better financial habits');
    }
    
    if ((usage['notes'] ?? 0) < 3) {
      recommendations.add('Use Notes to capture important ideas and information');
    }

    // Habit-based recommendations
    if (_currentProfile!.habits.isEmpty) {
      recommendations.add('Regular app usage helps build productive habits');
    }

    return recommendations;
  }

  // Get adaptive greeting
  String getAdaptiveGreeting() {
    final hour = DateTime.now().hour;
    String timeGreeting;
    
    if (hour < 12) {
      timeGreeting = 'Good morning';
    } else if (hour < 17) {
      timeGreeting = 'Good afternoon';
    } else {
      timeGreeting = 'Good evening';
    }

    if (_currentProfile != null) {
      final name = _currentProfile!.name.split(' ').first;
      return '$timeGreeting, $name!';
    }

    return '$timeGreeting!';
  }
}
