class Constants {
  // App Info
  static const String appName = 'Life Manager';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'Your personal life management companion';

  // API Keys - Replace with your actual API key
  static const String geminiApiKey = 'YOUR_GEMINI_API_KEY_HERE';

  // Currency
  static const String defaultCurrency = 'ZAR';
  static const String currencySymbol = 'R';

  // Storage Keys
  static const String keyTasks = 'tasks';
  static const String keyNotes = 'notes';
  static const String keyFinances = 'finances';
  static const String keyBirthdays = 'birthdays';
  static const String keyUserProfile = 'user_profile';
  static const String keyChatMessages = 'chat_messages';
  static const String keySettings = 'settings';
  static const String keyIsSignedIn = 'is_signed_in';

  // Notification Channels
  static const String channelId = 'life_manager_channel';
  static const String channelName = 'Life Manager Notifications';
  static const String channelDescription = 'Notifications for Life Manager app';

  // Feature Names for Analytics
  static const String featureTasks = 'tasks';
  static const String featureNotes = 'notes';
  static const String featureFinance = 'finance';
  static const String featureBirthdays = 'birthdays';
  static const String featureAssistant = 'assistant';
  static const String featureSettings = 'settings';

  // Priority Levels
  static const String priorityHigh = 'high';
  static const String priorityMedium = 'medium';
  static const String priorityLow = 'low';

  // Transaction Types
  static const String typeIncome = 'income';
  static const String typeExpense = 'expense';

  // Default Categories
  static const List<String> incomeCategories = [
    'Salary',
    'Freelance',
    'Investment',
    'Gift',
    'Other Income',
  ];

  static const List<String> expenseCategories = [
    'Food',
    'Transport',
    'Entertainment',
    'Bills',
    'Shopping',
    'Health',
    'Education',
    'Other',
  ];

  // Relationships
  static const List<String> relationships = [
    'Family',
    'Friend',
    'Colleague',
    'Partner',
    'Other',
  ];

  // Time Constants
  static const int notificationDefaultHour = 8;
  static const int notificationDefaultMinute = 0;
  static const int defaultReminderDaysBefore = 1;

  // UI Constants
  static const double defaultPadding = 16.0;
  static const double defaultRadius = 12.0;
  static const double iconSize = 24.0;
  static const double cardElevation = 4.0;

  // Animation Durations
  static const int animationDurationShort = 200;
  static const int animationDurationMedium = 350;
  static const int animationDurationLong = 500;

  // Max Limits
  static const int maxTasks = 1000;
  static const int maxNotes = 1000;
  static const int maxFinances = 5000;
  static const int maxBirthdays = 500;
  static const int maxChatHistory = 100;
  static const int maxQueryHistory = 100;

  // Image Quality
  static const int imageMaxWidth = 1920;
  static const int imageMaxHeight = 1920;
  static const int imageQuality = 85;

  // Error Messages
  static const String errorGeneric = 'Something went wrong. Please try again.';
  static const String errorNetwork = 'Network error. Please check your connection.';
  static const String errorAuth = 'Authentication failed. Please sign in again.';
  static const String errorPermission = 'Permission denied. Please check app settings.';
  static const String errorNotFound = 'Item not found.';

  // Success Messages
  static const String successSaved = 'Saved successfully!';
  static const String successDeleted = 'Deleted successfully!';
  static const String successUpdated = 'Updated successfully!';
  static const String successSignedIn = 'Signed in successfully!';
  static const String successSignedOut = 'Signed out successfully!';

  // Offline Messages
  static const String offlineTitle = 'You\'re Offline';
  static const String offlineMessage = 'Some features may be limited. Connect to the internet for full functionality.';
  static const String offlineAIResponse = 'I\'m currently offline, but I can still help with basic responses!';
}
