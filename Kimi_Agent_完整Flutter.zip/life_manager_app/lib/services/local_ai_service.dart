import 'dart:io';
import 'package:flutter_gemma/flutter_gemma.dart';
import '../core/constants.dart';
import '../models/chat_message.dart';
import 'ai_service.dart';

class LocalAIService implements AIService {
  final FlutterGemma _gemma = FlutterGemma();
  bool _isInitialized = false;
  bool _isModelLoaded = false;

  bool get isAvailable => _isInitialized && _isModelLoaded;

  Future<void> initialize() async {
    try {
      _isInitialized = await _gemma.isInitialized;
      if (_isInitialized) {
        _isModelLoaded = await _gemma.isLoaded;
      }
    } catch (e) {
      _isInitialized = false;
      _isModelLoaded = false;
    }
  }

  Future<bool> downloadModel({Function(double)? onProgress}) async {
    try {
      if (!_isInitialized) {
        await _gemma.init();
        _isInitialized = true;
      }

      if (!_isModelLoaded) {
        await _gemma.loadModel(
          modelName: AppConstants.gemmaModelName,
          onProgress: onProgress,
        );
        _isModelLoaded = true;
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> unloadModel() async {
    try {
      if (_isModelLoaded) {
        await _gemma.unloadModel();
        _isModelLoaded = false;
      }
    } catch (e) {
      // Ignore errors during unload
    }
  }

  @override
  Future<ChatMessage> sendMessage(String message, {String? imagePath}) async {
    if (!isAvailable) {
      return ChatMessage(
        content: 'Local AI model is not loaded. Please download the model first.',
        isUser: false,
        type: MessageType.error,
        isOffline: true,
      );
    }

    try {
      final response = await _gemma.generateResponse(
        prompt: _formatPrompt(message),
      );

      return ChatMessage(
        content: response.trim(),
        isUser: false,
        type: MessageType.text,
        isOffline: true,
        modelUsed: modelName,
      );
    } catch (e) {
      return ChatMessage(
        content: 'Error generating response: $e',
        isUser: false,
        type: MessageType.error,
        isOffline: true,
      );
    }
  }

  @override
  Future<ChatMessage> analyzeImage(File image, {String? prompt}) async {
    // Gemma 2B doesn't support image analysis
    return ChatMessage(
      content: 'The offline AI model (Gemma 2B) does not support image analysis. Please connect to the internet to use image features.',
      isUser: false,
      type: MessageType.text,
      isOffline: true,
      modelUsed: modelName,
    );
  }

  @override
  Future<bool> isAvailable() async {
    return isAvailable;
  }

  @override
  String get modelName => AppConstants.gemmaModelName;

  @override
  bool get isLocal => true;

  String _formatPrompt(String message) {
    // Format prompt for Gemma instruction-tuned model
    return '''<start_of_turn>user
$message<end_of_turn>
<start_of_turn>model
''';
  }

  // Stream response for real-time updates
  Stream<String> generateResponseStream(String message) async* {
    if (!isAvailable) {
      yield 'Local AI model is not available.';
      return;
    }

    try {
      await for (final chunk in _gemma.generateResponseStream(
        prompt: _formatPrompt(message),
      )) {
        yield chunk;
      }
    } catch (e) {
      yield 'Error: $e';
    }
  }

  void dispose() {
    unloadModel();
  }
}
