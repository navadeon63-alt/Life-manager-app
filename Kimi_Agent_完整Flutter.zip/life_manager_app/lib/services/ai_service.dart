import 'dart:async';
import 'dart:io';
import '../models/chat_message.dart';
import 'connectivity_service.dart';
import 'local_ai_service.dart';
import 'online_ai_service.dart';

abstract class AIService {
  Future<ChatMessage> sendMessage(String message, {String? imagePath});
  Future<ChatMessage> analyzeImage(File image, {String? prompt});
  Future<bool> isAvailable();
  String get modelName;
  bool get isLocal;
}

class AdaptiveAIService implements AIService {
  static final AdaptiveAIService _instance = AdaptiveAIService._internal();
  factory AdaptiveAIService() => _instance;
  AdaptiveAIService._internal();

  final ConnectivityService _connectivity = ConnectivityService();
  final LocalAIService _localAI = LocalAIService();
  final OnlineAIService _onlineAI = OnlineAIService();

  AIService? _currentService;
  bool _preferLocal = false;

  Future<void> initialize() async {
    await _localAI.initialize();
    await _onlineAI.initialize();
    
    // Determine which service to use
    await _selectOptimalService();
    
    // Listen for connectivity changes
    _connectivity.connectionStream.listen((isConnected) {
      _selectOptimalService();
    });
  }

  Future<void> _selectOptimalService() async {
    final isConnected = await _connectivity.checkConnection();
    
    if (_preferLocal && _localAI.isAvailable) {
      _currentService = _localAI;
    } else if (isConnected && await _onlineAI.isAvailable()) {
      _currentService = _onlineAI;
    } else if (_localAI.isAvailable) {
      _currentService = _localAI;
    } else {
      _currentService = null;
    }
  }

  void setPreferLocal(bool preferLocal) {
    _preferLocal = preferLocal;
    _selectOptimalService();
  }

  AIService? get currentService => _currentService;
  bool get isUsingLocalAI => _currentService == _localAI;
  bool get isUsingOnlineAI => _currentService == _onlineAI;
  bool get hasLocalAI => _localAI.isAvailable;
  bool get hasOnlineAI => _onlineAI.isAvailable;

  @override
  Future<ChatMessage> sendMessage(String message, {String? imagePath}) async {
    await _selectOptimalService();
    
    if (_currentService == null) {
      return ChatMessage(
        content: 'AI service is currently unavailable. Please check your connection or download the offline AI model.',
        isUser: false,
        type: MessageType.error,
      );
    }

    try {
      return await _currentService!.sendMessage(message, imagePath: imagePath);
    } catch (e) {
      // Try fallback service
      if (_currentService == _onlineAI && _localAI.isAvailable) {
        _currentService = _localAI;
        return await _localAI.sendMessage(message, imagePath: imagePath);
      }
      
      return ChatMessage(
        content: 'Sorry, I encountered an error: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  @override
  Future<ChatMessage> analyzeImage(File image, {String? prompt}) async {
    await _selectOptimalService();
    
    if (_currentService == null) {
      return ChatMessage(
        content: 'AI service is currently unavailable.',
        isUser: false,
        type: MessageType.error,
      );
    }

    try {
      return await _currentService!.analyzeImage(image, prompt: prompt);
    } catch (e) {
      return ChatMessage(
        content: 'Sorry, I encountered an error analyzing the image: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  @override
  Future<bool> isAvailable() async {
    await _selectOptimalService();
    return _currentService != null;
  }

  @override
  String get modelName => _currentService?.modelName ?? 'None';

  @override
  bool get isLocal => _currentService?.isLocal ?? false;

  // Search with web grounding (online only)
  Future<ChatMessage> searchWithGrounding(String query) async {
    final isConnected = await _connectivity.checkConnection();
    
    if (!isConnected) {
      return ChatMessage(
        content: 'Web search requires an internet connection. Please connect to search online.',
        isUser: false,
        type: MessageType.error,
        isOffline: true,
      );
    }

    try {
      return await _onlineAI.searchWithGrounding(query);
    } catch (e) {
      return ChatMessage(
        content: 'Search failed: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  // Get daily briefing data
  Future<Map<String, dynamic>> getDailyBriefingData() async {
    final isConnected = await _connectivity.checkConnection();
    
    if (!isConnected) {
      return {
        'exchangeRate': null,
        'economyUpdate': null,
        'isOffline': true,
      };
    }

    try {
      final exchangeRate = await _onlineAI.getExchangeRate();
      final economyUpdate = await _onlineAI.getSAEconomyUpdate();
      
      return {
        'exchangeRate': exchangeRate,
        'economyUpdate': economyUpdate,
        'isOffline': false,
      };
    } catch (e) {
      return {
        'exchangeRate': null,
        'economyUpdate': null,
        'isOffline': true,
        'error': e.toString(),
      };
    }
  }

  // Generate personalized tip based on user data
  Future<String> generatePersonalizedTip({
    required List<dynamic> tasks,
    required List<dynamic> finances,
    required Map<String, dynamic> behaviorPatterns,
  }) async {
    await _selectOptimalService();
    
    if (_currentService == null) {
      return 'Take a moment to review your tasks and plan your day for maximum productivity!';
    }

    final prompt = _buildPersonalizedTipPrompt(
      tasks: tasks,
      finances: finances,
      behaviorPatterns: behaviorPatterns,
    );

    try {
      final response = await _currentService!.sendMessage(prompt);
      return response.content;
    } catch (e) {
      return 'Remember to take breaks and stay hydrated throughout your day!';
    }
  }

  String _buildPersonalizedTipPrompt({
    required List<dynamic> tasks,
    required List<dynamic> finances,
    required Map<String, dynamic> behaviorPatterns,
  }) {
    final pendingTasks = tasks.where((t) => !t.isCompleted).length;
    final completedTasks = tasks.where((t) => t.isCompleted).length;
    
    return '''
Based on the following user data, provide a short, personalized productivity or wellness tip (max 2 sentences):

- Pending tasks: $pendingTasks
- Completed tasks today: $completedTasks
- Productive hours: ${behaviorPatterns['productiveHours']?.join(', ') ?? 'Unknown'}
- Top spending categories: ${behaviorPatterns['topSpendingCategories']?.join(', ') ?? 'Unknown'}

Make it encouraging, practical, and personalized. Respond with just the tip, no preamble.
''';}

  void dispose() {
    _localAI.dispose();
  }
}
