import '../core/constants.dart';
import '../models/user_profile.dart';
import 'storage_service.dart';
import 'auth_service.dart';

class UserProfileService {
  static final UserProfileService _instance = UserProfileService._internal();
  factory UserProfileService() => _instance;
  UserProfileService._internal();

  final StorageService _storage = StorageService();
  final AuthService _auth = AuthService();

  UserProfile? get currentProfile => _auth.userProfile;

  // Get user preferences
  UserPreferences get preferences {
    return _auth.userProfile?.preferences ?? UserPreferences();
  }

  // Update dark mode
  Future<void> setDarkMode(bool enabled) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: enabled,
      notificationsEnabled: current.notificationsEnabled,
      dailyBriefingEnabled: current.dailyBriefingEnabled,
      dailyBriefingTime: current.dailyBriefingTime,
      currency: current.currency,
      defaultTaskCategory: current.defaultTaskCategory,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
    await _storage.setBool(AppConstants.prefKeyDarkMode, enabled);
  }

  // Update notifications
  Future<void> setNotificationsEnabled(bool enabled) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: current.darkMode,
      notificationsEnabled: enabled,
      dailyBriefingEnabled: current.dailyBriefingEnabled,
      dailyBriefingTime: current.dailyBriefingTime,
      currency: current.currency,
      defaultTaskCategory: current.defaultTaskCategory,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
    await _storage.setBool(AppConstants.prefKeyNotificationsEnabled, enabled);
  }

  // Update daily briefing
  Future<void> setDailyBriefingEnabled(bool enabled) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: current.darkMode,
      notificationsEnabled: current.notificationsEnabled,
      dailyBriefingEnabled: enabled,
      dailyBriefingTime: current.dailyBriefingTime,
      currency: current.currency,
      defaultTaskCategory: current.defaultTaskCategory,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
    await _storage.setBool(AppConstants.prefKeyDailyBriefingEnabled, enabled);
  }

  // Update daily briefing time
  Future<void> setDailyBriefingTime(TimeOfDay time) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: current.darkMode,
      notificationsEnabled: current.notificationsEnabled,
      dailyBriefingEnabled: current.dailyBriefingEnabled,
      dailyBriefingTime: time,
      currency: current.currency,
      defaultTaskCategory: current.defaultTaskCategory,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
    await _storage.setInt(AppConstants.prefKeyDailyBriefingHour, time.hour);
    await _storage.setInt(AppConstants.prefKeyDailyBriefingMinute, time.minute);
  }

  // Update currency
  Future<void> setCurrency(String currency) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: current.darkMode,
      notificationsEnabled: current.notificationsEnabled,
      dailyBriefingEnabled: current.dailyBriefingEnabled,
      dailyBriefingTime: current.dailyBriefingTime,
      currency: currency,
      defaultTaskCategory: current.defaultTaskCategory,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
  }

  // Update default task category
  Future<void> setDefaultTaskCategory(String? category) async {
    final current = preferences;
    final updated = UserPreferences(
      darkMode: current.darkMode,
      notificationsEnabled: current.notificationsEnabled,
      dailyBriefingEnabled: current.dailyBriefingEnabled,
      dailyBriefingTime: current.dailyBriefingTime,
      currency: current.currency,
      defaultTaskCategory: category,
      expenseCategories: current.expenseCategories,
      incomeCategories: current.incomeCategories,
      noteCategories: current.noteCategories,
    );
    await _auth.updatePreferences(updated);
  }

  // Add custom expense category
  Future<void> addExpenseCategory(String category) async {
    final current = preferences;
    final categories = List<String>.from(current.expenseCategories);
    if (!categories.contains(category)) {
      categories.add(category);
      final updated = UserPreferences(
        darkMode: current.darkMode,
        notificationsEnabled: current.notificationsEnabled,
        dailyBriefingEnabled: current.dailyBriefingEnabled,
        dailyBriefingTime: current.dailyBriefingTime,
        currency: current.currency,
        defaultTaskCategory: current.defaultTaskCategory,
        expenseCategories: categories,
        incomeCategories: current.incomeCategories,
        noteCategories: current.noteCategories,
      );
      await _auth.updatePreferences(updated);
    }
  }

  // Add custom income category
  Future<void> addIncomeCategory(String category) async {
    final current = preferences;
    final categories = List<String>.from(current.incomeCategories);
    if (!categories.contains(category)) {
      categories.add(category);
      final updated = UserPreferences(
        darkMode: current.darkMode,
        notificationsEnabled: current.notificationsEnabled,
        dailyBriefingEnabled: current.dailyBriefingEnabled,
        dailyBriefingTime: current.dailyBriefingTime,
        currency: current.currency,
        defaultTaskCategory: current.defaultTaskCategory,
        expenseCategories: current.expenseCategories,
        incomeCategories: categories,
        noteCategories: current.noteCategories,
      );
      await _auth.updatePreferences(updated);
    }
  }

  // Add custom note category
  Future<void> addNoteCategory(String category) async {
    final current = preferences;
    final categories = List<String>.from(current.noteCategories);
    if (!categories.contains(category)) {
      categories.add(category);
      final updated = UserPreferences(
        darkMode: current.darkMode,
        notificationsEnabled: current.notificationsEnabled,
        dailyBriefingEnabled: current.dailyBriefingEnabled,
        dailyBriefingTime: current.dailyBriefingTime,
        currency: current.currency,
        defaultTaskCategory: current.defaultTaskCategory,
        expenseCategories: current.expenseCategories,
        incomeCategories: current.incomeCategories,
        noteCategories: categories,
      );
      await _auth.updatePreferences(updated);
    }
  }

  // Set AI model preference
  Future<void> setPreferredAiModel(String model) async {
    await _auth.setPreferredAiModel(model);
  }

  // Set model downloaded status
  Future<void> setModelDownloaded(bool downloaded) async {
    await _auth.setModelDownloaded(downloaded);
  }

  // Check if user has seen onboarding
  Future<bool> hasSeenOnboarding() async {
    return _storage.getBool(AppConstants.prefKeyHasSeenOnboarding) ?? false;
  }

  // Set onboarding seen
  Future<void> setHasSeenOnboarding(bool seen) async {
    await _storage.setBool(AppConstants.prefKeyHasSeenOnboarding, seen);
  }

  // Check if model has been downloaded
  Future<bool> hasDownloadedModel() async {
    return _storage.getBool(AppConstants.prefKeyHasDownloadedModel) ?? false;
  }

  // Get preferred AI model
  String? getPreferredAiModel() {
    return _storage.getString(AppConstants.prefKeyPreferredAiModel);
  }

  // Reset all preferences to default
  Future<void> resetPreferences() async {
    final defaultPrefs = UserPreferences();
    await _auth.updatePreferences(defaultPrefs);
    
    await _storage.setBool(AppConstants.prefKeyDarkMode, defaultPrefs.darkMode);
    await _storage.setBool(AppConstants.prefKeyNotificationsEnabled, defaultPrefs.notificationsEnabled);
    await _storage.setBool(AppConstants.prefKeyDailyBriefingEnabled, defaultPrefs.dailyBriefingEnabled);
  }

  // Export user data
  Future<Map<String, dynamic>> exportUserData() async {
    final profile = _auth.userProfile;
    if (profile == null) return {};

    return {
      'userId': profile.userId,
      'email': profile.email,
      'displayName': profile.displayName,
      'createdAt': profile.createdAt?.toIso8601String(),
      'preferences': profile.preferences.toJson(),
      'behaviorPatterns': profile.behaviorPatterns.toJson(),
      'frequentSearches': profile.frequentSearches,
      'hasDownloadedModel': profile.hasDownloadedModel,
      'preferredAiModel': profile.preferredAiModel,
    };
  }

  // Get account creation date
  DateTime? getAccountCreationDate() {
    return _auth.userProfile?.createdAt;
  }

  // Get last sign in date
  DateTime? getLastSignInDate() {
    return _auth.userProfile?.lastSignIn;
  }

  // Update last sign in
  Future<void> updateLastSignIn() async {
    if (_auth.userProfile != null) {
      final updated = _auth.userProfile!.copyWith(
        lastSignIn: DateTime.now(),
      );
      await _auth.updateUserProfile(updated);
    }
  }
}
