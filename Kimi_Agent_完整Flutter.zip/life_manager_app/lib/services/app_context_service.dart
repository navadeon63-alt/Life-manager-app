import '../models/task.dart';
import '../models/note.dart';
import '../models/finance.dart';
import '../models/birthday.dart';
import 'storage_service.dart';

class AppContextService {
  static final AppContextService _instance = AppContextService._internal();
  factory AppContextService() => _instance;
  AppContextService._internal();

  final StorageService _storage = StorageService();

  List<Task> _tasks = [];
  List<Note> _notes = [];
  List<FinanceEntry> _finances = [];
  List<Birthday> _birthdays = [];

  List<Task> get tasks => List.unmodifiable(_tasks);
  List<Note> get notes => List.unmodifiable(_notes);
  List<FinanceEntry> get finances => List.unmodifiable(_finances);
  List<Birthday> get birthdays => List.unmodifiable(_birthdays);

  // Tasks
  Future<void> loadTasks() async {
    _tasks = await _storage.loadTasks();
  }

  Future<void> addTask(Task task) async {
    _tasks.add(task);
    await _storage.saveTasks(_tasks);
  }

  Future<void> updateTask(Task task) async {
    final index = _tasks.indexWhere((t) => t.id == task.id);
    if (index != -1) {
      _tasks[index] = task;
      await _storage.saveTasks(_tasks);
    }
  }

  Future<void> deleteTask(String id) async {
    _tasks.removeWhere((t) => t.id == id);
    await _storage.saveTasks(_tasks);
  }

  Future<void> toggleTaskComplete(String id) async {
    final index = _tasks.indexWhere((t) => t.id == id);
    if (index != -1) {
      final task = _tasks[index];
      _tasks[index] = task.copyWith(
        isCompleted: !task.isCompleted,
        completedAt: !task.isCompleted ? DateTime.now() : null,
      );
      await _storage.saveTasks(_tasks);
    }
  }

  List<Task> getTasksForToday() {
    final now = DateTime.now();
    return _tasks.where((t) {
      if (t.isCompleted) return false;
      if (t.dueDate == null) return false;
      return t.dueDate!.year == now.year &&
          t.dueDate!.month == now.month &&
          t.dueDate!.day == now.day;
    }).toList();
  }

  List<Task> getUpcomingTasks({int days = 7}) {
    final now = DateTime.now();
    final future = now.add(Duration(days: days));
    return _tasks.where((t) {
      if (t.isCompleted) return false;
      if (t.dueDate == null) return false;
      return t.dueDate!.isAfter(now) && t.dueDate!.isBefore(future);
    }).toList();
  }

  List<Task> getOverdueTasks() {
    return _tasks.where((t) => t.isOverdue).toList();
  }

  // Notes
  Future<void> loadNotes() async {
    _notes = await _storage.loadNotes();
  }

  Future<void> addNote(Note note) async {
    _notes.add(note);
    await _storage.saveNotes(_notes);
  }

  Future<void> updateNote(Note note) async {
    final index = _notes.indexWhere((n) => n.id == note.id);
    if (index != -1) {
      _notes[index] = note;
      await _storage.saveNotes(_notes);
    }
  }

  Future<void> deleteNote(String id) async {
    _notes.removeWhere((n) => n.id == id);
    await _storage.saveNotes(_notes);
  }

  List<Note> getPinnedNotes() {
    return _notes.where((n) => n.isPinned).toList();
  }

  // Finances
  Future<void> loadFinances() async {
    _finances = await _storage.loadFinances();
  }

  Future<void> addFinance(FinanceEntry entry) async {
    _finances.add(entry);
    await _storage.saveFinances(_finances);
  }

  Future<void> updateFinance(FinanceEntry entry) async {
    final index = _finances.indexWhere((f) => f.id == entry.id);
    if (index != -1) {
      _finances[index] = entry;
      await _storage.saveFinances(_finances);
    }
  }

  Future<void> deleteFinance(String id) async {
    _finances.removeWhere((f) => f.id == id);
    await _storage.saveFinances(_finances);
  }

  double getTotalIncome({DateTime? startDate, DateTime? endDate}) {
    return _finances
        .where((f) {
          if (f.type != FinanceType.income) return false;
          if (startDate != null && f.date.isBefore(startDate)) return false;
          if (endDate != null && f.date.isAfter(endDate)) return false;
          return true;
        })
        .fold(0.0, (sum, f) => sum + f.amount);
  }

  double getTotalExpenses({DateTime? startDate, DateTime? endDate}) {
    return _finances
        .where((f) {
          if (f.type != FinanceType.expense) return false;
          if (startDate != null && f.date.isBefore(startDate)) return false;
          if (endDate != null && f.date.isAfter(endDate)) return false;
          return true;
        })
        .fold(0.0, (sum, f) => sum + f.amount);
  }

  double getBalance() {
    return getTotalIncome() - getTotalExpenses();
  }

  Map<String, double> getExpensesByCategory() {
    final Map<String, double> breakdown = {};
    for (final entry in _finances.where((f) => f.type == FinanceType.expense)) {
      final category = entry.category ?? 'Uncategorized';
      breakdown[category] = (breakdown[category] ?? 0) + entry.amount;
    }
    return breakdown;
  }

  // Birthdays
  Future<void> loadBirthdays() async {
    _birthdays = await _storage.loadBirthdays();
  }

  Future<void> addBirthday(Birthday birthday) async {
    _birthdays.add(birthday);
    await _storage.saveBirthdays(_birthdays);
  }

  Future<void> updateBirthday(Birthday birthday) async {
    final index = _birthdays.indexWhere((b) => b.id == birthday.id);
    if (index != -1) {
      _birthdays[index] = birthday;
      await _storage.saveBirthdays(_birthdays);
    }
  }

  Future<void> deleteBirthday(String id) async {
    _birthdays.removeWhere((b) => b.id == id);
    await _storage.saveBirthdays(_birthdays);
  }

  List<Birthday> getUpcomingBirthdays({int days = 30}) {
    return _birthdays
        .where((b) => b.daysUntilBirthday <= days)
        .toList()
      ..sort((a, b) => a.daysUntilBirthday.compareTo(b.daysUntilBirthday));
  }

  List<Birthday> getTodaysBirthdays() {
    return _birthdays.where((b) => b.isBirthdayToday).toList();
  }

  // Load all data
  Future<void> loadAllData() async {
    await Future.wait([
      loadTasks(),
      loadNotes(),
      loadFinances(),
      loadBirthdays(),
    ]);
  }

  // Get summary statistics
  Map<String, dynamic> getSummary() {
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1);
    
    return {
      'totalTasks': _tasks.length,
      'pendingTasks': _tasks.where((t) => !t.isCompleted).length,
      'completedTasks': _tasks.where((t) => t.isCompleted).length,
      'todayTasks': getTasksForToday().length,
      'totalNotes': _notes.length,
      'pinnedNotes': getPinnedNotes().length,
      'totalFinances': _finances.length,
      'monthlyIncome': getTotalIncome(startDate: startOfMonth),
      'monthlyExpenses': getTotalExpenses(startDate: startOfMonth),
      'balance': getBalance(),
      'totalBirthdays': _birthdays.length,
      'upcomingBirthdays': getUpcomingBirthdays(days: 30).length,
      'todaysBirthdays': getTodaysBirthdays().length,
    };
  }

  // Search across all data
  Map<String, List<dynamic>> search(String query) {
    final lowerQuery = query.toLowerCase();
    
    return {
      'tasks': _tasks.where((t) {
        return t.title.toLowerCase().contains(lowerQuery) ||
            (t.description?.toLowerCase().contains(lowerQuery) ?? false) ||
            t.tags.any((tag) => tag.toLowerCase().contains(lowerQuery));
      }).toList(),
      'notes': _notes.where((n) {
        return n.title.toLowerCase().contains(lowerQuery) ||
            n.content.toLowerCase().contains(lowerQuery) ||
            n.tags.any((tag) => tag.toLowerCase().contains(lowerQuery));
      }).toList(),
      'finances': _finances.where((f) {
        return f.title.toLowerCase().contains(lowerQuery) ||
            (f.description?.toLowerCase().contains(lowerQuery) ?? false) ||
            (f.category?.toLowerCase().contains(lowerQuery) ?? false);
      }).toList(),
      'birthdays': _birthdays.where((b) {
        return b.name.toLowerCase().contains(lowerQuery) ||
            (b.relationship?.toLowerCase().contains(lowerQuery) ?? false) ||
            (b.notes?.toLowerCase().contains(lowerQuery) ?? false);
      }).toList(),
    };
  }

  // Clear all data
  Future<void> clearAllData() async {
    _tasks.clear();
    _notes.clear();
    _finances.clear();
    _birthdays.clear();
    await _storage.clearAll();
  }
}
