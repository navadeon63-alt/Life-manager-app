import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'storage_service.dart';

class ImageService {
  static final ImageService _instance = ImageService._internal();
  factory ImageService() => _instance;
  ImageService._internal();

  final ImagePicker _picker = ImagePicker();
  final StorageService _storage = StorageService();

  // Request camera permission
  Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  // Request storage permission
  Future<bool> requestStoragePermission() async {
    if (Platform.isAndroid) {
      final status = await Permission.photos.request();
      return status.isGranted;
    }
    return true;
  }

  // Check all required permissions
  Future<Map<String, bool>> checkPermissions() async {
    return {
      'camera': await Permission.camera.isGranted,
      'photos': await Permission.photos.isGranted,
      'storage': await Permission.storage.isGranted,
    };
  }

  // Take a photo with camera
  Future<File?> takePhoto() async {
    try {
      final hasPermission = await requestCameraPermission();
      if (!hasPermission) {
        throw Exception('Camera permission denied');
      }

      final XFile? photo = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1920,
        maxHeight: 1920,
        imageQuality: 85,
      );

      if (photo != null) {
        return File(photo.path);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to take photo: $e');
    }
  }

  // Pick image from gallery
  Future<File?> pickFromGallery() async {
    try {
      final hasPermission = await requestStoragePermission();
      if (!hasPermission) {
        throw Exception('Storage permission denied');
      }

      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1920,
        maxHeight: 1920,
        imageQuality: 85,
      );

      if (image != null) {
        return File(image.path);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to pick image: $e');
    }
  }

  // Pick multiple images
  Future<List<File>> pickMultipleImages({int maxImages = 5}) async {
    try {
      final hasPermission = await requestStoragePermission();
      if (!hasPermission) {
        throw Exception('Storage permission denied');
      }

      final List<XFile> images = await _picker.pickMultiImage(
        maxWidth: 1920,
        maxHeight: 1920,
        imageQuality: 85,
      );

      return images.take(maxImages).map((x) => File(x.path)).toList();
    } catch (e) {
      throw Exception('Failed to pick images: $e');
    }
  }

  // Save image to app storage
  Future<String> saveImage(File imageFile, {String? prefix}) async {
    try {
      final filename = '${prefix ?? 'img'}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      return await _storage.saveImage(imageFile, filename);
    } catch (e) {
      throw Exception('Failed to save image: $e');
    }
  }

  // Delete image
  Future<void> deleteImage(String path) async {
    await _storage.deleteImage(path);
  }

  // Get image size in MB
  Future<double> getImageSize(String path) async {
    try {
      final file = File(path);
      final bytes = await file.length();
      return bytes / (1024 * 1024);
    } catch (e) {
      return 0;
    }
  }

  // Compress image if needed
  Future<File?> compressImage(File imageFile, {int quality = 85}) async {
    // For now, return the original file
    // In production, use flutter_image_compress package
    return imageFile;
  }

  // Show image source selector (camera or gallery)
  Future<File?> showImageSourceSelector({
    required Future<File?> Function() onCamera,
    required Future<File?> Function() onGallery,
  }) async {
    // This method should be called from UI with appropriate dialog
    // Returns the selected image file
    return null;
  }

  // Validate image file
  Future<bool> validateImage(String path) async {
    try {
      final file = File(path);
      if (!await file.exists()) return false;
      
      final size = await getImageSize(path);
      if (size > 10) return false; // Max 10MB
      
      return true;
    } catch (e) {
      return false;
    }
  }

  // Get image dimensions
  Future<Map<String, int>?> getImageDimensions(String path) async {
    try {
      // In production, use image package to get dimensions
      return null;
    } catch (e) {
      return null;
    }
  }
}
