import '../models/task.dart';
import '../models/finance.dart';
import '../models/user_profile.dart';
import 'storage_service.dart';
import 'auth_service.dart';

class LearningEngineService {
  static final LearningEngineService _instance = LearningEngineService._internal();
  factory LearningEngineService() => _instance;
  LearningEngineService._internal();

  final StorageService _storage = StorageService();
  final AuthService _auth = AuthService();

  // Track task completion
  Future<void> trackTaskCompletion(Task task) async {
    if (_auth.userProfile == null) return;

    final patterns = _auth.userProfile!.behaviorPatterns;
    final hour = DateTime.now().hour;
    
    patterns.updateTaskCompletion(hour);
    if (task.category != null) {
      patterns.updateTaskCategory(task.category!);
    }

    await _auth.updateBehaviorPatterns(patterns);
  }

  // Track spending
  Future<void> trackSpending(FinanceEntry entry) async {
    if (_auth.userProfile == null) return;

    final patterns = _auth.userProfile!.behaviorPatterns;
    
    if (entry.type == FinanceType.expense && entry.category != null) {
      patterns.updateSpending(entry.category!, entry.amount);
    }

    // Recalculate averages
    await _recalculateAverages();
    await _auth.updateBehaviorPatterns(patterns);
  }

  // Track app usage
  Future<void> trackAppUsage() async {
    if (_auth.userProfile == null) return;

    final patterns = _auth.userProfile!.behaviorPatterns;
    final dayOfWeek = DateTime.now().weekday.toString();
    
    patterns.appUsageByDay[dayOfWeek] = 
        (patterns.appUsageByDay[dayOfWeek] ?? 0) + 1;

    await _auth.updateBehaviorPatterns(patterns);
  }

  // Track search query
  Future<void> trackSearch(String query) async {
    if (query.isEmpty) return;
    await _auth.addFrequentSearch(query);
  }

  // Recalculate financial averages
  Future<void> _recalculateAverages() async {
    if (_auth.userProfile == null) return;

    final finances = await _storage.loadFinances();
    final now = DateTime.now();
    
    // Calculate daily average expense (last 30 days)
    final thirtyDaysAgo = now.subtract(const Duration(days: 30));
    final recentExpenses = finances.where((f) {
      return f.type == FinanceType.expense && f.date.isAfter(thirtyDaysAgo);
    }).toList();
    
    final totalExpenses = recentExpenses.fold<double>(
      0, (sum, f) => sum + f.amount,
    );
    
    // Calculate monthly average income (last 3 months)
    final threeMonthsAgo = now.subtract(const Duration(days: 90));
    final recentIncome = finances.where((f) {
      return f.type == FinanceType.income && f.date.isAfter(threeMonthsAgo);
    }).toList();
    
    final totalIncome = recentIncome.fold<double>(
      0, (sum, f) => sum + f.amount,
    );

    final patterns = _auth.userProfile!.behaviorPatterns;
    patterns.averageDailyExpense = totalExpenses / 30;
    patterns.averageMonthlyIncome = totalIncome / 3;

    await _auth.updateBehaviorPatterns(patterns);
  }

  // Generate proactive suggestions
  Future<List<String>> generateSuggestions() async {
    if (_auth.userProfile == null) return [];

    final suggestions = <String>[];
    final patterns = _auth.userProfile!.behaviorPatterns;
    final now = DateTime.now();

    // Task-related suggestions
    final tasks = await _storage.loadTasks();
    final pendingTasks = tasks.where((t) => !t.isCompleted).toList();
    final overdueTasks = pendingTasks.where((t) => t.isOverdue).toList();

    if (overdueTasks.isNotEmpty) {
      suggestions.add('You have ${overdueTasks.length} overdue task(s). Consider rescheduling or prioritizing them.');
    }

    if (pendingTasks.length > 10) {
      suggestions.add('You have many pending tasks. Try breaking them down into smaller, manageable chunks.');
    }

    // Productive hours suggestion
    if (patterns.productiveHours.isNotEmpty) {
      final hours = patterns.productiveHours.map((h) => '$h:00').join(', ');
      suggestions.add('Your most productive hours are around $hours. Schedule important tasks during these times.');
    }

    // Spending suggestions
    if (patterns.averageDailyExpense > patterns.averageMonthlyIncome / 30) {
      suggestions.add('Your daily spending is higher than your average income. Consider reviewing your budget.');
    }

    final topSpending = patterns.getTopSpendingCategories(1);
    if (topSpending.isNotEmpty) {
      suggestions.add('You spend the most on ${topSpending.first}. Keep an eye on this category.');
    }

    // Birthday suggestions
    final birthdays = await _storage.loadBirthdays();
    final upcomingBirthdays = birthdays
        .where((b) => b.daysUntilBirthday <= 7 && b.daysUntilBirthday > 0)
        .toList();

    for (final birthday in upcomingBirthdays.take(2)) {
      suggestions.add('${birthday.name}\'s birthday is in ${birthday.daysUntilBirthday} days! Start planning a gift.');
    }

    // Day-specific suggestions
    final dayOfWeek = now.weekday;
    if (dayOfWeek == DateTime.monday) {
      suggestions.add('It\'s Monday! Start your week by reviewing and prioritizing your tasks.');
    } else if (dayOfWeek == DateTime.friday) {
      suggestions.add('It\'s Friday! Wrap up pending tasks and plan for next week.');
    }

    // Time-based suggestions
    final hour = now.hour;
    if (hour >= 22 || hour < 6) {
      suggestions.add('It\'s getting late. Consider getting some rest for a productive tomorrow.');
    }

    return suggestions.take(5).toList();
  }

  // Get personalized greeting
  String getPersonalizedGreeting() {
    final hour = DateTime.now().hour;
    final name = _auth.userDisplayName?.split(' ').first ?? 'there';

    if (hour >= 5 && hour < 12) {
      return 'Good morning, $name!';
    } else if (hour >= 12 && hour < 17) {
      return 'Good afternoon, $name!';
    } else if (hour >= 17 && hour < 22) {
      return 'Good evening, $name!';
    } else {
      return 'Hello, $name!';
    }
  }

  // Get productivity insights
  Map<String, dynamic> getProductivityInsights() {
    if (_auth.userProfile == null) return {};

    final patterns = _auth.userProfile!.behaviorPatterns;

    return {
      'productiveHours': patterns.productiveHours,
      'taskCompletionPattern': patterns.taskCompletionByHour,
      'mostProductiveDay': _getMostProductiveDay(patterns),
      'categoryPreferences': patterns.taskCategoryFrequency,
      'appUsagePattern': patterns.appUsageByDay,
    };
  }

  String? _getMostProductiveDay(UserBehaviorPatterns patterns) {
    if (patterns.appUsageByDay.isEmpty) return null;
    
    final sorted = patterns.appUsageByDay.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final dayNames = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return dayNames[int.tryParse(sorted.first.key) ?? 1];
  }

  // Get financial insights
  Future<Map<String, dynamic>> getFinancialInsights() async {
    if (_auth.userProfile == null) return {};

    final patterns = _auth.userProfile!.behaviorPatterns;
    final finances = await _storage.loadFinances();

    final now = DateTime.now();
    final thisMonth = DateTime(now.year, now.month);
    final lastMonth = DateTime(now.year, now.month - 1);

    final thisMonthExpenses = finances
        .where((f) => f.type == FinanceType.expense && f.date.isAfter(thisMonth))
        .fold<double>(0, (sum, f) => sum + f.amount);

    final lastMonthExpenses = finances
        .where((f) => 
            f.type == FinanceType.expense && 
            f.date.isAfter(lastMonth) && 
            f.date.isBefore(thisMonth))
        .fold<double>(0, (sum, f) => sum + f.amount);

    final spendingChange = lastMonthExpenses > 0
        ? ((thisMonthExpenses - lastMonthExpenses) / lastMonthExpenses) * 100
        : 0;

    return {
      'averageDailyExpense': patterns.averageDailyExpense,
      'averageMonthlyIncome': patterns.averageMonthlyIncome,
      'topSpendingCategories': patterns.getTopSpendingCategories(3),
      'spendingChangePercent': spendingChange,
      'thisMonthExpenses': thisMonthExpenses,
      'lastMonthExpenses': lastMonthExpenses,
    };
  }

  // Clear all learning data
  Future<void> clearLearningData() async {
    if (_auth.userProfile == null) return;

    final emptyPatterns = UserBehaviorPatterns();
    await _auth.updateBehaviorPatterns(emptyPatterns);
    
    // Clear frequent searches
    final profile = _auth.userProfile!.copyWith(frequentSearches: []);
    await _auth.updateUserProfile(profile);
  }
}
