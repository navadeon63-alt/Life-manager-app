import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class ConnectivityService {
  static final ConnectivityService _instance = ConnectivityService._internal();
  factory ConnectivityService() => _instance;
  ConnectivityService._internal();

  final Connectivity _connectivity = Connectivity();
  StreamSubscription<ConnectivityResult>? _subscription;
  
  final StreamController<bool> _connectionController = 
      StreamController<bool>.broadcast();
  
  bool _isConnected = true;
  bool _wasConnected = true;

  Stream<bool> get connectionStream => _connectionController.stream;
  bool get isConnected => _isConnected;
  bool get wasConnected => _wasConnected;

  Future<void> initialize() async {
    // Check initial connection state
    final result = await _connectivity.checkConnectivity();
    _updateConnectionStatus(result);

    // Listen for connection changes
    _subscription = _connectivity.onConnectivityChanged.listen((result) {
      _updateConnectionStatus(result);
    });
  }

  void _updateConnectionStatus(ConnectivityResult result) {
    _wasConnected = _isConnected;
    _isConnected = result != ConnectivityResult.none;
    _connectionController.add(_isConnected);
  }

  Future<bool> checkConnection() async {
    final result = await _connectivity.checkConnectivity();
    _updateConnectionStatus(result);
    return _isConnected;
  }

  void dispose() {
    _subscription?.cancel();
    _connectionController.close();
  }
}

// Simple connection status enum for UI
enum ConnectionStatus {
  online,
  offline,
  checking,
}

extension ConnectionStatusExtension on ConnectionStatus {
  String get displayText {
    switch (this) {
      case ConnectionStatus.online:
        return 'Online';
      case ConnectionStatus.offline:
        return 'Offline';
      case ConnectionStatus.checking:
        return 'Checking...';
    }
  }

  String get icon {
    switch (this) {
      case ConnectionStatus.online:
        return '🌐';
      case ConnectionStatus.offline:
        return '📴';
      case ConnectionStatus.checking:
        return '⏳';
    }
  }
}
