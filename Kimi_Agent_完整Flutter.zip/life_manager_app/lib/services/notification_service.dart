import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:flutter_timezone/flutter_timezone.dart';
import '../core/constants.dart';
import '../models/task.dart';
import '../models/birthday.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    // Initialize timezone
    tz_data.initializeTimeZones();
    final String timeZoneName = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timeZoneName));

    // Android initialization
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    
    // iOS initialization
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    // Create notification channels
    await _createNotificationChannels();
    
    _initialized = true;
  }

  Future<void> _createNotificationChannels() async {
    const androidPlugin = AndroidFlutterLocalNotificationsPlugin();
    
    // Task reminders channel
    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        AppConstants.taskReminderChannelId,
        AppConstants.taskReminderChannelName,
        description: AppConstants.taskReminderChannelDesc,
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    // Birthday reminders channel
    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        AppConstants.birthdayReminderChannelId,
        AppConstants.birthdayReminderChannelName,
        description: AppConstants.birthdayReminderChannelDesc,
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    // Daily briefing channel
    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        AppConstants.dailyBriefingChannelId,
        AppConstants.dailyBriefingChannelName,
        description: AppConstants.dailyBriefingChannelDesc,
        importance: Importance.defaultImportance,
        playSound: true,
      ),
    );

    // General channel
    await androidPlugin.createNotificationChannel(
      const AndroidNotificationChannel(
        AppConstants.generalChannelId,
        AppConstants.generalChannelName,
        description: AppConstants.generalChannelDesc,
        importance: Importance.defaultImportance,
      ),
    );
  }

  void _onNotificationTap(NotificationResponse response) {
    // Handle notification tap - can be extended to navigate to specific screens
    final payload = response.payload;
    if (payload != null) {
      // Parse payload and navigate accordingly
    }
  }

  Future<bool> requestPermissions() async {
    final androidPlugin = _notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    
    if (androidPlugin != null) {
      final granted = await androidPlugin.requestNotificationsPermission();
      return granted ?? false;
    }

    final iosPlugin = _notifications.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();
    
    if (iosPlugin != null) {
      final granted = await iosPlugin.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      return granted ?? false;
    }

    return false;
  }

  // Show immediate notification
  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
    String channelId = AppConstants.generalChannelId,
    String channelName = AppConstants.generalChannelName,
    Importance importance = Importance.defaultImportance,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      importance: importance,
      priority: Priority.high,
      showWhen: true,
      enableVibration: true,
      playSound: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(id, title, body, details, payload: payload);
  }

  // Schedule task reminder
  Future<void> scheduleTaskReminder(Task task) async {
    if (task.dueDate == null || task.isCompleted) return;

    final reminderMinutes = task.reminderMinutesBefore ?? 
        AppConstants.defaultReminderMinutesBefore;
    final reminderTime = task.dueDate!.subtract(
      Duration(minutes: reminderMinutes),
    );

    if (reminderTime.isBefore(DateTime.now())) return;

    final androidDetails = const AndroidNotificationDetails(
      AppConstants.taskReminderChannelId,
      AppConstants.taskReminderChannelName,
      importance: Importance.high,
      priority: Priority.high,
    );

    const iosDetails = DarwinNotificationDetails();
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notifications.zonedSchedule(
      task.id.hashCode,
      'Task Reminder: ${task.title}',
      task.description ?? 'Your task is due soon!',
      tz.TZDateTime.from(reminderTime, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: 'task:${task.id}',
    );
  }

  // Cancel task reminder
  Future<void> cancelTaskReminder(String taskId) async {
    await _notifications.cancel(taskId.hashCode);
  }

  // Schedule birthday reminder
  Future<void> scheduleBirthdayReminder(Birthday birthday) async {
    if (!birthday.reminderEnabled) return;

    final daysBefore = birthday.reminderDaysBefore ?? 
        AppConstants.defaultBirthdayReminderDays;
    
    final nextBirthday = birthday.nextBirthday;
    final reminderDate = nextBirthday.subtract(Duration(days: daysBefore));
    
    // Set time to 9 AM
    final scheduledDate = tz.TZDateTime(
      tz.local,
      reminderDate.year,
      reminderDate.month,
      reminderDate.day,
      9,
      0,
    );

    if (scheduledDate.isBefore(DateTime.now())) return;

    final androidDetails = const AndroidNotificationDetails(
      AppConstants.birthdayReminderChannelId,
      AppConstants.birthdayReminderChannelName,
      importance: Importance.high,
      priority: Priority.high,
    );

    const iosDetails = DarwinNotificationDetails();
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    final age = birthday.age + 1;
    final message = daysBefore == 0
        ? "${birthday.name}'s birthday is today! They are turning $age."
        : "${birthday.name}'s birthday is in $daysBefore days! They will be turning $age.";

    await _notifications.zonedSchedule(
      birthday.id.hashCode,
      '🎂 Birthday Reminder',
      message,
      scheduledDate,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: 'birthday:${birthday.id}',
    );
  }

  // Cancel birthday reminder
  Future<void> cancelBirthdayReminder(String birthdayId) async {
    await _notifications.cancel(birthdayId.hashCode);
  }

  // Schedule daily briefing
  Future<void> scheduleDailyBriefing({TimeOfDay? time}) async {
    final briefingTime = time ?? AppConstants.defaultDailyBriefingTime;
    
    final now = DateTime.now();
    var scheduledDate = DateTime(
      now.year,
      now.month,
      now.day,
      briefingTime.hour,
      briefingTime.minute,
    );

    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    final androidDetails = const AndroidNotificationDetails(
      AppConstants.dailyBriefingChannelId,
      AppConstants.dailyBriefingChannelName,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
    );

    const iosDetails = DarwinNotificationDetails();
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notifications.zonedSchedule(
      999999, // Fixed ID for daily briefing
      '🌅 Good Morning!',
      'Your daily briefing is ready. Tap to view.',
      tz.TZDateTime.from(scheduledDate, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: 'daily_briefing',
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  // Cancel daily briefing
  Future<void> cancelDailyBriefing() async {
    await _notifications.cancel(999999);
  }

  // Show daily briefing notification
  Future<void> showDailyBriefingNotification({
    required int taskCount,
    required int birthdayCount,
    String? exchangeRate,
  }) async {
    String body = 'You have $taskCount task${taskCount != 1 ? 's' : ''} today';
    if (birthdayCount > 0) {
      body += ' and $birthdayCount birthday${birthdayCount != 1 ? 's' : ''} coming up';
    }
    body += '. Tap to view your full briefing.';

    await showNotification(
      id: 888888,
      title: '📊 Your Daily Briefing',
      body: body,
      payload: 'daily_briefing',
      channelId: AppConstants.dailyBriefingChannelId,
      channelName: AppConstants.dailyBriefingChannelName,
    );
  }

  // Cancel all notifications
  Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  // Cancel specific notification
  Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  // Get pending notifications
  Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    return await _notifications.pendingNotificationRequests();
  }

  // Check if notifications are enabled
  Future<bool> areNotificationsEnabled() async {
    final androidPlugin = _notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    
    if (androidPlugin != null) {
      final enabled = await androidPlugin.areNotificationsEnabled();
      return enabled ?? false;
    }
    
    return false;
  }

  // Schedule all reminders
  Future<void> scheduleAllReminders({
    required List<Task> tasks,
    required List<Birthday> birthdays,
  }) async {
    // Cancel all existing reminders first
    await cancelAllNotifications();

    // Schedule task reminders
    for (final task in tasks) {
      if (!task.isCompleted && task.dueDate != null) {
        await scheduleTaskReminder(task);
      }
    }

    // Schedule birthday reminders
    for (final birthday in birthdays) {
      if (birthday.reminderEnabled) {
        await scheduleBirthdayReminder(birthday);
      }
    }
  }
}
