import 'package:google_sign_in/google_sign_in.dart';
import '../core/constants.dart';
import '../models/user_profile.dart';
import 'storage_service.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [
      'email',
      'profile',
    ],
  );

  final StorageService _storage = StorageService();

  GoogleSignInAccount? _currentUser;
  UserProfile? _userProfile;

  GoogleSignInAccount? get currentUser => _currentUser;
  UserProfile? get userProfile => _userProfile;
  bool get isSignedIn => _currentUser != null;
  String? get userId => _currentUser?.id;
  String? get userEmail => _currentUser?.email;
  String? get userDisplayName => _currentUser?.displayName;
  String? get userPhotoUrl => _currentUser?.photoUrl;

  Future<void> initialize() async {
    // Check if user was previously signed in
    _currentUser = await _googleSignIn.signInSilently();
    if (_currentUser != null) {
      await _loadUserProfile();
    }
  }

  Future<GoogleSignInAccount?> signIn() async {
    try {
      _currentUser = await _googleSignIn.signIn();
      if (_currentUser != null) {
        await _loadOrCreateUserProfile();
        await _storage.setBool(AppConstants.prefKeyIsLoggedIn, true);
      }
      return _currentUser;
    } catch (e) {
      throw Exception('Sign in failed: $e');
    }
  }

  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
      _currentUser = null;
      _userProfile = null;
      await _storage.setBool(AppConstants.prefKeyIsLoggedIn, false);
    } catch (e) {
      throw Exception('Sign out failed: $e');
    }
  }

  Future<void> disconnect() async {
    try {
      await _googleSignIn.disconnect();
      _currentUser = null;
      _userProfile = null;
      await _storage.setBool(AppConstants.prefKeyIsLoggedIn, false);
    } catch (e) {
      throw Exception('Disconnect failed: $e');
    }
  }

  Future<void> _loadUserProfile() async {
    if (_currentUser == null) return;
    
    final profile = await _storage.loadUserProfile();
    if (profile != null && profile.userId == _currentUser!.id) {
      _userProfile = profile;
    } else {
      await _createUserProfile();
    }
  }

  Future<void> _loadOrCreateUserProfile() async {
    if (_currentUser == null) return;
    
    final existingProfile = await _storage.loadUserProfile();
    if (existingProfile != null && existingProfile.userId == _currentUser!.id) {
      // Update last sign in
      _userProfile = existingProfile.copyWith(
        lastSignIn: DateTime.now(),
        email: _currentUser!.email,
        displayName: _currentUser!.displayName,
        photoUrl: _currentUser!.photoUrl,
      );
    } else {
      await _createUserProfile();
    }
    
    await _storage.saveUserProfile(_userProfile!);
  }

  Future<void> _createUserProfile() async {
    if (_currentUser == null) return;
    
    _userProfile = UserProfile(
      userId: _currentUser!.id,
      email: _currentUser!.email,
      displayName: _currentUser!.displayName,
      photoUrl: _currentUser!.photoUrl,
      createdAt: DateTime.now(),
      lastSignIn: DateTime.now(),
    );
    
    await _storage.saveUserProfile(_userProfile!);
  }

  Future<void> updateUserProfile(UserProfile profile) async {
    _userProfile = profile;
    await _storage.saveUserProfile(profile);
  }

  Future<void> updatePreferences(UserPreferences preferences) async {
    if (_userProfile == null) return;
    
    _userProfile = _userProfile!.copyWith(preferences: preferences);
    await _storage.saveUserProfile(_userProfile!);
  }

  Future<void> updateBehaviorPatterns(UserBehaviorPatterns patterns) async {
    if (_userProfile == null) return;
    
    _userProfile = _userProfile!.copyWith(behaviorPatterns: patterns);
    await _storage.saveUserProfile(_userProfile!);
  }

  Future<void> addFrequentSearch(String search) async {
    if (_userProfile == null) return;
    
    final searches = List<String>.from(_userProfile!.frequentSearches);
    if (!searches.contains(search)) {
      searches.add(search);
      // Keep only last 20 searches
      if (searches.length > 20) {
        searches.removeAt(0);
      }
      
      _userProfile = _userProfile!.copyWith(frequentSearches: searches);
      await _storage.saveUserProfile(_userProfile!);
    }
  }

  Future<void> setModelDownloaded(bool downloaded) async {
    if (_userProfile == null) return;
    
    _userProfile = _userProfile!.copyWith(hasDownloadedModel: downloaded);
    await _storage.saveUserProfile(_userProfile!);
    await _storage.setBool(AppConstants.prefKeyHasDownloadedModel, downloaded);
  }

  Future<void> setPreferredAiModel(String model) async {
    if (_userProfile == null) return;
    
    _userProfile = _userProfile!.copyWith(preferredAiModel: model);
    await _storage.saveUserProfile(_userProfile!);
    await _storage.setString(AppConstants.prefKeyPreferredAiModel, model);
  }

  Future<void> clearUserData() async {
    await _storage.clearAll();
    _userProfile = null;
  }
}
