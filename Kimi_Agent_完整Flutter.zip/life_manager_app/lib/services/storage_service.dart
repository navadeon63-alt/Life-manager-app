import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants.dart';
import '../models/task.dart';
import '../models/note.dart';
import '../models/finance.dart';
import '../models/birthday.dart';
import '../models/chat_message.dart';
import '../models/user_profile.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  Directory? _appDir;
  SharedPreferences? _prefs;

  Future<void> initialize() async {
    _appDir = await getApplicationDocumentsDirectory();
    _prefs = await SharedPreferences.getInstance();
  }

  String get _basePath => _appDir?.path ?? '';

  // Generic file operations
  Future<void> _writeToFile(String filename, dynamic data) async {
    try {
      final file = File('$_basePath/$filename');
      final jsonString = jsonEncode(data);
      await file.writeAsString(jsonString);
    } catch (e) {
      throw Exception('Failed to write to $filename: $e');
    }
  }

  Future<dynamic> _readFromFile(String filename) async {
    try {
      final file = File('$_basePath/$filename');
      if (!await file.exists()) return null;
      final jsonString = await file.readAsString();
      return jsonDecode(jsonString);
    } catch (e) {
      throw Exception('Failed to read from $filename: $e');
    }
  }

  Future<void> _deleteFile(String filename) async {
    try {
      final file = File('$_basePath/$filename');
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      throw Exception('Failed to delete $filename: $e');
    }
  }

  // Tasks
  Future<void> saveTasks(List<Task> tasks) async {
    final data = tasks.map((t) => t.toJson()).toList();
    await _writeToFile(AppConstants.tasksFile, data);
  }

  Future<List<Task>> loadTasks() async {
    final data = await _readFromFile(AppConstants.tasksFile);
    if (data == null) return [];
    return (data as List).map((json) => Task.fromJson(json)).toList();
  }

  Future<void> deleteTask(String id) async {
    final tasks = await loadTasks();
    tasks.removeWhere((t) => t.id == id);
    await saveTasks(tasks);
  }

  // Notes
  Future<void> saveNotes(List<Note> notes) async {
    final data = notes.map((n) => n.toJson()).toList();
    await _writeToFile(AppConstants.notesFile, data);
  }

  Future<List<Note>> loadNotes() async {
    final data = await _readFromFile(AppConstants.notesFile);
    if (data == null) return [];
    return (data as List).map((json) => Note.fromJson(json)).toList();
  }

  Future<void> deleteNote(String id) async {
    final notes = await loadNotes();
    notes.removeWhere((n) => n.id == id);
    await saveNotes(notes);
  }

  // Finances
  Future<void> saveFinances(List<FinanceEntry> entries) async {
    final data = entries.map((f) => f.toJson()).toList();
    await _writeToFile(AppConstants.financesFile, data);
  }

  Future<List<FinanceEntry>> loadFinances() async {
    final data = await _readFromFile(AppConstants.financesFile);
    if (data == null) return [];
    return (data as List).map((json) => FinanceEntry.fromJson(json)).toList();
  }

  Future<void> deleteFinance(String id) async {
    final finances = await loadFinances();
    finances.removeWhere((f) => f.id == id);
    await saveFinances(finances);
  }

  // Budgets
  Future<void> saveBudgets(List<Budget> budgets) async {
    final data = budgets.map((b) => b.toJson()).toList();
    await _writeToFile(AppConstants.budgetsFile, data);
  }

  Future<List<Budget>> loadBudgets() async {
    final data = await _readFromFile(AppConstants.budgetsFile);
    if (data == null) return [];
    return (data as List).map((json) => Budget.fromJson(json)).toList();
  }

  // Birthdays
  Future<void> saveBirthdays(List<Birthday> birthdays) async {
    final data = birthdays.map((b) => b.toJson()).toList();
    await _writeToFile(AppConstants.birthdaysFile, data);
  }

  Future<List<Birthday>> loadBirthdays() async {
    final data = await _readFromFile(AppConstants.birthdaysFile);
    if (data == null) return [];
    return (data as List).map((json) => Birthday.fromJson(json)).toList();
  }

  Future<void> deleteBirthday(String id) async {
    final birthdays = await loadBirthdays();
    birthdays.removeWhere((b) => b.id == id);
    await saveBirthdays(birthdays);
  }

  // Chat History
  Future<void> saveChatHistory(List<ChatSession> sessions) async {
    final data = sessions.map((s) => s.toJson()).toList();
    await _writeToFile(AppConstants.chatHistoryFile, data);
  }

  Future<List<ChatSession>> loadChatHistory() async {
    final data = await _readFromFile(AppConstants.chatHistoryFile);
    if (data == null) return [];
    return (data as List).map((json) => ChatSession.fromJson(json)).toList();
  }

  Future<void> deleteChatSession(String id) async {
    final sessions = await loadChatHistory();
    sessions.removeWhere((s) => s.id == id);
    await saveChatHistory(sessions);
  }

  // User Profile
  Future<void> saveUserProfile(UserProfile profile) async {
    await _writeToFile(AppConstants.userProfileFile, profile.toJson());
    await _prefs?.setString(AppConstants.prefKeyUserId, profile.userId);
  }

  Future<UserProfile?> loadUserProfile() async {
    final data = await _readFromFile(AppConstants.userProfileFile);
    if (data == null) return null;
    return UserProfile.fromJson(data);
  }

  Future<void> deleteUserProfile() async {
    await _deleteFile(AppConstants.userProfileFile);
    await _prefs?.remove(AppConstants.prefKeyUserId);
  }

  // Shared Preferences Helpers
  Future<void> setString(String key, String value) async {
    await _prefs?.setString(key, value);
  }

  String? getString(String key) {
    return _prefs?.getString(key);
  }

  Future<void> setBool(String key, bool value) async {
    await _prefs?.setBool(key, value);
  }

  bool? getBool(String key) {
    return _prefs?.getBool(key);
  }

  Future<void> setInt(String key, int value) async {
    await _prefs?.setInt(key, value);
  }

  int? getInt(String key) {
    return _prefs?.getInt(key);
  }

  Future<void> remove(String key) async {
    await _prefs?.remove(key);
  }

  Future<void> clearAll() async {
    await _prefs?.clear();
    // Delete all JSON files
    final files = [
      AppConstants.tasksFile,
      AppConstants.notesFile,
      AppConstants.financesFile,
      AppConstants.birthdaysFile,
      AppConstants.chatHistoryFile,
      AppConstants.userProfileFile,
      AppConstants.budgetsFile,
    ];
    for (final filename in files) {
      await _deleteFile(filename);
    }
  }

  // Image Storage
  Future<String> saveImage(File imageFile, String filename) async {
    final imagesDir = Directory('$_basePath/images');
    if (!await imagesDir.exists()) {
      await imagesDir.create(recursive: true);
    }
    final destination = File('${imagesDir.path}/$filename');
    await imageFile.copy(destination.path);
    return destination.path;
  }

  Future<void> deleteImage(String path) async {
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (e) {
      // Ignore deletion errors
    }
  }

  // Backup & Restore
  Future<String> createBackup() async {
    final backupData = <String, dynamic>{};
    
    final tasks = await _readFromFile(AppConstants.tasksFile);
    if (tasks != null) backupData['tasks'] = tasks;
    
    final notes = await _readFromFile(AppConstants.notesFile);
    if (notes != null) backupData['notes'] = notes;
    
    final finances = await _readFromFile(AppConstants.financesFile);
    if (finances != null) backupData['finances'] = finances;
    
    final birthdays = await _readFromFile(AppConstants.birthdaysFile);
    if (birthdays != null) backupData['birthdays'] = birthdays;
    
    final chatHistory = await _readFromFile(AppConstants.chatHistoryFile);
    if (chatHistory != null) backupData['chatHistory'] = chatHistory;
    
    final userProfile = await _readFromFile(AppConstants.userProfileFile);
    if (userProfile != null) backupData['userProfile'] = userProfile;
    
    final budgets = await _readFromFile(AppConstants.budgetsFile);
    if (budgets != null) backupData['budgets'] = budgets;

    final backupFile = File('$_basePath/backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await backupFile.writeAsString(jsonEncode(backupData));
    return backupFile.path;
  }

  Future<void> restoreFromBackup(String backupPath) async {
    final backupFile = File(backupPath);
    if (!await backupFile.exists()) {
      throw Exception('Backup file not found');
    }
    
    final jsonString = await backupFile.readAsString();
    final backupData = jsonDecode(jsonString) as Map<String, dynamic>;
    
    if (backupData['tasks'] != null) {
      await _writeToFile(AppConstants.tasksFile, backupData['tasks']);
    }
    if (backupData['notes'] != null) {
      await _writeToFile(AppConstants.notesFile, backupData['notes']);
    }
    if (backupData['finances'] != null) {
      await _writeToFile(AppConstants.financesFile, backupData['finances']);
    }
    if (backupData['birthdays'] != null) {
      await _writeToFile(AppConstants.birthdaysFile, backupData['birthdays']);
    }
    if (backupData['chatHistory'] != null) {
      await _writeToFile(AppConstants.chatHistoryFile, backupData['chatHistory']);
    }
    if (backupData['userProfile'] != null) {
      await _writeToFile(AppConstants.userProfileFile, backupData['userProfile']);
    }
    if (backupData['budgets'] != null) {
      await _writeToFile(AppConstants.budgetsFile, backupData['budgets']);
    }
  }

  // Statistics
  Future<Map<String, int>> getStorageStats() async {
    final stats = <String, int>{};
    
    final files = [
      AppConstants.tasksFile,
      AppConstants.notesFile,
      AppConstants.financesFile,
      AppConstants.birthdaysFile,
      AppConstants.chatHistoryFile,
      AppConstants.userProfileFile,
      AppConstants.budgetsFile,
    ];
    
    for (final filename in files) {
      try {
        final file = File('$_basePath/$filename');
        if (await file.exists()) {
          final content = await file.readAsString();
          final data = jsonDecode(content);
          if (data is List) {
            stats[filename] = data.length;
          } else {
            stats[filename] = 1;
          }
        } else {
          stats[filename] = 0;
        }
      } catch (e) {
        stats[filename] = -1;
      }
    }
    
    return stats;
  }
}
