import 'dart:convert';
import 'dart:io';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:http/http.dart' as http;
import '../core/constants.dart';
import '../models/chat_message.dart';
import 'ai_service.dart';

class OnlineAIService implements AIService {
  static final OnlineAIService _instance = OnlineAIService._internal();
  factory OnlineAIService() => _instance;
  OnlineAIService._internal();

  GenerativeModel? _model;
  ChatSession? _chatSession;
  String? _apiKey;

  // Default API key - should be replaced with user's key or environment variable
  static const String _defaultApiKey = 'YOUR_GEMINI_API_KEY';

  Future<void> initialize() async {
    // Try to load API key from environment or secure storage
    _apiKey = await _loadApiKey();
    
    if (_apiKey != null && _apiKey!.isNotEmpty && _apiKey != _defaultApiKey) {
      _initializeModel();
    }
  }

  Future<String?> _loadApiKey() async {
    // In production, load from secure storage or environment
    // For now, return the default (user should replace)
    return _defaultApiKey;
  }

  void _initializeModel() {
    if (_apiKey == null || _apiKey!.isEmpty) return;

    _model = GenerativeModel(
      model: AppConstants.geminiModelName,
      apiKey: _apiKey!,
      generationConfig: GenerationConfig(
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 2048,
      ),
      safetySettings: [
        SafetySetting(HarmCategory.harassment, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.hateSpeech, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.sexuallyExplicit, HarmBlockThreshold.medium),
        SafetySetting(HarmCategory.dangerousContent, HarmBlockThreshold.medium),
      ],
    );

    _chatSession = _model!.startChat();
  }

  void setApiKey(String apiKey) {
    _apiKey = apiKey;
    _initializeModel();
  }

  @override
  Future<bool> isAvailable() async {
    if (_model == null || _apiKey == null || _apiKey == _defaultApiKey) {
      return false;
    }

    try {
      // Test with a simple request
      final response = await _model!.generateContent([Content.text('Hi')]);
      return response.text != null;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<ChatMessage> sendMessage(String message, {String? imagePath}) async {
    if (_model == null) {
      return ChatMessage(
        content: 'Gemini API not configured. Please set your API key.',
        isUser: false,
        type: MessageType.error,
      );
    }

    try {
      Content content;
      
      if (imagePath != null && await File(imagePath).exists()) {
        // Multi-modal input with image
        final imageBytes = await File(imagePath).readAsBytes();
        final imagePart = DataPart('image/jpeg', imageBytes);
        content = Content.multi([
          TextPart(message),
          imagePart,
        ]);
      } else {
        content = Content.text(message);
      }

      final response = await _chatSession!.sendMessage(content);
      
      return ChatMessage(
        content: response.text ?? 'No response received',
        isUser: false,
        type: MessageType.text,
        isOffline: false,
        modelUsed: modelName,
      );
    } catch (e) {
      return ChatMessage(
        content: 'Error: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  @override
  Future<ChatMessage> analyzeImage(File image, {String? prompt}) async {
    if (_model == null) {
      return ChatMessage(
        content: 'Gemini API not configured. Please set your API key.',
        isUser: false,
        type: MessageType.error,
      );
    }

    try {
      final imageBytes = await image.readAsBytes();
      final imagePart = DataPart('image/jpeg', imageBytes);
      
      final analysisPrompt = prompt ?? 
          'Analyze this image and describe what you see. If it contains a receipt, document, or item, extract relevant information.';
      
      final content = Content.multi([
        TextPart(analysisPrompt),
        imagePart,
      ]);

      final response = await _model!.generateContent([content]);
      
      return ChatMessage(
        content: response.text ?? 'Could not analyze image',
        isUser: false,
        type: MessageType.image,
        imagePath: image.path,
        isOffline: false,
        modelUsed: modelName,
      );
    } catch (e) {
      return ChatMessage(
        content: 'Error analyzing image: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  // Search with Google Search grounding
  Future<ChatMessage> searchWithGrounding(String query) async {
    if (_model == null) {
      return ChatMessage(
        content: 'Gemini API not configured. Please set your API key.',
        isUser: false,
        type: MessageType.error,
      );
    }

    try {
      // Use tools for search grounding
      final tools = [
        Tool.googleSearchRetrieval(
          GoogleSearchRetrieval(
            dynamicRetrievalConfig: DynamicRetrievalConfig(
              dynamicThreshold: 0.7,
              mode: DynamicRetrievalMode.modeDynamic,
            ),
          ),
        ),
      ];

      final modelWithSearch = GenerativeModel(
        model: AppConstants.geminiModelName,
        apiKey: _apiKey!,
        tools: tools,
      );

      final response = await modelWithSearch.generateContent([
        Content.text(query),
      ]);

      // Extract sources if available
      List<String>? sources;
      if (response.candidates.isNotEmpty) {
        final candidate = response.candidates.first;
        // Sources would be extracted from grounding metadata
      }

      return ChatMessage(
        content: response.text ?? 'No results found',
        isUser: false,
        type: MessageType.search,
        sources: sources,
        isOffline: false,
        modelUsed: modelName,
      );
    } catch (e) {
      return ChatMessage(
        content: 'Search failed: $e',
        isUser: false,
        type: MessageType.error,
      );
    }
  }

  // Get exchange rate for ZAR
  Future<Map<String, dynamic>?> getExchangeRate() async {
    try {
      final searchQuery = 'ZAR USD EUR GBP exchange rate today South Africa rand';
      final response = await searchWithGrounding(searchQuery);
      
      // Parse the response to extract rates
      final content = response.content;
      
      // Extract rates using regex
      final usdMatch = RegExp(r'USD[\/\s]*ZAR[\s:]*([\d.]+)', caseSensitive: false).firstMatch(content);
      final eurMatch = RegExp(r'EUR[\/\s]*ZAR[\s:]*([\d.]+)', caseSensitive: false).firstMatch(content);
      final gbpMatch = RegExp(r'GBP[\/\s]*ZAR[\s:]*([\d.]+)', caseSensitive: false).firstMatch(content);

      return {
        'zarToUsd': usdMatch != null ? double.tryParse(usdMatch.group(1) ?? '0') ?? 0 : 0,
        'zarToEur': eurMatch != null ? double.tryParse(eurMatch.group(1) ?? '0') ?? 0 : 0,
        'zarToGbp': gbpMatch != null ? double.tryParse(gbpMatch.group(1) ?? '0') ?? 0 : 0,
        'rawResponse': content,
        'lastUpdated': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return null;
    }
  }

  // Get South Africa economy update
  Future<Map<String, dynamic>?> getSAEconomyUpdate() async {
    try {
      final queries = [
        'South Africa economy news today headline',
        'South Africa inflation rate interest rate SARB today',
        'Eskom load shedding schedule today South Africa',
        'South Africa cost of living food prices today',
      ];

      final results = <String, dynamic>{};
      
      for (final query in queries) {
        try {
          final response = await searchWithGrounding(query);
          results[query] = response.content;
        } catch (e) {
          results[query] = 'Failed to fetch: $e';
        }
      }

      // Compile into structured update
      final compiledResponse = await _compileEconomyUpdate(results);
      
      return {
        'headline': 'South Africa Economy Update',
        'summary': compiledResponse,
        'keyPoints': results.entries.map((e) => '${e.key}: ${e.value}').toList(),
        'source': 'Google Search via Gemini',
        'publishedAt': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return null;
    }
  }

  Future<String> _compileEconomyUpdate(Map<String, dynamic> results) async {
    if (_model == null) return 'AI service unavailable';

    try {
      final prompt = '''
Compile the following search results into a brief summary (2-3 sentences) about the current South African economic situation:

${results.entries.map((e) => '- ${e.key}: ${e.value}').join('\n')}

Focus on: rand exchange rate, inflation, interest rates, and load shedding status.
'';

      final response = await _model!.generateContent([Content.text(prompt)]);
      return response.text ?? 'Could not compile update';
    } catch (e) {
      return 'Error compiling update: $e';
    }
  }

  // Stream response for real-time updates
  Stream<String> generateResponseStream(String message) async* {
    if (_model == null) {
      yield 'Gemini API not configured.';
      return;
    }

    try {
      final stream = _chatSession!.sendMessageStream(Content.text(message));
      
      await for (final response in stream) {
        if (response.text != null) {
          yield response.text!;
        }
      }
    } catch (e) {
      yield 'Error: $e';
    }
  }

  @override
  String get modelName => AppConstants.geminiModelName;

  @override
  bool get isLocal => false;

  // Reset chat session
  void resetChat() {
    if (_model != null) {
      _chatSession = _model!.startChat();
    }
  }
}
