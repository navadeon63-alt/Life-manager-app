import 'package:flutter/material.dart';

class AppConstants {
  // App Info
  static const String appName = 'Life Manager';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'Your AI-powered personal life assistant';

  // Storage File Names
  static const String tasksFile = 'tasks.json';
  static const String notesFile = 'notes.json';
  static const String financesFile = 'finances.json';
  static const String birthdaysFile = 'birthdays.json';
  static const String chatHistoryFile = 'chat_history.json';
  static const String userProfileFile = 'user_profile.json';
  static const String budgetsFile = 'budgets.json';

  // AI Model Settings
  static const String gemmaModelName = 'gemma-2b-it-q4f16_1';
  static const String geminiModelName = 'gemini-1.5-flash';
  static const int maxChatHistory = 50;
  static const int aiResponseTimeoutSeconds = 30;

  // Currency
  static const String defaultCurrency = 'ZAR';
  static const String currencySymbol = 'R';

  // Notification Channels
  static const String taskReminderChannelId = 'task_reminders';
  static const String taskReminderChannelName = 'Task Reminders';
  static const String taskReminderChannelDesc = 'Notifications for upcoming tasks';
  
  static const String birthdayReminderChannelId = 'birthday_reminders';
  static const String birthdayReminderChannelName = 'Birthday Reminders';
  static const String birthdayReminderChannelDesc = 'Notifications for upcoming birthdays';
  
  static const String dailyBriefingChannelId = 'daily_briefing';
  static const String dailyBriefingChannelName = 'Daily Briefing';
  static const String dailyBriefingChannelDesc = 'Your daily morning briefing';
  
  static const String generalChannelId = 'general';
  static const String generalChannelName = 'General';
  static const String generalChannelDesc = 'General app notifications';

  // Default Values
  static const int defaultReminderMinutesBefore = 30;
  static const int defaultBirthdayReminderDays = 7;
  static const TimeOfDay defaultDailyBriefingTime = TimeOfDay(hour: 7, minute: 0);

  // API Endpoints (for future use)
  static const String geminiApiBaseUrl = 'https://generativelanguage.googleapis.com';
  
  // Search Keywords for Daily Briefing
  static const List<String> saEconomySearchKeywords = [
    'South Africa economy news today',
    'ZAR USD exchange rate',
    'South African rand rate',
    'Eskom load shedding schedule',
    'South Africa cost of living',
    'SA inflation rate',
    'South Africa interest rate',
    'JSE all share index',
  ];

  // Expense Categories
  static const List<String> defaultExpenseCategories = [
    'Food & Dining',
    'Transport',
    'Shopping',
    'Entertainment',
    'Bills & Utilities',
    'Health & Medical',
    'Education',
    'Housing',
    'Insurance',
    'Personal Care',
    'Gifts & Donations',
    'Travel',
    'Other',
  ];

  // Income Categories
  static const List<String> defaultIncomeCategories = [
    'Salary',
    'Freelance',
    'Investments',
    'Business',
    'Rental Income',
    'Gifts',
    'Refunds',
    'Other',
  ];

  // Task Categories
  static const List<String> defaultTaskCategories = [
    'Work',
    'Personal',
    'Health',
    'Finance',
    'Shopping',
    'Home',
    'Education',
    'Other',
  ];

  // Note Categories
  static const List<String> defaultNoteCategories = [
    'Personal',
    'Work',
    'Ideas',
    'Journal',
    'Study',
    'Travel',
    'Recipes',
    'Other',
  ];

  // Relationships for Birthdays
  static const List<String> relationshipTypes = [
    'Family',
    'Friend',
    'Colleague',
    'Partner',
    'Acquaintance',
    'Other',
  ];

  // Colors for UI
  static const Map<String, Color> categoryColors = {
    'Work': Color(0xFF6366F1),
    'Personal': Color(0xFFEC4899),
    'Health': Color(0xFF10B981),
    'Finance': Color(0xFFF59E0B),
    'Shopping': Color(0xFF8B5CF6),
    'Home': Color(0xFF14B8A6),
    'Education': Color(0xFF3B82F6),
    'Other': Color(0xFF6B7280),
  };

  // Priority Colors
  static const Color priorityLowColor = Color(0xFF10B981);
  static const Color priorityMediumColor = Color(0xFFF59E0B);
  static const Color priorityHighColor = Color(0xFFF97316);
  static const Color priorityUrgentColor = Color(0xFFEF4444);

  // Animation Durations
  static const Duration shortAnimationDuration = Duration(milliseconds: 200);
  static const Duration mediumAnimationDuration = Duration(milliseconds: 350);
  static const Duration longAnimationDuration = Duration(milliseconds: 500);

  // Timeouts
  static const Duration connectionTimeout = Duration(seconds: 10);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // Limits
  static const int maxImageSizeMB = 10;
  static const int maxChatMessageLength = 2000;
  static const int maxTasksFree = 100;
  static const int maxNotesFree = 100;
  static const int maxFinancesFree = 500;

  // Shared Preferences Keys
  static const String prefKeyUserId = 'user_id';
  static const String prefKeyIsLoggedIn = 'is_logged_in';
  static const String prefKeyLastSync = 'last_sync';
  static const String prefKeyDarkMode = 'dark_mode';
  static const String prefKeyNotificationsEnabled = 'notifications_enabled';
  static const String prefKeyDailyBriefingEnabled = 'daily_briefing_enabled';
  static const String prefKeyDailyBriefingHour = 'daily_briefing_hour';
  static const String prefKeyDailyBriefingMinute = 'daily_briefing_minute';
  static const String prefKeyHasSeenOnboarding = 'has_seen_onboarding';
  static const String prefKeyHasDownloadedModel = 'has_downloaded_model';
  static const String prefKeyPreferredAiModel = 'preferred_ai_model';
  static const String prefKeyLastDailyBriefing = 'last_daily_briefing';
}

class AssetPaths {
  static const String imagesDir = 'assets/images/';
  static const String iconsDir = 'assets/icons/';
  static const String modelsDir = 'assets/models/';
  
  static const String logo = '${imagesDir}logo.png';
  static const String placeholderImage = '${imagesDir}placeholder.png';
  static const String emptyStateImage = '${imagesDir}empty_state.png';
}

class ErrorMessages {
  static const String genericError = 'Something went wrong. Please try again.';
  static const String networkError = 'No internet connection. Please check your network.';
  static const String authError = 'Authentication failed. Please sign in again.';
  static const String storageError = 'Failed to save data. Please try again.';
  static const String aiError = 'AI service is temporarily unavailable. Please try again later.';
  static const String cameraError = 'Could not access camera. Please check permissions.';
  static const String invalidInput = 'Please check your input and try again.';
  static const String notFound = 'Item not found.';
  static const String permissionDenied = 'Permission denied. Please enable in settings.';
}

class SuccessMessages {
  static const String taskCreated = 'Task created successfully!';
  static const String taskUpdated = 'Task updated successfully!';
  static const String taskDeleted = 'Task deleted successfully!';
  static const String taskCompleted = 'Task completed! Great job!';
  static const String noteCreated = 'Note saved successfully!';
  static const String noteUpdated = 'Note updated successfully!';
  static const String noteDeleted = 'Note deleted successfully!';
  static const String financeAdded = 'Transaction recorded successfully!';
  static const String financeUpdated = 'Transaction updated successfully!';
  static const String financeDeleted = 'Transaction deleted successfully!';
  static const String birthdayAdded = 'Birthday added successfully!';
  static const String birthdayUpdated = 'Birthday updated successfully!';
  static const String birthdayDeleted = 'Birthday deleted successfully!';
  static const String settingsSaved = 'Settings saved successfully!';
  static const String signOutSuccess = 'Signed out successfully!';
  static const String modelDownloaded = 'AI model downloaded successfully!';
}
