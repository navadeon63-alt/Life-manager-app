import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'finance.g.dart';

@JsonSerializable()
class FinanceEntry {
  final String id;
  String title;
  double amount;
  FinanceType type;
  DateTime date;
  String? category;
  String? description;
  String? imagePath;
  String? paymentMethod;
  bool isRecurring;
  RecurringFrequency? recurringFrequency;
  List<String> tags;

  FinanceEntry({
    String? id,
    required this.title,
    required this.amount,
    required this.type,
    DateTime? date,
    this.category,
    this.description,
    this.imagePath,
    this.paymentMethod,
    this.isRecurring = false,
    this.recurringFrequency,
    List<String>? tags,
  })  : id = id ?? const Uuid().v4(),
        date = date ?? DateTime.now(),
        tags = tags ?? [];

  factory FinanceEntry.fromJson(Map<String, dynamic> json) =>
      _$FinanceEntryFromJson(json);

  Map<String, dynamic> toJson() => _$FinanceEntryToJson(this);

  FinanceEntry copyWith({
    String? title,
    double? amount,
    FinanceType? type,
    DateTime? date,
    String? category,
    String? description,
    String? imagePath,
    String? paymentMethod,
    bool? isRecurring,
    RecurringFrequency? recurringFrequency,
    List<String>? tags,
  }) {
    return FinanceEntry(
      id: id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      date: date ?? this.date,
      category: category ?? this.category,
      description: description ?? this.description,
      imagePath: imagePath ?? this.imagePath,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      isRecurring: isRecurring ?? this.isRecurring,
      recurringFrequency: recurringFrequency ?? this.recurringFrequency,
      tags: tags ?? this.tags,
    );
  }

  bool get isIncome => type == FinanceType.income;
  bool get isExpense => type == FinanceType.expense;

  String get formattedAmount {
    final prefix = isIncome ? '+' : '-';
    return '$prefix\R${amount.toStringAsFixed(2)}';
  }
}

enum FinanceType { income, expense }

enum RecurringFrequency { daily, weekly, monthly, yearly }

extension RecurringFrequencyExtension on RecurringFrequency {
  String get displayName {
    switch (this) {
      case RecurringFrequency.daily:
        return 'Daily';
      case RecurringFrequency.weekly:
        return 'Weekly';
      case RecurringFrequency.monthly:
        return 'Monthly';
      case RecurringFrequency.yearly:
        return 'Yearly';
    }
  }
}

@JsonSerializable()
class Budget {
  final String id;
  String category;
  double limit;
  double spent;
  DateTime createdAt;
  DateTime? resetDate;
  BudgetPeriod period;

  Budget({
    String? id,
    required this.category,
    required this.limit,
    this.spent = 0.0,
    DateTime? createdAt,
    this.resetDate,
    this.period = BudgetPeriod.monthly,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now();

  factory Budget.fromJson(Map<String, dynamic> json) => _$BudgetFromJson(json);

  Map<String, dynamic> toJson() => _$BudgetToJson(this);

  double get remaining => limit - spent;
  double get percentageUsed => (spent / limit) * 100;
  bool get isOverBudget => spent > limit;
}

enum BudgetPeriod { daily, weekly, monthly, yearly }

@JsonSerializable()
class FinanceSummary {
  final double totalIncome;
  final double totalExpenses;
  final double balance;
  final Map<String, double> categoryBreakdown;
  final DateTime generatedAt;

  FinanceSummary({
    required this.totalIncome,
    required this.totalExpenses,
    required this.balance,
    required this.categoryBreakdown,
    DateTime? generatedAt,
  }) : generatedAt = generatedAt ?? DateTime.now();

  factory FinanceSummary.fromJson(Map<String, dynamic> json) =>
      _$FinanceSummaryFromJson(json);

  Map<String, dynamic> toJson() => _$FinanceSummaryToJson(this);
}
