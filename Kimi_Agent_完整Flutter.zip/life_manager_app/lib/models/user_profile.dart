import 'package:json_annotation/json_annotation.dart';

part 'user_profile.g.dart';

@JsonSerializable()
class UserProfile {
  final String userId;
  String? email;
  String? displayName;
  String? photoUrl;
  DateTime? createdAt;
  DateTime? lastSignIn;
  UserPreferences preferences;
  UserBehaviorPatterns behaviorPatterns;
  List<String> frequentSearches;
  Map<String, dynamic> aiContext;
  bool hasDownloadedModel;
  String? preferredAiModel;

  UserProfile({
    required this.userId,
    this.email,
    this.displayName,
    this.photoUrl,
    this.createdAt,
    this.lastSignIn,
    UserPreferences? preferences,
    UserBehaviorPatterns? behaviorPatterns,
    List<String>? frequentSearches,
    Map<String, dynamic>? aiContext,
    this.hasDownloadedModel = false,
    this.preferredAiModel,
  })  : preferences = preferences ?? UserPreferences(),
        behaviorPatterns = behaviorPatterns ?? UserBehaviorPatterns(),
        frequentSearches = frequentSearches ?? [],
        aiContext = aiContext ?? {};

  factory UserProfile.fromJson(Map<String, dynamic> json) =>
      _$UserProfileFromJson(json);

  Map<String, dynamic> toJson() => _$UserProfileToJson(this);

  UserProfile copyWith({
    String? email,
    String? displayName,
    String? photoUrl,
    DateTime? lastSignIn,
    UserPreferences? preferences,
    UserBehaviorPatterns? behaviorPatterns,
    List<String>? frequentSearches,
    Map<String, dynamic>? aiContext,
    bool? hasDownloadedModel,
    String? preferredAiModel,
  }) {
    return UserProfile(
      userId: userId,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      createdAt: createdAt,
      lastSignIn: lastSignIn ?? this.lastSignIn,
      preferences: preferences ?? this.preferences,
      behaviorPatterns: behaviorPatterns ?? this.behaviorPatterns,
      frequentSearches: frequentSearches ?? this.frequentSearches,
      aiContext: aiContext ?? this.aiContext,
      hasDownloadedModel: hasDownloadedModel ?? this.hasDownloadedModel,
      preferredAiModel: preferredAiModel ?? this.preferredAiModel,
    );
  }
}

@JsonSerializable()
class UserPreferences {
  bool darkMode;
  bool notificationsEnabled;
  bool dailyBriefingEnabled;
  TimeOfDay? dailyBriefingTime;
  String currency;
  String? defaultTaskCategory;
  List<String> expenseCategories;
  List<String> incomeCategories;
  List<String> noteCategories;

  UserPreferences({
    this.darkMode = true,
    this.notificationsEnabled = true,
    this.dailyBriefingEnabled = true,
    this.dailyBriefingTime,
    this.currency = 'ZAR',
    this.defaultTaskCategory,
    List<String>? expenseCategories,
    List<String>? incomeCategories,
    List<String>? noteCategories,
  })  : expenseCategories = expenseCategories ??
            [
              'Food & Dining',
              'Transport',
              'Shopping',
              'Entertainment',
              'Bills',
              'Health',
              'Education',
              'Other'
            ],
        incomeCategories = incomeCategories ??
            ['Salary', 'Freelance', 'Investments', 'Gifts', 'Other'],
        noteCategories = noteCategories ??
            ['Personal', 'Work', 'Ideas', 'Journal', 'Other'];

  factory UserPreferences.fromJson(Map<String, dynamic> json) =>
      _$UserPreferencesFromJson(json);

  Map<String, dynamic> toJson() => _$UserPreferencesToJson(this);
}

@JsonSerializable()
class TimeOfDay {
  final int hour;
  final int minute;

  TimeOfDay({required this.hour, required this.minute});

  factory TimeOfDay.fromJson(Map<String, dynamic> json) =>
      _$TimeOfDayFromJson(json);

  Map<String, dynamic> toJson() => _$TimeOfDayToJson(this);

  String get formatted => '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
}

@JsonSerializable()
class UserBehaviorPatterns {
  Map<String, int> taskCompletionByHour;
  Map<String, double> spendingByCategory;
  Map<String, int> taskCategoryFrequency;
  List<String> productiveHours;
  double averageDailyExpense;
  double averageMonthlyIncome;
  Map<String, int> appUsageByDay;
  DateTime? lastUpdated;

  UserBehaviorPatterns({
    Map<String, int>? taskCompletionByHour,
    Map<String, double>? spendingByCategory,
    Map<String, int>? taskCategoryFrequency,
    List<String>? productiveHours,
    this.averageDailyExpense = 0.0,
    this.averageMonthlyIncome = 0.0,
    Map<String, int>? appUsageByDay,
    this.lastUpdated,
  })  : taskCompletionByHour = taskCompletionByHour ?? {},
        spendingByCategory = spendingByCategory ?? {},
        taskCategoryFrequency = taskCategoryFrequency ?? {},
        productiveHours = productiveHours ?? [],
        appUsageByDay = appUsageByDay ?? {};

  factory UserBehaviorPatterns.fromJson(Map<String, dynamic> json) =>
      _$UserBehaviorPatternsFromJson(json);

  Map<String, dynamic> toJson() => _$UserBehaviorPatternsToJson(this);

  void updateTaskCompletion(int hour) {
    final hourKey = hour.toString();
    taskCompletionByHour[hourKey] = (taskCompletionByHour[hourKey] ?? 0) + 1;
    _updateProductiveHours();
    lastUpdated = DateTime.now();
  }

  void updateSpending(String category, double amount) {
    spendingByCategory[category] = (spendingByCategory[category] ?? 0) + amount;
    lastUpdated = DateTime.now();
  }

  void updateTaskCategory(String category) {
    taskCategoryFrequency[category] = (taskCategoryFrequency[category] ?? 0) + 1;
    lastUpdated = DateTime.now();
  }

  void _updateProductiveHours() {
    final sorted = taskCompletionByHour.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    productiveHours = sorted.take(3).map((e) => e.key).toList();
  }

  List<String> getTopSpendingCategories(int limit) {
    final sorted = spendingByCategory.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(limit).map((e) => e.key).toList();
  }
}

@JsonSerializable()
class DailyBriefingData {
  final List<TaskSummary> todayTasks;
  final List<BirthdaySummary> upcomingBirthdays;
  final ExchangeRateData? exchangeRate;
  final EconomyUpdate? economyUpdate;
  final String personalizedTip;
  final DateTime generatedAt;

  DailyBriefingData({
    required this.todayTasks,
    required this.upcomingBirthdays,
    this.exchangeRate,
    this.economyUpdate,
    required this.personalizedTip,
    DateTime? generatedAt,
  }) : generatedAt = generatedAt ?? DateTime.now();

  factory DailyBriefingData.fromJson(Map<String, dynamic> json) =>
      _$DailyBriefingDataFromJson(json);

  Map<String, dynamic> toJson() => _$DailyBriefingDataToJson(this);
}

@JsonSerializable()
class TaskSummary {
  final String id;
  final String title;
  final bool isCompleted;
  final String? priority;

  TaskSummary({
    required this.id,
    required this.title,
    required this.isCompleted,
    this.priority,
  });

  factory TaskSummary.fromJson(Map<String, dynamic> json) =>
      _$TaskSummaryFromJson(json);

  Map<String, dynamic> toJson() => _$TaskSummaryToJson(this);
}

@JsonSerializable()
class BirthdaySummary {
  final String id;
  final String name;
  final int age;
  final int daysUntil;

  BirthdaySummary({
    required this.id,
    required this.name,
    required this.age,
    required this.daysUntil,
  });

  factory BirthdaySummary.fromJson(Map<String, dynamic> json) =>
      _$BirthdaySummaryFromJson(json);

  Map<String, dynamic> toJson() => _$BirthdaySummaryToJson(this);
}

@JsonSerializable()
class ExchangeRateData {
  final double zarToUsd;
  final double zarToEur;
  final double zarToGbp;
  final DateTime lastUpdated;
  final String trend;

  ExchangeRateData({
    required this.zarToUsd,
    required this.zarToEur,
    required this.zarToGbp,
    required this.lastUpdated,
    required this.trend,
  });

  factory ExchangeRateData.fromJson(Map<String, dynamic> json) =>
      _$ExchangeRateDataFromJson(json);

  Map<String, dynamic> toJson() => _$ExchangeRateDataToJson(this);
}

@JsonSerializable()
class EconomyUpdate {
  final String headline;
  final String summary;
  final List<String> keyPoints;
  final String source;
  final DateTime publishedAt;

  EconomyUpdate({
    required this.headline,
    required this.summary,
    required this.keyPoints,
    required this.source,
    required this.publishedAt,
  });

  factory EconomyUpdate.fromJson(Map<String, dynamic> json) =>
      _$EconomyUpdateFromJson(json);

  Map<String, dynamic> toJson() => _$EconomyUpdateToJson(this);
}
