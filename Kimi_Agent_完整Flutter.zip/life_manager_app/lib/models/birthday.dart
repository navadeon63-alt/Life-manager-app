import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'birthday.g.dart';

@JsonSerializable()
class Birthday {
  final String id;
  String name;
  DateTime birthDate;
  String? relationship;
  String? phoneNumber;
  String? email;
  String? notes;
  String? imagePath;
  List<String> giftIdeas;
  bool reminderEnabled;
  int? reminderDaysBefore;
  DateTime createdAt;

  Birthday({
    String? id,
    required this.name,
    required this.birthDate,
    this.relationship,
    this.phoneNumber,
    this.email,
    this.notes,
    this.imagePath,
    List<String>? giftIdeas,
    this.reminderEnabled = true,
    this.reminderDaysBefore = 7,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        giftIdeas = giftIdeas ?? [],
        createdAt = createdAt ?? DateTime.now();

  factory Birthday.fromJson(Map<String, dynamic> json) =>
      _$BirthdayFromJson(json);

  Map<String, dynamic> toJson() => _$BirthdayToJson(this);

  Birthday copyWith({
    String? name,
    DateTime? birthDate,
    String? relationship,
    String? phoneNumber,
    String? email,
    String? notes,
    String? imagePath,
    List<String>? giftIdeas,
    bool? reminderEnabled,
    int? reminderDaysBefore,
  }) {
    return Birthday(
      id: id,
      name: name ?? this.name,
      birthDate: birthDate ?? this.birthDate,
      relationship: relationship ?? this.relationship,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      email: email ?? this.email,
      notes: notes ?? this.notes,
      imagePath: imagePath ?? this.imagePath,
      giftIdeas: giftIdeas ?? this.giftIdeas,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      reminderDaysBefore: reminderDaysBefore ?? this.reminderDaysBefore,
      createdAt: createdAt,
    );
  }

  int get age {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month ||
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  DateTime get nextBirthday {
    final now = DateTime.now();
    DateTime next = DateTime(now.year, birthDate.month, birthDate.day);
    if (next.isBefore(now) || next.isAtSameMomentAs(now)) {
      next = DateTime(now.year + 1, birthDate.month, birthDate.day);
    }
    return next;
  }

  int get daysUntilBirthday {
    final next = nextBirthday;
    final now = DateTime.now();
    return next.difference(now).inDays;
  }

  bool get isBirthdayToday {
    final now = DateTime.now();
    return now.month == birthDate.month && now.day == birthDate.day;
  }

  String get zodiacSign {
    final month = birthDate.month;
    final day = birthDate.day;

    if ((month == 3 && day >= 21) || (month == 4 && day <= 19)) return 'Aries';
    if ((month == 4 && day >= 20) || (month == 5 && day <= 20)) return 'Taurus';
    if ((month == 5 && day >= 21) || (month == 6 && day <= 20)) return 'Gemini';
    if ((month == 6 && day >= 21) || (month == 7 && day <= 22)) return 'Cancer';
    if ((month == 7 && day >= 23) || (month == 8 && day <= 22)) return 'Leo';
    if ((month == 8 && day >= 23) || (month == 9 && day <= 22)) return 'Virgo';
    if ((month == 9 && day >= 23) || (month == 10 && day <= 22)) return 'Libra';
    if ((month == 10 && day >= 23) || (month == 11 && day <= 21))
      return 'Scorpio';
    if ((month == 11 && day >= 22) || (month == 12 && day <= 21))
      return 'Sagittarius';
    if ((month == 12 && day >= 22) || (month == 1 && day <= 19))
      return 'Capricorn';
    if ((month == 1 && day >= 20) || (month == 2 && day <= 18))
      return 'Aquarius';
    return 'Pisces';
  }

  String get formattedNextBirthday {
    final next = nextBirthday;
    final suffix = _getDaySuffix(next.day);
    return '${next.day}$suffix ${_getMonthName(next.month)}';
  }

  String _getDaySuffix(int day) {
    if (day >= 11 && day <= 13) return 'th';
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  String _getMonthName(int month) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return months[month - 1];
  }
}
