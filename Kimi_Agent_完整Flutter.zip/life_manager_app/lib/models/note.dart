import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'note.g.dart';

@JsonSerializable()
class Note {
  final String id;
  String title;
  String content;
  DateTime createdAt;
  DateTime updatedAt;
  String? category;
  List<String> tags;
  String? imagePath;
  bool isPinned;
  String? color;

  Note({
    String? id,
    required this.title,
    required this.content,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.category,
    List<String>? tags,
    this.imagePath,
    this.isPinned = false,
    this.color,
  })  : id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        tags = tags ?? [];

  factory Note.fromJson(Map<String, dynamic> json) => _$NoteFromJson(json);

  Map<String, dynamic> toJson() => _$NoteToJson(this);

  Note copyWith({
    String? title,
    String? content,
    String? category,
    List<String>? tags,
    String? imagePath,
    bool? isPinned,
    String? color,
  }) {
    return Note(
      id: id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      category: category ?? this.category,
      tags: tags ?? this.tags,
      imagePath: imagePath ?? this.imagePath,
      isPinned: isPinned ?? this.isPinned,
      color: color ?? this.color,
    );
  }

  String get preview {
    if (content.isEmpty) return '';
    final lines = content.split('\n');
    final firstNonEmpty = lines.firstWhere(
      (line) => line.trim().isNotEmpty,
      orElse: () => '',
    );
    return firstNonEmpty.length > 100
        ? '${firstNonEmpty.substring(0, 100)}...'
        : firstNonEmpty;
  }
}
