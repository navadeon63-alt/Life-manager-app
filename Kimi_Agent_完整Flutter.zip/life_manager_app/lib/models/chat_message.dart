import 'package:json_annotation/json_annotation.dart';
import 'package:uuid/uuid.dart';

part 'chat_message.g.dart';

@JsonSerializable()
class ChatMessage {
  final String id;
  final String content;
  final bool isUser;
  final DateTime timestamp;
  final MessageType type;
  final String? imagePath;
  final List<String>? sources;
  final bool isOffline;
  final String? modelUsed;
  final Map<String, dynamic>? metadata;

  ChatMessage({
    String? id,
    required this.content,
    required this.isUser,
    DateTime? timestamp,
    this.type = MessageType.text,
    this.imagePath,
    this.sources,
    this.isOffline = false,
    this.modelUsed,
    this.metadata,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  factory ChatMessage.fromJson(Map<String, dynamic> json) =>
      _$ChatMessageFromJson(json);

  Map<String, dynamic> toJson() => _$ChatMessageToJson(this);

  ChatMessage copyWith({
    String? content,
    bool? isUser,
    MessageType? type,
    String? imagePath,
    List<String>? sources,
    bool? isOffline,
    String? modelUsed,
    Map<String, dynamic>? metadata,
  }) {
    return ChatMessage(
      id: id,
      content: content ?? this.content,
      isUser: isUser ?? this.isUser,
      timestamp: timestamp,
      type: type ?? this.type,
      imagePath: imagePath ?? this.imagePath,
      sources: sources ?? this.sources,
      isOffline: isOffline ?? this.isOffline,
      modelUsed: modelUsed ?? this.modelUsed,
      metadata: metadata ?? this.metadata,
    );
  }
}

enum MessageType { text, image, search, suggestion, error, system }

extension MessageTypeExtension on MessageType {
  String get displayName {
    switch (this) {
      case MessageType.text:
        return 'Text';
      case MessageType.image:
        return 'Image';
      case MessageType.search:
        return 'Search';
      case MessageType.suggestion:
        return 'Suggestion';
      case MessageType.error:
        return 'Error';
      case MessageType.system:
        return 'System';
    }
  }
}

@JsonSerializable()
class ChatSession {
  final String id;
  String title;
  final DateTime createdAt;
  DateTime updatedAt;
  List<ChatMessage> messages;
  bool isPinned;
  String? context;

  ChatSession({
    String? id,
    String? title,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<ChatMessage>? messages,
    this.isPinned = false,
    this.context,
  })  : id = id ?? const Uuid().v4(),
        title = title ?? 'New Chat',
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        messages = messages ?? [];

  factory ChatSession.fromJson(Map<String, dynamic> json) =>
      _$ChatSessionFromJson(json);

  Map<String, dynamic> toJson() => _$ChatSessionToJson(this);

  void addMessage(ChatMessage message) {
    messages.add(message);
    updatedAt = DateTime.now();
    _updateTitleIfNeeded();
  }

  void _updateTitleIfNeeded() {
    if (title == 'New Chat' && messages.isNotEmpty) {
      final firstUserMessage = messages.firstWhere(
        (m) => m.isUser,
        orElse: () => messages.first,
      );
      if (firstUserMessage.content.isNotEmpty) {
        title = firstUserMessage.content.length > 30
            ? '${firstUserMessage.content.substring(0, 30)}...'
            : firstUserMessage.content;
      }
    }
  }

  ChatMessage? get lastMessage => messages.isNotEmpty ? messages.last : null;

  int get messageCount => messages.length;
}
