import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/constants.dart';
import 'core/theme.dart';
import 'services/storage_service.dart';
import 'services/notification_service.dart';
import 'services/connectivity_service.dart';
import 'services/auth_service.dart';
import 'screens/sign_in_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Set system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: AppTheme.darkSurface,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  
  // Initialize services
  await _initializeServices();
  
  runApp(const LifeManagerApp());
}

Future<void> _initializeServices() async {
  // Initialize storage service
  await StorageService().initialize();
  
  // Initialize notification service
  await NotificationService().initialize();
  
  // Initialize connectivity service
  await ConnectivityService().initialize();
  
  // Initialize auth service
  await AuthService().initialize();
}

class LifeManagerApp extends StatelessWidget {
  const LifeManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const AppInitializer(),
    );
  }
}

class AppInitializer extends StatefulWidget {
  const AppInitializer({super.key});

  @override
  State<AppInitializer> createState() => _AppInitializerState();
}

class _AppInitializerState extends State<AppInitializer> {
  final AuthService _auth = AuthService();
  final StorageService _storage = StorageService();
  bool _isLoading = true;
  bool _isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
  }

  Future<void> _checkAuthStatus() async {
    try {
      // Check if user is already signed in
      final isSignedIn = _auth.isSignedIn;
      
      setState(() {
        _isLoggedIn = isSignedIn;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoggedIn = false;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppTheme.darkBackground,
                AppTheme.darkSurface,
              ],
            ),
          ),
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Icon(
                  Icons.auto_awesome,
                  size: 80,
                  color: AppTheme.primaryColor,
                ),
                SizedBox(height: 24),
                // Loading indicator
                CircularProgressIndicator(),
                SizedBox(height: 16),
                // Loading text
                Text(
                  'Loading...',
                  style: TextStyle(
                    color: AppTheme.darkTextSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Return appropriate screen based on auth status
    if (_isLoggedIn) {
      return const HomeScreen();
    } else {
      return const SignInScreen();
    }
  }
}

// Extension for file operations
extension FileExtension on String {
  String get fileName {
    return split(Platform.pathSeparator).last;
  }
  
  String get fileExtension {
    final name = fileName;
    final dotIndex = name.lastIndexOf('.');
    return dotIndex == -1 ? '' : name.substring(dotIndex + 1);
  }
}

// Extension for date formatting
extension DateTimeExtension on DateTime {
  String get formatted {
    return '$day/$month/$year';
  }
  
  String get formattedWithTime {
    return '$day/$month/$year ${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }
  
  bool get isToday {
    final now = DateTime.now();
    return year == now.year && month == now.month && day == now.day;
  }
  
  bool get isYesterday {
    final yesterday = DateTime.now().subtract(const Duration(days: 1));
    return year == yesterday.year && month == yesterday.month && day == yesterday.day;
  }
}

// Extension for string utilities
extension StringExtension on String {
  String get capitalize {
    if (isEmpty) return this;
    return '${this[0].toUpperCase()}${substring(1)}';
  }
  
  String get truncate {
    if (length <= 100) return this;
    return '${substring(0, 100)}...';
  }
}
