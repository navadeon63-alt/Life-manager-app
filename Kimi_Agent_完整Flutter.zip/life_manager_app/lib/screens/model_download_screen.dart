import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/theme.dart';
import '../services/local_ai_service.dart';
import '../services/user_profile_service.dart';
import 'home_screen.dart';

class ModelDownloadScreen extends StatefulWidget {
  const ModelDownloadScreen({super.key});

  @override
  State<ModelDownloadScreen> createState() => _ModelDownloadScreenState();
}

class _ModelDownloadScreenState extends State<ModelDownloadScreen> {
  final LocalAIService _localAI = LocalAIService();
  final UserProfileService _userProfile = UserProfileService();
  
  bool _isDownloading = false;
  double _downloadProgress = 0;
  String _statusMessage = '';
  bool _downloadComplete = false;
  bool _downloadFailed = false;

  Future<void> _downloadModel() async {
    setState(() {
      _isDownloading = true;
      _downloadProgress = 0;
      _statusMessage = 'Preparing download...';
      _downloadFailed = false;
    });

    try {
      final success = await _localAI.downloadModel(
        onProgress: (progress) {
          setState(() {
            _downloadProgress = progress;
            if (progress < 0.1) {
              _statusMessage = 'Initializing download...';
            } else if (progress < 0.5) {
              _statusMessage = 'Downloading model files...';
            } else if (progress < 0.8) {
              _statusMessage = 'Downloading parameters...';
            } else if (progress < 1.0) {
              _statusMessage = 'Finalizing...';
            } else {
              _statusMessage = 'Download complete!';
            }
          });
        },
      );

      if (success) {
        await _userProfile.setModelDownloaded(true);
        setState(() {
          _downloadComplete = true;
          _isDownloading = false;
        });
      } else {
        setState(() {
          _downloadFailed = true;
          _isDownloading = false;
          _statusMessage = 'Download failed. Please try again.';
        });
      }
    } catch (e) {
      setState(() {
        _downloadFailed = true;
        _isDownloading = false;
        _statusMessage = 'Error: $e';
      });
    }
  }

  void _skipDownload() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Skip Download?'),
        content: const Text(
          'Without the offline AI model, you\'ll need an internet connection to use the AI assistant. You can download it later in Settings.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _navigateToHome();
            },
            child: const Text('Skip'),
          ),
        ],
      ),
    );
  }

  void _navigateToHome() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.darkBackground,
              AppTheme.darkSurface,
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                
                // Icon
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    gradient: _downloadComplete
                        ? AppTheme.accentGradient
                        : AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: (_downloadComplete
                                ? AppTheme.accentColor
                                : AppTheme.primaryColor)
                            .withOpacity(0.3),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Icon(
                    _downloadComplete
                        ? Icons.check
                        : _isDownloading
                            ? Icons.downloading
                            : Icons.model_training,
                    size: 60,
                    color: Colors.white,
                  ),
                ),
                
                const SizedBox(height: 32),
                
                // Title
                Text(
                  _downloadComplete
                      ? 'Ready to Go!'
                      : 'Download AI Model',
                  style: Theme.of(context).textTheme.headlineLarge,
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 16),
                
                // Description
                Text(
                  _downloadComplete
                      ? 'The offline AI model has been downloaded successfully. You can now use the AI assistant even without an internet connection!'
                      : 'Download the Gemma 2B AI model to use the assistant offline. This is optional but recommended for the best experience.',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.darkTextSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 48),
                
                // Progress section
                if (_isDownloading || _downloadComplete) ...[
                  // Progress bar
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _downloadComplete ? 1.0 : _downloadProgress,
                      minHeight: 12,
                      backgroundColor: AppTheme.darkCard,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        _downloadComplete
                            ? AppTheme.accentColor
                            : AppTheme.primaryColor,
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Status text
                  Text(
                    _downloadComplete
                        ? 'Download complete!'
                        : '${(_downloadProgress * 100).toStringAsFixed(0)}% - $_statusMessage',
                    style: TextStyle(
                      fontSize: 14,
                      color: _downloadComplete
                          ? AppTheme.accentColor
                          : AppTheme.darkTextSecondary,
                    ),
                  ),
                  
                  if (_downloadComplete)
                    Text(
                      'Model size: ~1.5 GB',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppTheme.darkTextTertiary,
                      ),
                    ),
                ],
                
                if (_downloadFailed) ...[
                  const Icon(
                    Icons.error_outline,
                    color: AppTheme.errorColor,
                    size: 48,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _statusMessage,
                    style: const TextStyle(
                      color: AppTheme.errorColor,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
                
                const Spacer(),
                
                // Buttons
                if (!_isDownloading) ...[
                  if (!_downloadComplete) ...[
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _downloadModel,
                        child: const Text(
                          'Download Now',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: OutlinedButton(
                        onPressed: _skipDownload,
                        child: const Text(
                          'Skip for Now',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  ] else ...[
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: _navigateToHome,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.accentColor,
                        ),
                        child: const Text(
                          'Get Started',
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ),
                  ],
                ] else ...[
                  // Cancel button
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: OutlinedButton(
                      onPressed: () {
                        setState(() {
                          _isDownloading = false;
                          _downloadProgress = 0;
                        });
                      },
                      child: const Text(
                        'Cancel',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ],
                
                const SizedBox(height: 16),
                
                // Info text
                if (!_downloadComplete)
                  Text(
                    'You can download this later in Settings > AI Model',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.darkTextTertiary,
                    ),
                    textAlign: TextAlign.center,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
