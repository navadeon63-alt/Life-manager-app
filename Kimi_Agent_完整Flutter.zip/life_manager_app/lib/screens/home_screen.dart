import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/learning_engine_service.dart';
import 'tasks_screen.dart';
import 'notes_screen.dart';
import 'finance_screen.dart';
import 'birthdays_screen.dart';
import 'assistant_screen.dart';
import 'settings_screen.dart';
import 'daily_briefing_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final LearningEngineService _learning = LearningEngineService();

  final List<Widget> _screens = [
    const TasksScreen(),
    const NotesScreen(),
    const FinanceScreen(),
    const BirthdaysScreen(),
    const AssistantScreen(),
  ];

  final List<String> _titles = [
    'Tasks',
    'Notes',
    'Money',
    'Birthdays',
    'AI Assistant',
  ];

  final List<IconData> _icons = [
    Icons.task_alt,
    Icons.note_alt,
    Icons.account_balance_wallet,
    Icons.cake,
    Icons.smart_toy,
  ];

  @override
  void initState() {
    super.initState();
    _checkDailyBriefing();
    _learning.trackAppUsage();
  }

  Future<void> _checkDailyBriefing() async {
    // Show daily briefing on first open of the day
    // Implementation would check last shown date
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) {
      _showDailyBriefing();
    }
  }

  void _showDailyBriefing() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const DailyBriefingScreen(),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_currentIndex]),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // Show notifications
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.darkSurface,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          items: List.generate(
            _titles.length,
            (index) => BottomNavigationBarItem(
              icon: Icon(_icons[index]),
              label: _titles[index],
            ),
          ),
        ),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget? _buildFloatingActionButton() {
    switch (_currentIndex) {
      case 0: // Tasks
        return FloatingActionButton(
          onPressed: () => _showAddTaskDialog(),
          child: const Icon(Icons.add),
        );
      case 1: // Notes
        return FloatingActionButton(
          onPressed: () => _showAddNoteDialog(),
          child: const Icon(Icons.add),
        );
      case 2: // Finance
        return FloatingActionButton(
          onPressed: () => _showAddFinanceDialog(),
          child: const Icon(Icons.add),
        );
      case 3: // Birthdays
        return FloatingActionButton(
          onPressed: () => _showAddBirthdayDialog(),
          child: const Icon(Icons.add),
        );
      default:
        return null;
    }
  }

  void _showAddTaskDialog() {
    // Navigate to add task screen or show dialog
  }

  void _showAddNoteDialog() {
    // Navigate to add note screen or show dialog
  }

  void _showAddFinanceDialog() {
    // Navigate to add finance screen or show dialog
  }

  void _showAddBirthdayDialog() {
    // Navigate to add birthday screen or show dialog
  }
}
