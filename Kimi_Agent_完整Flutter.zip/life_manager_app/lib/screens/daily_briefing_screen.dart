import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/task.dart';
import '../models/birthday.dart';
import '../services/app_context_service.dart';
import '../services/ai_service.dart';
import '../services/learning_engine_service.dart';

class DailyBriefingScreen extends StatefulWidget {
  const DailyBriefingScreen({super.key});

  @override
  State<DailyBriefingScreen> createState() => _DailyBriefingScreenState();
}

class _DailyBriefingScreenState extends State<DailyBriefingScreen> {
  final AppContextService _context = AppContextService();
  final AdaptiveAIService _ai = AdaptiveAIService();
  final LearningEngineService _learning = LearningEngineService();
  
  bool _isLoading = true;
  List<Task> _todayTasks = [];
  List<Birthday> _upcomingBirthdays = [];
  Map<String, dynamic>? _exchangeRate;
  Map<String, dynamic>? _economyUpdate;
  String _personalizedTip = '';

  @override
  void initState() {
    super.initState();
    _loadBriefing();
  }

  Future<void> _loadBriefing() async {
    setState(() => _isLoading = true);
    
    await _context.loadAllData();
    await _ai.initialize();
    
    _todayTasks = _context.getTasksForToday();
    _upcomingBirthdays = _context.getUpcomingBirthdays(days: 30);
    
    // Get AI-powered data
    final briefingData = await _ai.getDailyBriefingData();
    _exchangeRate = briefingData['exchangeRate'];
    _economyUpdate = briefingData['economyUpdate'];
    
    // Get personalized tip
    _personalizedTip = await _ai.generatePersonalizedTip(
      tasks: _context.tasks,
      finances: _context.finances,
      behaviorPatterns: _learning.getProductivityInsights(),
    );
    
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.darkBackground,
              AppTheme.darkSurface,
            ],
          ),
        ),
        child: SafeArea(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : CustomScrollView(
                  slivers: [
                    // Header
                    SliverToBoxAdapter(
                      child: _buildHeader(),
                    ),
                    
                    // Content
                    SliverPadding(
                      padding: const EdgeInsets.all(16),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate([
                          // Today's tasks
                          _buildTasksSection(),
                          
                          const SizedBox(height: 16),
                          
                          // Upcoming birthdays
                          if (_upcomingBirthdays.isNotEmpty)
                            _buildBirthdaysSection(),
                          
                          if (_upcomingBirthdays.isNotEmpty)
                            const SizedBox(height: 16),
                          
                          // Exchange rate
                          if (_exchangeRate != null)
                            _buildExchangeRateSection(),
                          
                          if (_exchangeRate != null)
                            const SizedBox(height: 16),
                          
                          // Economy update
                          if (_economyUpdate != null)
                            _buildEconomySection(),
                          
                          if (_economyUpdate != null)
                            const SizedBox(height: 16),
                          
                          // Personalized tip
                          _buildTipSection(),
                          
                          const SizedBox(height: 32),
                          
                          // Dismiss button
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text('Got it, thanks!'),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final greeting = _learning.getPersonalizedGreeting();
    final now = DateTime.now();
    final date = '${now.day}/${now.month}/${now.year}';
    
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(
                  Icons.wb_sunny,
                  color: AppTheme.warningColor,
                  size: 32,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            greeting,
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'Here is your daily briefing for $date',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: AppTheme.darkTextSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTasksSection() {
    return _buildSectionCard(
      icon: Icons.task_alt,
      title: "Today's Tasks",
      color: AppTheme.primaryColor,
      child: _todayTasks.isEmpty
          ? const Text(
              'No tasks for today! Enjoy your free time.',
              style: TextStyle(color: AppTheme.darkTextSecondary),
            )
          : Column(
              children: _todayTasks.take(3).map((task) {
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Checkbox(
                    value: task.isCompleted,
                    onChanged: null,
                  ),
                  title: Text(
                    task.title,
                    style: TextStyle(
                      decoration: task.isCompleted
                          ? TextDecoration.lineThrough
                          : null,
                      color: task.isCompleted
                          ? AppTheme.darkTextTertiary
                          : AppTheme.darkTextPrimary,
                    ),
                  ),
                  subtitle: task.dueDate != null
                      ? Text(
                          'Due at ${task.dueDate!.hour}:${task.dueDate!.minute.toString().padLeft(2, '0')}',
                          style: const TextStyle(fontSize: 12),
                        )
                      : null,
                );
              }).toList(),
            ),
    );
  }

  Widget _buildBirthdaysSection() {
    final upcoming = _upcomingBirthdays.where((b) => b.daysUntilBirthday <= 7).toList();
    
    return _buildSectionCard(
      icon: Icons.cake,
      title: 'Upcoming Birthdays',
      color: AppTheme.accentColor,
      child: Column(
        children: upcoming.take(3).map((birthday) {
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundColor: AppTheme.accentColor.withOpacity(0.2),
              child: Text(birthday.name.substring(0, 1)),
            ),
            title: Text(birthday.name),
            subtitle: Text('Turning ${birthday.age + 1}'),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: birthday.daysUntilBirthday == 0
                    ? AppTheme.primaryColor
                    : AppTheme.darkCard,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                birthday.daysUntilBirthday == 0
                    ? 'Today!'
                    : '${birthday.daysUntilBirthday} days',
                style: TextStyle(
                  fontSize: 12,
                  color: birthday.daysUntilBirthday == 0
                      ? Colors.white
                      : AppTheme.darkTextPrimary,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildExchangeRateSection() {
    return _buildSectionCard(
      icon: Icons.currency_exchange,
      title: 'Rand Exchange Rate',
      color: AppTheme.successColor,
      child: Column(
        children: [
          _buildRateRow('USD', _exchangeRate?['zarToUsd'] ?? 0, '🇺🇸'),
          const Divider(),
          _buildRateRow('EUR', _exchangeRate?['zarToEur'] ?? 0, '🇪🇺'),
          const Divider(),
          _buildRateRow('GBP', _exchangeRate?['zarToGbp'] ?? 0, '🇬🇧'),
        ],
      ),
    );
  }

  Widget _buildRateRow(String currency, double rate, String flag) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(flag, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Text(
            '1 $currency =',
            style: const TextStyle(fontSize: 14),
          ),
          const Spacer(),
          Text(
            'R${rate.toStringAsFixed(2)}',
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEconomySection() {
    return _buildSectionCard(
      icon: Icons.trending_up,
      title: 'SA Economy Update',
      color: AppTheme.infoColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _economyUpdate?['headline'] ?? 'South Africa Economy',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _economyUpdate?['summary'] ?? 'No update available',
            style: const TextStyle(
              fontSize: 14,
              color: AppTheme.darkTextSecondary,
            ),
          ),
          if (_economyUpdate?['keyPoints'] != null) ...[
            const SizedBox(height: 12),
            ...(_economyUpdate!['keyPoints'] as List).take(3).map((point) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(fontSize: 14)),
                    Expanded(
                      child: Text(
                        point.toString(),
                        style: const TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      ),
    );
  }

  Widget _buildTipSection() {
    return _buildSectionCard(
      icon: Icons.lightbulb,
      title: 'Personalized Tip',
      color: AppTheme.warningColor,
      child: Text(
        _personalizedTip,
        style: const TextStyle(
          fontSize: 14,
          fontStyle: FontStyle.italic,
          color: AppTheme.darkTextSecondary,
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required IconData icon,
    required String title,
    required Color color,
    required Widget child,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            child,
          ],
        ),
      ),
    );
  }
}
