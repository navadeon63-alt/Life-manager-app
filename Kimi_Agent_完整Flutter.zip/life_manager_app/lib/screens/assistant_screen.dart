import 'dart:io';
import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/theme.dart';
import '../models/chat_message.dart';
import '../services/ai_service.dart';
import '../services/app_context_service.dart';
import '../services/image_service.dart';
import '../services/connectivity_service.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final AdaptiveAIService _ai = AdaptiveAIService();
  final AppContextService _context = AppContextService();
  final ImageService _image = ImageService();
  final ConnectivityService _connectivity = ConnectivityService();
  
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  List<ChatMessage> _messages = [];
  bool _isTyping = false;
  bool _isOnline = true;
  File? _attachedImage;

  final List<String> _suggestions = [
    'What tasks do I have today?',
    'How much did I spend this month?',
    'Any birthdays coming up?',
    'Analyze this receipt',
    'Give me productivity tips',
  ];

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    await _ai.initialize();
    _connectivity.connectionStream.listen((isConnected) {
      setState(() => _isOnline = isConnected);
    });
    
    // Add welcome message
    setState(() {
      _messages.add(ChatMessage(
        content: 'Hello! I\'m your AI assistant. I can help you manage tasks, track finances, remember birthdays, and much more. How can I help you today?',
        isUser: false,
        type: MessageType.text,
      ));
    });
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty && _attachedImage == null) return;

    final userMessage = ChatMessage(
      content: text,
      isUser: true,
      type: _attachedImage != null ? MessageType.image : MessageType.text,
      imagePath: _attachedImage?.path,
    );

    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
      _messageController.clear();
    });

    _scrollToBottom();

    try {
      ChatMessage response;
      
      if (_attachedImage != null) {
        response = await _ai.analyzeImage(_attachedImage!, prompt: text);
        setState(() => _attachedImage = null);
      } else {
        response = await _ai.sendMessage(text);
      }

      setState(() {
        _messages.add(response);
        _isTyping = false;
      });
    } catch (e) {
      setState(() {
        _messages.add(ChatMessage(
          content: 'Sorry, I encountered an error: $e',
          isUser: false,
          type: MessageType.error,
        ));
        _isTyping = false;
      });
    }

    _scrollToBottom();
  }

  Future<void> _searchWithGrounding() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    final userMessage = ChatMessage(
      content: text,
      isUser: true,
      type: MessageType.search,
    );

    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
      _messageController.clear();
    });

    _scrollToBottom();

    final response = await _ai.searchWithGrounding(text);

    setState(() {
      _messages.add(response);
      _isTyping = false;
    });

    _scrollToBottom();
  }

  Future<void> _attachImage() async {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () async {
                Navigator.pop(context);
                final image = await _image.takePhoto();
                if (image != null) {
                  setState(() => _attachedImage = image);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () async {
                Navigator.pop(context);
                final image = await _image.pickFromGallery();
                if (image != null) {
                  setState(() => _attachedImage = image);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _useSuggestion(String suggestion) {
    _messageController.text = suggestion;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Assistant'),
        actions: [
          // Connection status
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: _isOnline
                  ? AppTheme.successColor.withOpacity(0.2)
                  : AppTheme.warningColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _isOnline ? Icons.wifi : Icons.wifi_off,
                  size: 14,
                  color: _isOnline ? AppTheme.successColor : AppTheme.warningColor,
                ),
                const SizedBox(width: 4),
                Text(
                  _isOnline ? 'Online' : 'Offline',
                  style: TextStyle(
                    fontSize: 12,
                    color: _isOnline ? AppTheme.successColor : AppTheme.warningColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Suggestions
          if (_messages.length <= 1)
            Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _suggestions.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: Text(_suggestions[index]),
                      onPressed: () => _useSuggestion(_suggestions[index]),
                      backgroundColor: AppTheme.darkCard,
                    ),
                  );
                },
              ),
            ),
          
          // Messages
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return _buildMessageBubble(message);
              },
            ),
          ),
          
          // Typing indicator
          if (_isTyping)
            const Padding(
              padding: EdgeInsets.only(left: 16, bottom: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    SizedBox(width: 8),
                    Text(
                      'AI is typing...',
                      style: TextStyle(
                        color: AppTheme.darkTextTertiary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          
          // Attached image preview
          if (_attachedImage != null)
            Container(
              height: 80,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      _attachedImage!,
                      height: 80,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: GestureDetector(
                      onTap: () => setState(() => _attachedImage = null),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          size: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          
          // Input area
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.darkSurface,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.image),
                    onPressed: _attachImage,
                    color: AppTheme.darkTextSecondary,
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      decoration: const InputDecoration(
                        hintText: 'Type a message...',
                        border: InputBorder.none,
                      ),
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                  if (_isOnline)
                    IconButton(
                      icon: const Icon(Icons.search),
                      onPressed: _searchWithGrounding,
                      color: AppTheme.primaryColor,
                      tooltip: 'Search with Google',
                    ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: _sendMessage,
                    color: AppTheme.primaryColor,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    final isUser = message.isUser;
    
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.8,
        ),
        child: Column(
          crossAxisAlignment:
              isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isUser
                    ? AppTheme.primaryColor
                    : message.type == MessageType.error
                        ? AppTheme.errorColor.withOpacity(0.2)
                        : AppTheme.darkCard,
                borderRadius: BorderRadius.circular(16).copyWith(
                  bottomRight: isUser ? const Radius.circular(4) : null,
                  bottomLeft: !isUser ? const Radius.circular(4) : null,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (message.imagePath != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(message.imagePath!),
                        width: 200,
                        fit: BoxFit.cover,
                      ),
                    ),
                  if (message.imagePath != null) const SizedBox(height: 8),
                  Text(
                    message.content,
                    style: TextStyle(
                      color: isUser
                          ? Colors.white
                          : message.type == MessageType.error
                              ? AppTheme.errorColor
                              : AppTheme.darkTextPrimary,
                    ),
                  ),
                  if (message.sources != null && message.sources!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Sources:',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          ...message.sources!.map((s) => Text(
                                '• $s',
                                style: const TextStyle(fontSize: 11),
                              )),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            if (!isUser && message.modelUsed != null)
              Padding(
                padding: const EdgeInsets.only(top: 4, left: 8),
                child: Text(
                  message.isOffline
                      ? 'Offline • ${message.modelUsed}'
                      : 'Online • ${message.modelUsed}',
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppTheme.darkTextTertiary,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
