import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../core/constants.dart';
import '../core/theme.dart';
import '../models/birthday.dart';
import '../services/app_context_service.dart';
import '../services/notification_service.dart';
import '../services/image_service.dart';

class BirthdaysScreen extends StatefulWidget {
  const BirthdaysScreen({super.key});

  @override
  State<BirthdaysScreen> createState() => _BirthdaysScreenState();
}

class _BirthdaysScreenState extends State<BirthdaysScreen> {
  final AppContextService _context = AppContextService();
  final NotificationService _notifications = NotificationService();
  final ImageService _image = ImageService();
  
  List<Birthday> _birthdays = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBirthdays();
  }

  Future<void> _loadBirthdays() async {
    setState(() => _isLoading = true);
    await _context.loadBirthdays();
    setState(() {
      _birthdays = _context.birthdays;
      _isLoading = false;
    });
  }

  Future<void> _addBirthday() async {
    final result = await showModalBottomSheet<Birthday>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const AddBirthdaySheet(),
    );

    if (result != null) {
      await _context.addBirthday(result);
      await _notifications.scheduleBirthdayReminder(result);
      _loadBirthdays();
    }
  }

  Future<void> _editBirthday(Birthday birthday) async {
    final result = await showModalBottomSheet<Birthday>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddBirthdaySheet(birthday: birthday),
    );

    if (result != null) {
      await _context.updateBirthday(result);
      await _notifications.scheduleBirthdayReminder(result);
      _loadBirthdays();
    }
  }

  Future<void> _deleteBirthday(Birthday birthday) async {
    await _notifications.cancelBirthdayReminder(birthday.id);
    await _context.deleteBirthday(birthday.id);
    _loadBirthdays();
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(SuccessMessages.birthdayDeleted)),
      );
    }
  }

  List<Birthday> get _sortedBirthdays {
    return _birthdays..sort((a, b) {
      return a.daysUntilBirthday.compareTo(b.daysUntilBirthday);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _sortedBirthdays.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.only(bottom: 80),
                  itemCount: _sortedBirthdays.length,
                  itemBuilder: (context, index) {
                    final birthday = _sortedBirthdays[index];
                    return _buildBirthdayCard(birthday);
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addBirthday,
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBirthdayCard(Birthday birthday) {
    final isToday = birthday.isBirthdayToday;
    final daysUntil = birthday.daysUntilBirthday;
    
    return Slidable(
      key: ValueKey(birthday.id),
      endActionPane: ActionPane(
        motion: const ScrollMotion(),
        children: [
          SlidableAction(
            onPressed: (_) => _editBirthday(birthday),
            backgroundColor: AppTheme.infoColor,
            foregroundColor: Colors.white,
            icon: Icons.edit,
            label: 'Edit',
          ),
          SlidableAction(
            onPressed: (_) => _deleteBirthday(birthday),
            backgroundColor: AppTheme.errorColor,
            foregroundColor: Colors.white,
            icon: Icons.delete,
            label: 'Delete',
          ),
        ],
      ),
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        color: isToday ? AppTheme.primaryColor.withOpacity(0.1) : null,
        child: ListTile(
          leading: Stack(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: isToday
                    ? AppTheme.primaryColor
                    : AppTheme.darkCard,
                backgroundImage: birthday.imagePath != null
                    ? FileImage(File(birthday.imagePath!))
                    : null,
                child: birthday.imagePath == null
                    ? Text(
                        birthday.name.substring(0, 1).toUpperCase(),
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: isToday ? Colors.white : AppTheme.darkTextPrimary,
                        ),
                      )
                    : null,
              ),
              if (isToday)
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: AppTheme.warningColor,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.cake,
                      size: 12,
                      color: Colors.white,
                    ),
                  ),
                ),
            ],
          ),
          title: Text(
            birthday.name,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (birthday.relationship != null)
                Text(
                  birthday.relationship!,
                  style: const TextStyle(fontSize: 12),
                ),
              Text(
                isToday
                    ? '🎉 Turning ${birthday.age + 1} today!'
                    : daysUntil == 0
                        ? 'Tomorrow'
                        : '$daysUntil days until birthday',
                style: TextStyle(
                  fontSize: 12,
                  color: isToday ? AppTheme.primaryColor : AppTheme.darkTextSecondary,
                  fontWeight: isToday ? FontWeight.w600 : null,
                ),
              ),
            ],
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                birthday.formattedNextBirthday,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${birthday.age + 1} years',
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.darkTextSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.cake,
            size: 80,
            color: AppTheme.darkTextTertiary.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No birthdays yet',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: AppTheme.darkTextTertiary.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap + to add birthdays and never forget!',
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.darkTextTertiary.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }
}

class AddBirthdaySheet extends StatefulWidget {
  final Birthday? birthday;
  
  const AddBirthdaySheet({super.key, this.birthday});

  @override
  State<AddBirthdaySheet> createState() => _AddBirthdaySheetState();
}

class _AddBirthdaySheetState extends State<AddBirthdaySheet> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _notesController = TextEditingController();
  DateTime? _birthDate;
  String? _relationship;
  String? _imagePath;
  bool _reminderEnabled = true;
  int _reminderDays = 7;

  final ImageService _image = ImageService();

  @override
  void initState() {
    super.initState();
    if (widget.birthday != null) {
      _nameController.text = widget.birthday!.name;
      _phoneController.text = widget.birthday!.phoneNumber ?? '';
      _emailController.text = widget.birthday!.email ?? '';
      _notesController.text = widget.birthday!.notes ?? '';
      _birthDate = widget.birthday!.birthDate;
      _relationship = widget.birthday!.relationship;
      _imagePath = widget.birthday!.imagePath;
      _reminderEnabled = widget.birthday!.reminderEnabled;
      _reminderDays = widget.birthday!.reminderDaysBefore ?? 7;
    }
  }

  Future<void> _pickImage() async {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take Photo'),
              onTap: () async {
                Navigator.pop(context);
                final image = await _image.takePhoto();
                if (image != null) {
                  final path = await _image.saveImage(image);
                  setState(() => _imagePath = path);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Choose from Gallery'),
              onTap: () async {
                Navigator.pop(context);
                final image = await _image.pickFromGallery();
                if (image != null) {
                  final path = await _image.saveImage(image);
                  setState(() => _imagePath = path);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: const BoxDecoration(
        color: AppTheme.darkSurface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.darkBorder,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              Text(
                widget.birthday == null ? 'Add Birthday' : 'Edit Birthday',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              
              const SizedBox(height: 24),
              
              // Profile image
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: AppTheme.darkCard,
                    backgroundImage:
                        _imagePath != null ? FileImage(File(_imagePath!)) : null,
                    child: _imagePath == null
                        ? const Icon(Icons.camera_alt, size: 32)
                        : null,
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Name
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  hintText: 'e.g., John Smith',
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Birth date
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_today),
                title: const Text('Birth Date'),
                subtitle: Text(
                  _birthDate != null
                      ? '${_birthDate!.day}/${_birthDate!.month}/${_birthDate!.year}'
                      : 'Not set',
                ),
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now().subtract(const Duration(days: 365 * 25)),
                    firstDate: DateTime(1900),
                    lastDate: DateTime.now(),
                  );
                  if (date != null) {
                    setState(() => _birthDate = date);
                  }
                },
              ),
              
              const SizedBox(height: 16),
              
              // Relationship
              DropdownButtonFormField<String>(
                value: _relationship,
                decoration: const InputDecoration(
                  labelText: 'Relationship',
                ),
                items: AppConstants.relationshipTypes.map((rel) {
                  return DropdownMenuItem(
                    value: rel,
                    child: Text(rel),
                  );
                }).toList(),
                onChanged: (value) => setState(() => _relationship = value),
              ),
              
              const SizedBox(height: 16),
              
              // Reminder settings
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Enable Reminder'),
                subtitle: Text('$_reminderDays days before'),
                value: _reminderEnabled,
                onChanged: (value) => setState(() => _reminderEnabled = value),
              ),
              
              if (_reminderEnabled)
                Slider(
                  value: _reminderDays.toDouble(),
                  min: 1,
                  max: 30,
                  divisions: 29,
                  label: '$_reminderDays days',
                  onChanged: (value) {
                    setState(() => _reminderDays = value.round());
                  },
                ),
              
              const SizedBox(height: 24),
              
              // Save button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: Text(widget.birthday == null ? 'Add Birthday' : 'Save Changes'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _save() {
    if (_nameController.text.trim().isEmpty || _birthDate == null) return;

    final birthday = Birthday(
      id: widget.birthday?.id,
      name: _nameController.text.trim(),
      birthDate: _birthDate!,
      relationship: _relationship,
      phoneNumber: _phoneController.text.trim().isEmpty
          ? null
          : _phoneController.text.trim(),
      email: _emailController.text.trim().isEmpty
          ? null
          : _emailController.text.trim(),
      notes: _notesController.text.trim().isEmpty
          ? null
          : _notesController.text.trim(),
      imagePath: _imagePath,
      reminderEnabled: _reminderEnabled,
      reminderDaysBefore: _reminderDays,
    );

    Navigator.pop(context, birthday);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}
