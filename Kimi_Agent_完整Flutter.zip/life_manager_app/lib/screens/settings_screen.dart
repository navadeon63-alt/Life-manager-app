import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../services/notification_service.dart';
import '../services/user_profile_service.dart';
import '../services/local_ai_service.dart';
import 'sign_in_screen.dart';
import 'model_download_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final AuthService _auth = AuthService();
  final StorageService _storage = StorageService();
  final NotificationService _notifications = NotificationService();
  final UserProfileService _userProfile = UserProfileService();
  final LocalAIService _localAI = LocalAIService();

  bool _notificationsEnabled = true;
  bool _dailyBriefingEnabled = true;
  bool _darkMode = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    setState(() {
      _notificationsEnabled = _userProfile.preferences.notificationsEnabled;
      _dailyBriefingEnabled = _userProfile.preferences.dailyBriefingEnabled;
      _darkMode = _userProfile.preferences.darkMode;
    });
  }

  Future<void> _toggleNotifications(bool value) async {
    setState(() => _notificationsEnabled = value);
    await _userProfile.setNotificationsEnabled(value);
    
    if (value) {
      await _notifications.requestPermissions();
    }
  }

  Future<void> _toggleDailyBriefing(bool value) async {
    setState(() => _dailyBriefingEnabled = value);
    await _userProfile.setDailyBriefingEnabled(value);
    
    if (value) {
      await _notifications.scheduleDailyBriefing();
    } else {
      await _notifications.cancelDailyBriefing();
    }
  }

  Future<void> _toggleDarkMode(bool value) async {
    setState(() => _darkMode = value);
    await _userProfile.setDarkMode(value);
  }

  Future<void> _signOut() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              setState(() => _isLoading = true);
              
              await _auth.signOut();
              
              if (mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const SignInScreen()),
                  (route) => false,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
  }

  Future<void> _clearAllData() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear All Data'),
        content: const Text(
          'This will permanently delete all your tasks, notes, finances, and birthdays. This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              setState(() => _isLoading = true);
              
              await _storage.clearAll();
              await _notifications.cancelAllNotifications();
              
              setState(() => _isLoading = false);
              
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('All data cleared')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }

  Future<void> _downloadModel() async {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ModelDownloadScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                // User profile section
                _buildUserProfileSection(),
                
                const Divider(),
                
                // Preferences
                _buildSectionHeader('Preferences'),
                
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_outlined),
                  title: const Text('Notifications'),
                  subtitle: const Text('Enable push notifications'),
                  value: _notificationsEnabled,
                  onChanged: _toggleNotifications,
                ),
                
                SwitchListTile(
                  secondary: const Icon(Icons.wb_sunny_outlined),
                  title: const Text('Daily Briefing'),
                  subtitle: const Text('Morning summary of your day'),
                  value: _dailyBriefingEnabled,
                  onChanged: _toggleDailyBriefing,
                ),
                
                SwitchListTile(
                  secondary: const Icon(Icons.dark_mode_outlined),
                  title: const Text('Dark Mode'),
                  subtitle: const Text('Use dark theme'),
                  value: _darkMode,
                  onChanged: _toggleDarkMode,
                ),
                
                const Divider(),
                
                // AI Settings
                _buildSectionHeader('AI Assistant'),
                
                ListTile(
                  leading: const Icon(Icons.model_training),
                  title: const Text('AI Model'),
                  subtitle: Text(
                    _localAI.isAvailable
                        ? 'Gemma 2B (Offline)'
                        : 'Not downloaded',
                  ),
                  trailing: _localAI.isAvailable
                      ? const Icon(Icons.check_circle, color: AppTheme.successColor)
                      : TextButton(
                          onPressed: _downloadModel,
                          child: const Text('Download'),
                        ),
                ),
                
                const Divider(),
                
                // Data Management
                _buildSectionHeader('Data Management'),
                
                ListTile(
                  leading: const Icon(Icons.backup_outlined),
                  title: const Text('Create Backup'),
                  subtitle: const Text('Export all your data'),
                  onTap: () async {
                    setState(() => _isLoading = true);
                    try {
                      final path = await _storage.createBackup();
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Backup saved to: $path')),
                        );
                      }
                    } catch (e) {
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Backup failed: $e')),
                        );
                      }
                    }
                    setState(() => _isLoading = false);
                  },
                ),
                
                ListTile(
                  leading: const Icon(Icons.restore_outlined),
                  title: const Text('Restore from Backup'),
                  subtitle: const Text('Import previously exported data'),
                  onTap: () {
                    // Show file picker and restore
                  },
                ),
                
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: AppTheme.errorColor),
                  title: const Text(
                    'Clear All Data',
                    style: TextStyle(color: AppTheme.errorColor),
                  ),
                  subtitle: const Text('Permanently delete all app data'),
                  onTap: _clearAllData,
                ),
                
                const Divider(),
                
                // About
                _buildSectionHeader('About'),
                
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: const Text('App Version'),
                  subtitle: const Text(AppConstants.appVersion),
                ),
                
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined),
                  title: const Text('Privacy Policy'),
                  onTap: () {
                    // Show privacy policy
                  },
                ),
                
                ListTile(
                  leading: const Icon(Icons.help_outline),
                  title: const Text('Help & Support'),
                  onTap: () {
                    // Show help
                  },
                ),
                
                const Divider(),
                
                // Sign Out
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: _signOut,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.errorColor.withOpacity(0.1),
                        foregroundColor: AppTheme.errorColor,
                        elevation: 0,
                      ),
                      icon: const Icon(Icons.logout),
                      label: const Text('Sign Out'),
                    ),
                  ),
                ),
                
                const SizedBox(height: 32),
              ],
            ),
    );
  }

  Widget _buildUserProfileSection() {
    final user = _auth.currentUser;
    
    return Container(
      padding: const EdgeInsets.all(24),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundImage: user?.photoUrl != null
                ? NetworkImage(user!.photoUrl!)
                : null,
            child: user?.photoUrl == null
                ? Text(
                    (user?.displayName ?? 'U').substring(0, 1).toUpperCase(),
                    style: const TextStyle(fontSize: 32),
                  )
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user?.displayName ?? 'User',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  user?.email ?? '',
                  style: const TextStyle(
                    fontSize: 14,
                    color: AppTheme.darkTextSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: AppTheme.darkTextTertiary,
          letterSpacing: 1,
        ),
      ),
    );
  }
}
