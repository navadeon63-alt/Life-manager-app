import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/transaction.dart';
import 'storage_service.dart';

class VisionService {
  final StorageService _storageService = StorageService();
  
  static const String _apiUrl = 
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';
  
  static const String _prompt = 
      'Look at this financial document. Extract: 1) transaction type (income or expense), 2) amount in numbers only, 3) description of what it is, 4) date if visible. Reply in this exact JSON format: {"type":"income or expense","amount":0.00,"description":"text","date":"YYYY-MM-DD"}. If you cannot find financial data, reply: {"error":"no financial data found"}';

  Future<Transaction> extractTransactionFromImage(File imageFile) async {
    final String? apiKey = await _storageService.getApiKey();
    
    if (apiKey == null || apiKey.isEmpty) {
      throw Exception('Gemini API key not configured. Please set your API key in Settings.');
    }

    try {
      final Uint8List imageBytes = await imageFile.readAsBytes();
      final String base64Image = base64Encode(imageBytes);
      
      final Uri url = Uri.parse('$_apiUrl?key=$apiKey');
      
      final Map<String, dynamic> requestBody = {
        'contents': [
          {
            'parts': [
              {
                'text': _prompt
              },
              {
                'inlineData': {
                  'mimeType': 'image/jpeg',
                  'data': base64Image
                }
              }
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.1,
          'maxOutputTokens': 1024
        }
      };

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestBody),
      );

      if (response.statusCode != 200) {
        throw Exception('API request failed with status: ${response.statusCode}. Response: ${response.body}');
      }

      final Map<String, dynamic> responseData = jsonDecode(response.body);
      
      if (responseData['error'] != null) {
        throw Exception('API error: ${responseData['error']['message']}');
      }

      final String extractedText = _extractTextFromResponse(responseData);
      
      return _parseTransactionFromText(extractedText);
    } on FormatException catch (e) {
      throw Exception('Failed to parse API response: $e');
    } on HttpException catch (e) {
      throw Exception('Network error: $e');
    } catch (e) {
      throw Exception('Failed to process image: $e');
    }
  }

  String _extractTextFromResponse(Map<String, dynamic> responseData) {
    try {
      final candidates = responseData['candidates'] as List<dynamic>;
      if (candidates.isEmpty) {
        throw Exception('No response from API');
      }
      
      final content = candidates[0]['content'] as Map<String, dynamic>;
      final parts = content['parts'] as List<dynamic>;
      
      if (parts.isEmpty) {
        throw Exception('Empty response from API');
      }
      
      return parts[0]['text'] as String;
    } catch (e) {
      throw Exception('Failed to extract text from response: $e');
    }
  }

  Transaction _parseTransactionFromText(String text) {
    try {
      final String cleanedText = text.trim();
      
      final jsonStartIndex = cleanedText.indexOf('{');
      final jsonEndIndex = cleanedText.lastIndexOf('}');
      
      if (jsonStartIndex == -1 || jsonEndIndex == -1 || jsonEndIndex <= jsonStartIndex) {
        throw Exception('No valid JSON found in response');
      }
      
      final String jsonString = cleanedText.substring(jsonStartIndex, jsonEndIndex + 1);
      final Map<String, dynamic> jsonData = jsonDecode(jsonString);
      
      if (jsonData['error'] != null) {
        throw Exception(jsonData['error'] as String);
      }
      
      final String type = jsonData['type'] as String? ?? '';
      final dynamic amountData = jsonData['amount'];
      final String description = jsonData['description'] as String? ?? '';
      final String dateString = jsonData['date'] as String? ?? '';
      
      if (type.isEmpty || amountData == null) {
        throw Exception('Missing required fields in response');
      }
      
      final double amount = (amountData is int) 
          ? amountData.toDouble() 
          : (amountData as num).toDouble();
      
      if (amount <= 0) {
        throw Exception('Invalid amount: must be greater than zero');
      }
      
      DateTime transactionDate;
      try {
        if (dateString.isNotEmpty && dateString.contains('-')) {
          transactionDate = DateTime.parse(dateString);
        } else {
          transactionDate = DateTime.now();
        }
      } catch (e) {
        transactionDate = DateTime.now();
      }
      
      final normalizedType = type.toLowerCase().trim();
      if (normalizedType != 'income' && normalizedType != 'expense') {
        throw Exception('Invalid transaction type: must be "income" or "expense"');
      }
      
      return Transaction(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: normalizedType,
        amount: amount,
        description: description.isNotEmpty ? description : 'Unknown transaction',
        date: transactionDate,
        createdAt: DateTime.now(),
      );
    } on FormatException catch (e) {
      throw Exception('Invalid JSON format in response: $e');
    } catch (e) {
      throw Exception('Failed to parse transaction: $e');
    }
  }
}
