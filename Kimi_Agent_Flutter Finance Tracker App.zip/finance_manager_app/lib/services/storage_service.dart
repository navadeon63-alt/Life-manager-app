import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/transaction.dart';

class StorageService {
  static const String _transactionsKey = 'transactions';
  static const String _apiKeyKey = 'gemini_api_key';
  
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  SharedPreferences? _prefs;

  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
  }

  Future<List<Transaction>> getTransactions() async {
    if (_prefs == null) {
      await initialize();
    }
    
    final String? transactionsJson = _prefs!.getString(_transactionsKey);
    
    if (transactionsJson == null || transactionsJson.isEmpty) {
      return [];
    }
    
    try {
      final List<dynamic> decoded = jsonDecode(transactionsJson) as List<dynamic>;
      final transactions = decoded
          .map((item) => Transaction.fromJson(item as Map<String, dynamic>))
          .toList();
      
      transactions.sort((a, b) => b.date.compareTo(a.date));
      
      return transactions;
    } catch (e) {
      return [];
    }
  }

  Future<void> saveTransaction(Transaction transaction) async {
    if (_prefs == null) {
      await initialize();
    }
    
    final transactions = await getTransactions();
    transactions.add(transaction);
    
    await _saveTransactionsList(transactions);
  }

  Future<void> deleteTransaction(String id) async {
    if (_prefs == null) {
      await initialize();
    }
    
    final transactions = await getTransactions();
    transactions.removeWhere((t) => t.id == id);
    
    await _saveTransactionsList(transactions);
  }

  Future<void> _saveTransactionsList(List<Transaction> transactions) async {
    final List<Map<String, dynamic>> jsonList = 
        transactions.map((t) => t.toJson()).toList();
    final String encoded = jsonEncode(jsonList);
    
    await _prefs!.setString(_transactionsKey, encoded);
  }

  Future<String?> getApiKey() async {
    if (_prefs == null) {
      await initialize();
    }
    
    return _prefs!.getString(_apiKeyKey);
  }

  Future<void> saveApiKey(String apiKey) async {
    if (_prefs == null) {
      await initialize();
    }
    
    await _prefs!.setString(_apiKeyKey, apiKey);
  }

  Future<void> clearAllData() async {
    if (_prefs == null) {
      await initialize();
    }
    
    await _prefs!.remove(_transactionsKey);
  }

  double getTotalBalance(List<Transaction> transactions) {
    double income = 0;
    double expense = 0;
    
    for (final transaction in transactions) {
      if (transaction.isIncome) {
        income += transaction.amount;
      } else {
        expense += transaction.amount;
      }
    }
    
    return income - expense;
  }

  double getTotalIncome(List<Transaction> transactions) {
    return transactions
        .where((t) => t.isIncome)
        .fold(0, (sum, t) => sum + t.amount);
  }

  double getTotalExpenses(List<Transaction> transactions) {
    return transactions
        .where((t) => t.isExpense)
        .fold(0, (sum, t) => sum + t.amount);
  }
}
